package com.hk.gonggongnews.ngogong;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.load.MultiTransformation;
import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.GongInfoContract;
import com.hk.gonggongnews.ngogong.data.GongInfoLookupContract;
import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.sync.FirebaseIntentService;
import com.hk.gonggongnews.ngogong.sync.GSheetQuery;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;

import java.util.LinkedHashMap;
import java.util.Map;

import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropTransformation;

import static android.support.v7.widget.RecyclerView.SCROLL_STATE_DRAGGING;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_IDLE;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_SETTLING;

/**
 * Created by ismile on 11/28/2017.
 */

public class GongNewsDetailActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>,
        FirstLevelNewsAdapter.FirstLevelNewsAdapterOnClickHandler {



    private Map<String, String> mArticleLookupList;
    private Map<String, String> mGongInfoLookupList;

    private final String TAG = GongNewsDetailActivity.class.getSimpleName();

    private static final int ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER = 601;
    private static final int ID_ARTICLELOOKUP_LOADER = 602;
    private static final int ID_SIGNAL_LOADER = 603;
    private static final int ID_GONGINFO_NAME_NAME_LOADER = 604;

    private static final int ID_ARCHIVELATESTLOOKUP_LOADER = 605;
    private static final int ID_ARCHIVELATESTPAGELOOKUP_LOADER = 606;

    private static final int NUMBER_OF_ENTRY_TO_RETRIEVE = 20;
    private int mCurrentNoofEntry=0;
    private FirstLevelNewsAdapter mFirstLevelNewsAdapter;

    private SlowdownRecyclerView mRecyclerView;
    private int mPosition = RecyclerView.NO_POSITION;

    private ProgressBar mLoadingIndicator;

    private boolean mLoadingMore = false;
    private SwipeRefreshLayout mSwipeRefreshLayout ;
    private boolean mRefreshingLayout=false ;
    private boolean mUsingAllArchive =false;
    private boolean mUsingPageArchive =false;
    private int mRetrievePageNumber = 0;
    private Context mCurrentContext;


    public final static String PREFERREDLISTINTARRAY = "preferredlistarray";

    public final static String ENTITY_NAME = "entity_name";
    public final static String ENTITY_ID = "entity_id";
    private String mEntity_name;
    private int mEntity_id;

    private Cursor mCursorGongInfoLookup=null;
    private Cursor mCursorGongInfo;
    private CollapsingToolbarLayout mCollapsingToolbarLayout;
    private String mCollapsingToolbarTitle;
    private TextView mNoNewsHimHer;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gongnews_detail);

        Intent intent = getIntent();
        mEntity_name = intent.getStringExtra(ENTITY_NAME);
        mEntity_id = intent.getIntExtra(ENTITY_ID,0);

        LogUtil.debug(TAG, " oncreate 0 name=" + mEntity_name + ",id=" + mEntity_id);
        mCurrentContext = this;
        mArticleLookupList = new LinkedHashMap<String, String>();
        mGongInfoLookupList = new LinkedHashMap<String, String>();
        LogUtil.debug(TAG, "oncreate 1 ");

        mRecyclerView = (SlowdownRecyclerView) findViewById(R.id.recyclerview_slowdown);
        mLoadingIndicator = (ProgressBar) findViewById(R.id.pb_loading_indicator);


        LinearLayoutManager layoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(false);
        mFirstLevelNewsAdapter = new FirstLevelNewsAdapter(this, this);

        mRecyclerView.setAdapter(mFirstLevelNewsAdapter);

        LogUtil.debug(TAG, "oncreateview 2 ");


        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                LogUtil.debug(TAG, "-->  onScrollStateChanged idle=" + SCROLL_STATE_IDLE + ",settling=" + SCROLL_STATE_SETTLING + ",dragging=" +
                        SCROLL_STATE_DRAGGING + ",newState=" + newState);
                int visibleItemCount = recyclerView.getLayoutManager().getChildCount();
                int totalItemCount = recyclerView.getLayoutManager().getItemCount();
                int findFirstVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findFirstVisibleItemPosition();
                int findFirstCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findFirstCompletelyVisibleItemPosition();
                int findLastVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findLastVisibleItemPosition();
                int findLastCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findLastCompletelyVisibleItemPosition();

                LogUtil.debug(TAG, "----> onscrollstatechanged  visibleItemCount=" + visibleItemCount +
                        ",totalItemCount=" + totalItemCount +
                        ",findFirstVisibleItemPosition=" + findFirstVisibleItemPosition +
                        ",findFirstCompletelyVisibleItemPosition=" + findFirstCompletelyVisibleItemPosition +
                        ",findLastVisibleItemPosition=" + findLastVisibleItemPosition +
                        ",findLastCompletelyVisibleItemPosition=" + findLastCompletelyVisibleItemPosition
                );
                if ((mLoadingMore == false)
                        && (newState == SCROLL_STATE_DRAGGING)
                        && (((float) findLastVisibleItemPosition / totalItemCount) > 0.4)
                        ) {
                    if (isOnline()) {
                        LogUtil.debug(TAG, " onscrollstatechanged 10 ");
                        mCursorGongInfoLookup.moveToPosition(0);

                        int remoteNoofEntry = mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY);
                        int localNoofEntry = GongPreference.getLastUpdateNoOfEntry(mCurrentContext, mEntity_name);
                        if  (localNoofEntry - (NUMBER_OF_ENTRY_TO_RETRIEVE * 2 * mRetrievePageNumber) > 0) {
                            mLoadingMore = Gongdispatch.retrieveSheetAndName(remoteNoofEntry,
                                    mGongInfoLookupList,
                                    mRetrievePageNumber,
                                    remoteNoofEntry > localNoofEntry
                                            ? remoteNoofEntry - localNoofEntry
                                            : 0,
                                    GongInfoContract.buildUriWithNamePathAndName(mEntity_name),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE * 2,
                                    mCurrentContext,
                                    mEntity_name
                            );
                            mRetrievePageNumber++;
                        }
                        LogUtil.debug(TAG, " onscrollstatechanged 11 mRetrievePageNumber=" + mRetrievePageNumber);

                    } else {
                        Toast.makeText(mCurrentContext, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }
                }

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

            }
        });




        mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);
        mSwipeRefreshLayout.setDistanceToTriggerSync(32);
        mSwipeRefreshLayout.setNestedScrollingEnabled(true);
        mSwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        LogUtil.debug(TAG, "onRefresh called from SwipeRefreshLayout 1 ");
                        if ( isOnline()) {
                            mCursorGongInfoLookup.moveToPosition(0);
                            if (mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY) > 0) {
                                Gongdispatch.retrieveSheetAndName(mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY),
                                        mGongInfoLookupList,
                                        0,
                                        0,
                                        GongInfoContract.buildUriWithNamePathAndName(mEntity_name),
                                        "H",
                                        NUMBER_OF_ENTRY_TO_RETRIEVE,
                                        mCurrentContext,
                                        mEntity_name
                                );
                                mRetrievePageNumber = 0;

                                //((FilterFragment.CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceListAfterSwipe();

                                mRefreshingLayout = true;
                            } else {
                                mSwipeRefreshLayout.setRefreshing(false);
                                mRefreshingLayout = false;
                                showNoNewsView();

                            }
                        } else {
                            LogUtil.debug(TAG, "onRefresh called from SwipeRefreshLayout 3");
                            Toast.makeText(mCurrentContext, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                            mSwipeRefreshLayout.setRefreshing(false);
                            mRefreshingLayout = false;

                        }
                    }
                }
        );





        mCollapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        mCollapsingToolbarLayout.setExpandedTitleColor(getResources().getColor(android.R.color.transparent));


        AppBarLayout appBarLayout = (AppBarLayout) findViewById(R.id.app_bar_layout);
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = false;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                LogUtil.debug(TAG, "vertical - scrollRange=" + scrollRange + ", verticalOffset=" + verticalOffset +",isshow="+ isShow);

                if (scrollRange + verticalOffset == 0) {
                    //fully collapsed the actionbar to the top

                    mCollapsingToolbarLayout.setTitle(mEntity_name);
                    mCollapsingToolbarLayout.setTitleEnabled(true);

                    isShow = true;
                    LogUtil.debug(TAG, "vertical 0 ");
                } else if(isShow) {
                    //either dragging or expanding.
                    //collapsingToolbarLayout.setTitle(" vertical1");//carefull there should a space between double quote otherwise it wont work
                    mCollapsingToolbarLayout.setTitleEnabled(false);

                    isShow = false;
                    LogUtil.debug(TAG, "vertical 1 ");
                } else {
                    LogUtil.debug(TAG, "vertical 2 ");
                    mCollapsingToolbarLayout.setTitleEnabled(false);

                }
                LogUtil.debug(TAG, "vertical 3 ");
            }
        });


        TextView sourcetitle = (TextView) findViewById(R.id.sourcetitle);
        sourcetitle.setText(mEntity_name);

        mNoNewsHimHer = (TextView) findViewById(R.id.tv_no_news_for_him_her);




        LogUtil.debug(TAG, "oncreateview 4 ");
        getSupportLoaderManager().initLoader(ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_GONGINFO_NAME_NAME_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_ARTICLELOOKUP_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_SIGNAL_LOADER, null, this);

        LogUtil.debug(TAG, "oncreateview 5 ");

        mRetrievePageNumber = 0;


    }

    private void showLoading() {
        /* Then, hide the weather data */
        LogUtil.debug(TAG, " showloading ");
        mRecyclerView.setVisibility(View.INVISIBLE);
        /* Finally, show the loading indicator */
        mLoadingIndicator.setVisibility(View.VISIBLE);
        mNoNewsHimHer.setVisibility(View.INVISIBLE);
    }
    private void showDataView() {
        /* First, hide the loading indicator */
        LogUtil.debug(TAG, " showdatashow ");
        mLoadingIndicator.setVisibility(View.INVISIBLE);
        /* Finally, make sure the weather data is visible */
        mRecyclerView.setVisibility(View.VISIBLE);
        mNoNewsHimHer.setVisibility(View.INVISIBLE);
    }
    private void showNoNewsView() {
        /* First, hide the loading indicator */
        LogUtil.debug(TAG, " showNoNewsView ");
        mLoadingIndicator.setVisibility(View.INVISIBLE);
        /* Finally, make sure the weather data is visible */
        mRecyclerView.setVisibility(View.INVISIBLE);
        mNoNewsHimHer.setVisibility(View.VISIBLE);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        LogUtil.debug(TAG, "----> oncreateloader ");
        switch (id) {
            case ID_GONGINFO_NAME_NAME_LOADER :
                Uri gonginfoQueryUri = GongInfoContract.buildUriWithNamePathAndName(mEntity_name);
                LogUtil.debug(TAG, "----> oncreateloader 1");

                return new CursorLoader(this,
                        gonginfoQueryUri,
                        null,
                        null,
                        null,
                        null);

            case ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER :
                Uri gonginfolookupQueryUri = GongInfoLookupContract.buildUriWithNamePathAndName(mEntity_name);
                String gonginfolookupsortOrder = GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SHEETID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                return new CursorLoader(this,
                        gonginfolookupQueryUri,
                        GongInfoLookupContract.PROJECTION,
                        null,
                        null,
                        gonginfolookupsortOrder);


            case ID_ARTICLELOOKUP_LOADER:
                Uri articlelookupQueryUri = ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI;
                String articlelookupsortOrder = ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                return new CursorLoader(this,
                        articlelookupQueryUri,
                        ArticleLookupTableContract.PROJECTION,
                        null,
                        null,
                        articlelookupsortOrder);

            case ID_SIGNAL_LOADER:
            default :
                if (id != ID_SIGNAL_LOADER){
                    Log.w(TAG, "Loader Not Implemented: " + id);
                }
                Uri signalQueryUri = SignalContract.SignalEntry.CONTENT_URI;
                String signalsortOrder = SignalContract.SignalEntry.COLUMN_ARTICLE_ID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 3");

                return new CursorLoader(this,
                        signalQueryUri,
                        SignalContract.PROJECTION,
                        null,
                        null,
                        signalsortOrder);



            //default:
            //    throw new RuntimeException("Loader Not Implemented: " + id);
        }


    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, " gongnewsdetailactivity  onloadfinished 1 ");

        switch (loader.getId()) {
            case ID_GONGINFO_NAME_NAME_LOADER :
                LogUtil.debug(TAG, "  ID_GONGINFO_NAME_NAME_LOADER onloadfinished 1.1 ");

                if ( (data == null) || ((data != null) && (data.getCount() == 0) )){
                    if ( ((data != null) && (data.getCount() == 0) ) && (mPosition == 0)){
                        //it is really no data to show
                        LogUtil.debug(TAG, " ID_GONGINFO_NAME_NAME_LOADER onloadfinished 1.1.1 ");
                        mFirstLevelNewsAdapter.swapCursor(null, false);
                        showNoNewsView();
                        mRefreshingLayout = false;

                        break;

                    }
                    //go get data
                    showLoading();
                    if ( isOnline()) {
                        if (mCursorGongInfoLookup == null){
                            LogUtil.debug(TAG, "  ID_GONGINFO_NAME_NAME_LOADER onloadfinished 1.2 ");

                            //well restart and checkagain , wait for infolookup
                            getSupportLoaderManager().restartLoader(ID_GONGINFO_NAME_NAME_LOADER, null, this);
                            mRefreshingLayout = true;
                            break;

                        } else {

                            LogUtil.debug(TAG, "  ID_GONGINFO_NAME_NAME_LOADER onloadfinished 1.3 ");
                            mCursorGongInfoLookup.moveToPosition(0);
                            if (mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY) > 0) {
                                Gongdispatch.retrieveSheetAndName(mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY),
                                        mGongInfoLookupList,
                                        0,
                                        0,
                                        GongInfoContract.buildUriWithNamePathAndName(mEntity_name),
                                        "H",
                                        NUMBER_OF_ENTRY_TO_RETRIEVE,
                                        mCurrentContext,
                                        mEntity_name
                                );
                                mRefreshingLayout = true;
                            } else {
                                LogUtil.debug(TAG, "  ID_GONGINFO_NAME_NAME_LOADER onloadfinished 1.4 ");

                                mRefreshingLayout = false;
                                mFirstLevelNewsAdapter.swapCursor(null, false);
                                showNoNewsView();

                            }
                        }
                        mRetrievePageNumber = 0;


                        //((FilterFragment.CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceListAfterSwipe();

                        mPosition =0;
                    } else {
                        LogUtil.debug(TAG, " onloadfinished ID_GONGINFO_NAME_NAME_LOADER 1.5");
                        Toast.makeText(mCurrentContext, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                        mSwipeRefreshLayout.setRefreshing(false);
                        mRefreshingLayout = false;
                    }

                } else {
                    if (mRefreshingLayout == true) {
                        mRefreshingLayout = false;
                        mSwipeRefreshLayout.setRefreshing(false);

                        //mSwipeRefreshLayout.setEnabled(true);
                        LogUtil.debug(TAG, "  onloadfinished ID_GONGINFO_NAME_NAME_LOADER 2 ");

                    }
                    LogUtil.debug(TAG, " onloadfinished ID_GONGINFO_NAME_NAME_LOADER 3 ");
                    mFirstLevelNewsAdapter.swapCursor(data, false);
                    mLoadingMore = false;
                    LogUtil.debug(TAG, "  onloadfinished ID_GONGINFO_NAME_NAME_LOADER 4 ");

                    if (mPosition == RecyclerView.NO_POSITION) {
                        //it means there are some data in the database
                        //check whether there are more new news
                        //int prefNoofentry = GongPreference.getLastUpdateNoOfEntry(this, mEntity_name);
                        LogUtil.debug(TAG, "  onloadfinished ID_GONGINFO_NAME_NAME_LOADER 4.1 ");

                        if (mCursorGongInfoLookup != null){
                            mCursorGongInfoLookup.moveToPosition(0);

                            Gongdispatch.retrieveSheetAndName(mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY),
                                    mGongInfoLookupList,
                                    0,
                                    0,
                                    GongInfoContract.buildUriWithNamePathAndName(mEntity_name),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                                    mCurrentContext,
                                    mEntity_name
                            );
                        }
                        mPosition = 0;
                    } else if (mPosition >= 0) {

                            //(mPosition == RecyclerView.NO_POSITION){
                            //mPosition = data.getCount();
                            mRecyclerView.smoothScrollToPosition(0);
                        mCursorGongInfoLookup.moveToPosition(0);
                        LogUtil.debug(TAG, "  onloadfinished ID_GONGINFO_NAME_NAME_LOADER 4.2 ");

                        GongPreference.setLastUpdateNoOfEntry(this,
                                    mCursorGongInfoLookup.getInt(GongInfoLookupContract.INDEX_NOOFENTRY),
                                    mEntity_name );

                    }
                    LogUtil.debug(TAG, "  onloadfinished ID_GONGINFO_NAME_NAME_LOADER 5 data.getcount=" + data.getCount());
                    if (data.getCount() != 0) showDataView();
                }

                break;

            case ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER :
                LogUtil.debug(TAG, " newsfragment onloadinfished ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER 1 ");
                if ( (data != null) && (data.getCount() > 0) ){
                    mCursorGongInfoLookup =data;
                    for (int index=0 ; index < data.getCount(); index++){
                        data.moveToPosition(index);
                        mGongInfoLookupList.put(
                                data.getString(GongInfoLookupContract.INDEX_SHEETID),
                                data.getString(GongInfoLookupContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, " newsfragment onloadinfished ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER 2 index="
                                + index
                                + ", sheetid="
                                + data.getString(GongInfoLookupContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(GongInfoLookupContract.INDEX_SHEETID_URL)
                        );

                    }
                    GlideApp.with(this)
                            .load( mCursorGongInfoLookup.getString(GongInfoLookupContract.INDEX_SOURCEICONURL))
                            .placeholder(R.drawable.ic_tmp_icon)
                            //.transform(new MultiTransformation(new BlurTransformation(3), new CropTransformation(0,300)))
                            //.apply(new RequestOptions().transform(new BlurTransformation(50)))
                            //.fitCenter()
                            .centerCrop()
                            .into((ImageView)findViewById(R.id.entity_image));

                } else {
                    LogUtil.debug(TAG, " newsfragment onloadinfished ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER getcount=0");
                }
                LogUtil.debug (TAG, " ID_GONGINFOLOOKUP_NAME_TYPE_NAME_LOADER  mGongInfoLookupList=" + mGongInfoLookupList.toString());
                break;




            case ID_ARTICLELOOKUP_LOADER:
                if ( (data != null) && (data.getCount() > 0) ){
                    for (int index=0 ; index < data.getCount(); index++){
                        data.moveToPosition(index);
                        mArticleLookupList.put(
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID),
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, " gongnewsdetailactivity onloadinfished articlelookup_loader index="
                                + index
                                + ", sheetid="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, " gongnewsdetailactivity onloadinfished articlelookup_loader getcount=0");
                }
                LogUtil.debug (TAG, " ID_ARTICLELOOKUP_LOADER mArticleLookupList=" + mArticleLookupList.toString());

                break;
            case ID_SIGNAL_LOADER :
                mFirstLevelNewsAdapter.updateSignalMapFromCursor(data);
                //getActivity().getSupportLoaderManager().destroyLoader(ID_SIGNAL_LOADER);
                LogUtil.debug(TAG, " gongnewsdetailactivity onloadfinished 9 loaderid=" + loader.getId());


                break;



            default:
                LogUtil.debug(TAG, " gongnewsdetailactivity onloadfinished 10 loaderid=" + loader.getId());
                break;
        }

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        LogUtil.debug(TAG, "----> onloaderreset 1 loader.getid=" + loader.getId());
        if (loader.getId() == ID_GONGINFO_NAME_NAME_LOADER ) {
            LogUtil.debug(TAG, "----> onloaderreset 2 loader.getid=" + loader.getId());
            mFirstLevelNewsAdapter.swapCursor(null, false);
        }
    }

    @Override
    public void onClickDetailNews(long entryID, String finalurl) {
        for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()){

            if (    (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                    &&  ( entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()) ) ){

                LogUtil.debug( TAG, "  --> onClickDetailNews 1 entryID=" + entryID);
                Intent intent = new Intent(this, DetailNewsActivity.class);
                intent.putExtra(DetailNewsActivity.SHEET_ID, mapentry.getValue());
                intent.putExtra(DetailNewsActivity.ARTICLE_ID, entryID);
                intent.putExtra(DetailNewsActivity.FINALURL, finalurl);
                intent.putExtra(DetailNewsActivity.ROWID, entryID -
                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1);
                startActivity(intent);
                LogUtil.debug( TAG, "  --> onClickDetailNews 2 entryID=" + entryID);

                break;
            }
        }
        LogUtil.debug(TAG, " --> onClickDetailNews 3 ");


    }

    @Override
    public void onClickExpandNews(String jsonArticleList, String jsonSignalbit) {
        Intent intent = new Intent(this, ExpandNewsActivity.class);
        intent.putExtra(ExpandNewsActivity.JSONARTICLELISTSTR, jsonArticleList);
        intent.putExtra(ExpandNewsActivity.JSONSIGNALBITSTR, jsonSignalbit);
        startActivity(intent);
        LogUtil.debug(TAG, " --> onClickExpandNews 1 ");

    }

    @Override
    public void onClickBookmarkArticleStoreOrRemove(long entryID, boolean save) {
        if (save) {
            for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

                if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                        && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                    LogUtil.debug(TAG, "  --> onClickBookmarkArticleStoreOrRemove 1 entryID=" + entryID);
                    if (Gongdispatch.isOnline(this)){
                    Gongdispatch.gsheetfetchOneEntry(this,
                            mapentry.getValue(),
                            entryID -
                                    (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                            entryID);
                    } else {
                        Gongdispatch.gongdispatchOneEntry(this,
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);

                        Toast.makeText(this, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }


                    LogUtil.debug(TAG, "  --> onClickBookmarkArticleStoreOrRemove 2 entryID=" + entryID);
                    break;
                }
            }
            LogUtil.debug(TAG, " --> onClickBookmarkArticleStoreOrRemove 3 ");
        }else {
            //remove
            Uri removeindIDURI = ArticleTableContract.buildArticleUriWithID(entryID);
            String selection = " " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " == ? ";

            int result  = getContentResolver().delete(
                    removeindIDURI,
                    selection,
                    null);
            LogUtil.debug(TAG, " --> onClickBookmarkArticleStoreOrRemove 4 result= " + result);

        }


    }

    public boolean isOnline() {
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }



}
