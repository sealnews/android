package com.hk.gonggongnews.ngogong.util;

import java.util.Map;

/**
 * Created by ismile on 11/24/2017.
 */

public class GongInfo {


    private String mType;
    private String mName;
    private int mID;
    private String mSourceIconURL;
    private int mNoOfEntry;
    private long mLastUpdatetime;
    private Map<String, String> mSheetIDWithURL;
    //private String mSheetID;
    //private String mSheetIDURL;

    public GongInfo(
            String type,
            String name,
            int id,
            String sourceIconURL,
            int noOfEntry,
            long lastUpdatetime,
            Map<String, String> sheetidWithURL
    ){
        mType = type;
        mName =  name;
        mID = id;
        mSourceIconURL = sourceIconURL;
        mNoOfEntry = noOfEntry;
        mLastUpdatetime = lastUpdatetime;
        mSheetIDWithURL = sheetidWithURL;
        //mSheetID = sheetID;
        //mSheetIDURL = sheetIDURL;

    }

    public String getType(){
                return mType;
    }

    public String getName(){
        return mName;
    }

    public int getid(){
        return mID;
    }

    public String getSourceIconURL(){
        return mSourceIconURL;
    }

    public int getNoOfEntry(){
        return mNoOfEntry;
    }

    public long getLastUpdateTime(){
        return mLastUpdatetime;
    }

    public Map<String, String>  getSheetIDWithURL (){
        return mSheetIDWithURL;
    }




}
