package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.GongInfoContract.GongInfoEntry.CONTENT_URI;
import static com.hk.gonggongnews.ngogong.data.GongInfoContract.GongInfoEntry.CONTENT_URI_NAME;

/**
 * Created by ismile on 11/23/2017.
 */

public class GongInfoContract {
    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_GONGINFO = "gonginfo";
    public static final String PATH_NAME = "name";

    public static final int INDEX_RAWQUERY_NAME = 13;

    public static final String RAWQUERYORDERSTRING = " order by gonginfo.timestampondocandid DESC ";
    public static final String RAWQUERYGONGINFOWHEREIDSTRING = " gonginfo._id >= ? and gonginfo._id <= ? ";
    public static final String RAWQUERYGONGINFOWHERENAMESTRING = " gonginfo.name = ? ";
    public static final String RAWQUERYGONGINFOWHEREFIRSTSUBSTRING = " gonginfo.firstsubdomaintable_id == ?  ";
    public static final String RAWQUERYGONGINFOSELECTIONSTRING =
            " select gonginfo._id as gonginfo_id, "
                    + " gonginfo.finalurl as gonginfo_finalurl, "
                    + " gonginfo.timestampondoc as gonginfo_timestampondoc, "
                    + " gonginfo.title as gonginfo_title, "
                    + " gonginfo.imageurl as gonginfo_imageurl, "
                    + " gonginfo.similiaritiescount as gonginfo_similaritiescount, "
                    + " gonginfo.entry as gonginfo_entry, "
                    + " gonginfo.firstsubdomaintable_id as gonginfo_firstsubdomaintable_id, "
                    + " gonginfo.timestampondocandid as gonginfo_timestampondocandid, "
                    + " gonginfo.article_id as gonginfo_article_id, "
                    + " signal.bookmarkalready as signal_bookmarkalready, "
                    + " signal.readalready as signal_readalready, "
                    + " firstsubdomain.sourceiconurl as firstsubdomain_sourceiconurl, "
                    + " gonginfo.name as gonginfo_name "
                    + " from gonginfo "
                    + " left join firstsubdomain on gonginfo.firstsubdomaintable_id = firstsubdomain.firstsubdomaintable_id "
                    + " left join signal on gonginfo.article_id = signal.article_id ";
    public static final String RAWQUERYGONGINFORANGESTRING = RAWQUERYGONGINFOSELECTIONSTRING
            + " where " + RAWQUERYGONGINFOWHEREIDSTRING
            + RAWQUERYORDERSTRING;
    public static final String RAWQUERYGONGINFONAMESTRING = RAWQUERYGONGINFOSELECTIONSTRING
            + " where " + RAWQUERYGONGINFOWHERENAMESTRING
            + RAWQUERYORDERSTRING;


    public static final class GongInfoEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_GONGINFO)
                .build();

        public static final Uri CONTENT_URI_NAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_GONGINFO)
                .appendPath(PATH_NAME)
                .build();


        public static final String TABLE_NAME = "gonginfo";

        public static final String COLUMN_TIMESTAMPONDOC_AND_ID = "timestampondocandid";
        public static final String COLUMN_ARTICLEID = "article_id";
        public static final String COLUMN_TIMESTAMPONDOC = "timestampondoc";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_FINALURL = "finalurl";
        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_IMAGEURL = "imageurl";
        public static final String COLUMN_SIMILARITIESCOUNT = "similiaritiescount";
        public static final String COLUMN_ENTRY = "entry";
        public static final String COLUMN_NAME= "name";

    }

    public static Uri buildPaginationUriWithTimestampondocAndId(String timestampondocandid) {
        return CONTENT_URI.buildUpon()
                .appendPath(timestampondocandid)
                .build();
    }

    public static String decodeGetTimestampondoc(String timestampondocandid) {
        String timestamp = timestampondocandid.split("Z")[0];
        return timestamp;
    }

    public static String decodeGetId(String timestampondocandid) {
        String id = timestampondocandid.split("Z")[1];
        return id;
    }


    public static Uri buildUriWithNamePathAndName ( String name) {
        return CONTENT_URI_NAME.buildUpon()
                .appendPath(name)
                .build();
    }

}
