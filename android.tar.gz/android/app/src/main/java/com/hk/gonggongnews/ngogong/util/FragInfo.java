package com.hk.gonggongnews.ngogong.util;

import android.content.Context;

import com.hk.gonggongnews.ngogong.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 12/6/2017.
 */

public class FragInfo {

    //private static Map<String, FragInfoElem> FRAGINFO_MAP = new HashMap<String, FragInfoElem>();
    //private static Map<String, String> FRAGINFO_ARCHIVEMAP = new HashMap<String, String>();
    //private static List<FragInfoElem> FRAGINFO_TABLIST = new ArrayList<FragInfoElem>();
    private static Map<String, FragInfoElem> FRAGINFO_MAP ;
    private static Map<String, String> FRAGINFO_ARCHIVEMAP ;
    private static List<FragInfoElem> FRAGINFO_TABLIST ;

    public class FragInfoElem  {
        private String displayName;
        private int category_id;
        private String fragtablename;
        private int startingLoaderID;

        public FragInfoElem  (String dName, int cid, String fname, int sloaderid){
            displayName = dName;
            category_id = cid;
            fragtablename = fname;
            startingLoaderID = sloaderid;
        }

        public int  get_CategoryID (){
            return category_id;
        }
        public String  get_name (){
            return displayName;
        }
        public String  get_fragtablename(){
            return fragtablename;
        }
        public String get_noofentrynamelocal(){
            return fragtablename + "_local_noofentry";
        }
        public String get_noofentrynameremote(){
            return fragtablename + "_remote_noofentry";
        }
        public String get_lastupdatetimename(){
            return fragtablename + "_local_lastupdatetime";
        }
        public int getStartingLoaderID(){
            return startingLoaderID;
        }
    }

    static {

    }

    private static FragInfo mInstance=null;
    private static Context mContext=null;

    public static void init(Context context) {
        mContext = context;
        mInstance = new FragInfo(context);
    }

    public static FragInfo getInstance() {
        if (mInstance == null) {
            mInstance = new FragInfo(mContext);
            return mInstance;
        } else {
            return mInstance;
        }
    }

    public static FragInfo getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new FragInfo(context);
            return mInstance;
        } else {
            return mInstance;
        }
    }


    private FragInfo (Context context){
        mContext = context;
        FRAGINFO_MAP = new HashMap<String, FragInfoElem>();
        FRAGINFO_ARCHIVEMAP = new HashMap<String, String>();
        FRAGINFO_TABLIST = new ArrayList<FragInfoElem>();

        FRAGINFO_MAP.clear();
        FRAGINFO_MAP.put("hklatestnewstable", new FragInfoElem(mContext.getString(R.string.fraginfo_hklatestnews), 3, "hklatestnewstable", 1000));
        FRAGINFO_MAP.put("hknewstable", new FragInfoElem(mContext.getString(R.string.fraginfo_hknews), 2, "hknewstable", 1100));
        FRAGINFO_MAP.put("finlatestnewstable", new FragInfoElem(mContext.getString(R.string.fraginfo_finlatestnews), 5, "finlatestnewstable", 1200));
        FRAGINFO_MAP.put("finnewstable", new FragInfoElem(mContext.getString(R.string.fraginfo_finnews), 6, "finnewstable", 1300));
        FRAGINFO_MAP.put("entnewstable", new FragInfoElem(mContext.getString(R.string.fraginfo_entnews), 8, "entnewstable", 1400));
        FRAGINFO_MAP.put("sportsnewstable", new FragInfoElem(mContext.getString(R.string.fraginfo_sportsnews), 7, "sportsnewstable", 1500));
        FRAGINFO_MAP.put("sportsnewsarchivetable", new FragInfoElem(mContext.getString(R.string.fraginfo_sportsnewsarchive), 7, "sportsnewsarchivetable", 1500));
        FRAGINFO_MAP.put("entnewsarchivetable", new FragInfoElem(mContext.getString(R.string.fraginfo_entnewsarchive), 8, "entnewsarchivetable", 1400));
        FRAGINFO_MAP.put("finnewsarchivetable", new FragInfoElem(mContext.getString(R.string.fraginfo_finnewsarchive), 6, "finnewsarchivetable", 1300));
        FRAGINFO_MAP.put("hknewsarchivetable", new FragInfoElem(mContext.getString(R.string.fraginfo_hknewsarchive), 2, "hknewsarchivetable", 1100));
        FRAGINFO_MAP.put("finlatestnewsarchivetable", new FragInfoElem(mContext.getString(R.string.fraginfo_finlatestnewsarchive), 5, "finlatestnewsarchivetable", 1200));

        FRAGINFO_ARCHIVEMAP.clear();
        FRAGINFO_ARCHIVEMAP.put("hknewstable", "hknewsarchivetable");
        FRAGINFO_ARCHIVEMAP.put("finlatestnewstable", "finlatestnewsarchivetable");
        FRAGINFO_ARCHIVEMAP.put("finnewstable", "finnewsarchivetable");
        FRAGINFO_ARCHIVEMAP.put("entnewstable", "entnewsarchivetable");
        FRAGINFO_ARCHIVEMAP.put("sportsnewstable", "sportsnewsarchivetable");

        FRAGINFO_TABLIST.clear();
        FRAGINFO_TABLIST.add(FRAGINFO_MAP.get("hklatestnewstable"));
        FRAGINFO_TABLIST.add(FRAGINFO_MAP.get("hknewstable"));
        FRAGINFO_TABLIST.add(FRAGINFO_MAP.get("finlatestnewstable"));
        FRAGINFO_TABLIST.add(FRAGINFO_MAP.get("finnewstable"));
        FRAGINFO_TABLIST.add(FRAGINFO_MAP.get("entnewstable"));
        FRAGINFO_TABLIST.add(FRAGINFO_MAP.get("sportsnewstable"));


    }

    //FragInfo.getInstance().get_archivecategory(mFragment_name)
    public int get_archivecategory(String indexname) {
        return FRAGINFO_MAP.get(FRAGINFO_ARCHIVEMAP.get(indexname)).get_CategoryID();
    }

    //FragInfo.getInstance().get_archivetablename(mFragment_name)
    public String get_archivetablename(String indexname){
        return FRAGINFO_ARCHIVEMAP.get(indexname);
    }

    //FragInfo.getInstance().get_archivenoofentryname(mFragment_name)
    public String get_archivenoofentrynamelocal(String indexname) {
        return FRAGINFO_MAP.get(FRAGINFO_ARCHIVEMAP.get(indexname)).get_noofentrynamelocal();
    }

    //FragInfo.getInstance().get_noofentryname(mFragment_name)
    public String get_noofentrynamelocal(String indexname) {
        return FRAGINFO_MAP.get(indexname).get_noofentrynamelocal();
    }

    public String get_noofentrynameremote(String indexname) {
        return FRAGINFO_MAP.get(indexname).get_noofentrynameremote();
    }


    //FragInfo.getInstance().get_startingloaderid(name)
    public int get_startingloaderid(String indexname) {
        return FRAGINFO_MAP.get(indexname).getStartingLoaderID();
    }

    //FragInfo.getInstance().get_category(mFragment_name)
    //FragInfo.getInstance().get_category(name)
    public int get_category(String indexname) {
        return FRAGINFO_MAP.get(indexname).get_CategoryID();
    }

    //FragInfo.getInstance().get_category(position)
    public int get_category(int position) {
        return FRAGINFO_TABLIST.get(position).get_CategoryID();
    }

    //FragInfo.getInstance().get_name(position)
    public String get_tablistname (int position){
        return FRAGINFO_TABLIST.get(position).get_name();
    }

    //FragInfo.getInstance().get_tablistSize()
    public int get_tablistSize() {
        return FRAGINFO_TABLIST.size();
    }
    //FragInfo.getInstance().get_tablistFragTableName(position)
    public String get_tablistFragTableName(int position){
        return FRAGINFO_TABLIST.get(position).get_fragtablename();
    }


}
