package com.hk.gonggongnews.ngogong.sync;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import com.firebase.jobdispatcher.Constraint;
import com.firebase.jobdispatcher.Driver;
import com.firebase.jobdispatcher.FirebaseJobDispatcher;
import com.firebase.jobdispatcher.GooglePlayDriver;
import com.firebase.jobdispatcher.Job;
import com.firebase.jobdispatcher.JobTrigger;
import com.firebase.jobdispatcher.Lifetime;
import com.firebase.jobdispatcher.Trigger;
import com.hk.gonggongnews.ngogong.GlideApp;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.CategoryTableContract;
import com.hk.gonggongnews.ngogong.data.FragLookupTableContract;
import com.hk.gonggongnews.ngogong.data.GongInfoLookupContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationArcContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by ismile on 10/11/2017.
 */

public class Gongdispatch {
    private final static String TAG = Gongdispatch.class.getSimpleName();

    private static final int SYNC_INTERVAL_HOURS = 3;
    private static final int SYNC_INTERVAL_SECONDS = (int) TimeUnit.HOURS.toSeconds(SYNC_INTERVAL_HOURS);
    private static final int SYNC_FLEXTIME_SECONDS = SYNC_INTERVAL_SECONDS + SYNC_INTERVAL_SECONDS / 2;
    private static final int SYNC_INTERVAL_SECONDS_INITIAL = 20;
    private static final int SYNC_FLEXTIME_SECONDS_INITIAL = SYNC_INTERVAL_SECONDS_INITIAL + SYNC_INTERVAL_SECONDS_INITIAL / 2;

    private static final long MINLATENCY = 500;
    private static final long OVERRIDETIME = 1000;

    private static boolean sInitialized=false;
    private static boolean gongnewsInitialized=false;
    private static boolean fragInitialized=false;

    private static final String GONG_SYNC_INITIAL_TAG = "gong_sync_initial_tag";
    private static final String GONG_SYNC_SCHEDULE_TAG = "gong_sync_schedule_tag";
    private static final String GONGNEWS_SYNC_INITIAL_TAG = "gongnews_sync_initial_tag";
    private static final String GONGNEWS_SYNC_SCHEDULE_TAG = "gongnews_sync_schedule_tag";
    private static final String FRAG_SYNC_NOW_TAG = "gongnews_sync_now_tag";
    private static final String FRAG_SYNC_INITIAL_TAG = "gongnews_sync_initial_tag";
    private static final String GONG_SYNC_ONE_ENTRY_TAG = "gong_sync_one_entry_tag";
    private static final String GONG_UPGRADE_CHECK_TAG = "gong_upgrade_check_tag";

    private static final int GONG_SYNC_INITIAL_JOBID = 10000;
    private static final int GONG_SYNC_SCHEDULE_JOBID = 10001;
    private static final int GONGNEWS_SYNC_INITIAL_JOBID = 10002;
    private static final int GONGNEWS_SYNC_SCHEDULE_JOBID = 10003;
    private static final int FRAG_SYNC_NOW_JOBID = 10004;
    private static final int FRAG_SYNC_INITIAL_JOBID = 10005;
    private static final int GONG_SYNC_ONE_ENTRY_JOBID = 1006;


    public static final String SHEET_ID = "sheet_id";
    public static final String ROW_ID  = "row_id";
    public static final String ARTICLE_ID  = "article_id";

    public static final int ENTRYPERSHEET = 33000;


    /**
     * Schedules a repeating sync of Sunshine's weather data using FirebaseJobDispatcher.
     *
     * @param context Context used to create the GooglePlayDriver that powers the
     *                FirebaseJobDispatcher
     */
    static void gongdispatchFirebaseJobDispatcher_now(@NonNull final Context context) {
        /*
        JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
                0,
                0);

        gongdispatchFirebaseJobDispatcher(context, GONG_SYNC_INITIAL_TAG,
                false, trigger
        );
        */
        gongdispatchFirebaseJobDispatcher(context, GONG_SYNC_INITIAL_JOBID ,
                MINLATENCY,
                OVERRIDETIME);
    }

    static void gongdispatchFirebaseJobDispatcher_initial(@NonNull final Context context) {

        /*
        JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
                SYNC_INTERVAL_SECONDS_INITIAL,
                SYNC_FLEXTIME_SECONDS_INITIAL);
        gongdispatchFirebaseJobDispatcher(context, GONG_SYNC_INITIAL_TAG,
                false, trigger);
                */
        gongdispatchFirebaseJobDispatcher(context, GONG_SYNC_INITIAL_JOBID ,
                (long) SYNC_INTERVAL_SECONDS_INITIAL,
                (long) SYNC_FLEXTIME_SECONDS_INITIAL);

    }

    static void gongdispatchFirebaseJobDispatcher_schedule(@NonNull final Context context) {
        JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
                SYNC_INTERVAL_SECONDS,
                SYNC_FLEXTIME_SECONDS);
        gongdispatchFirebaseJobDispatcher(context, GONG_SYNC_SCHEDULE_TAG,
                true, trigger);
    }


    static void gongdispatchFirebaseJobDispatcher(@NonNull final Context context,
                                                  int jobid,
                                                  long minLatency,
                                                  long overridetime
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFirebaseJobDispatcher 1");
        ComponentName mServiceComponent = new ComponentName(context, FirebaseJobService.class);
        JobInfo.Builder builder = new JobInfo.Builder(jobid, mServiceComponent);
        builder.setPersisted(true)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setRequiresDeviceIdle(false)
                .setOverrideDeadline(overridetime)
                .setMinimumLatency(minLatency);

        JobScheduler tm = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        int result = tm.schedule(builder.build());
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFirebaseJobDispatcher 4=" + result );


    }




    static void gongdispatchFirebaseJobDispatcher(@NonNull final Context context,
                                                  String tagname,
                                                  boolean recurring,
                                                  JobTrigger trigger
    ) {
/*
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFirebaseJobDispatcher 1");
        Bundle trybundle = new Bundle();
        trybundle.putCharSequence("hello1", "world1");
        Driver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(driver);

        // Create the Job to periodically sync Sunshine
        Job syncJob = dispatcher.newJobBuilder()
                // The Service that will be used to sync Sunshine's data
//                .setService(FirebaseJobService.class)
                .setService(FirebaseJobServiceFrag.class)
                // Set the UNIQUE tag used to identify this Job
                .setTag(tagname)
                //
                // Network constraints on which this Job should run. We choose to run on any
                // network, but you can also choose to run only on un-metered networks or when the
                // device is charging. It might be a good idea to include a preference for this,
                // as some users may not want to download any data on their mobile plan. ($$$)
                //
                .setConstraints(Constraint.ON_ANY_NETWORK)
                //
                // setLifetime sets how long this job should persist. The options are to keep the
                // Job "forever" or to have it die the next time the device boots up.
                //
                .setLifetime(Lifetime.UNTIL_NEXT_BOOT)
                //
                // We want Sunshine's weather data to stay up to date, so we tell this Job to recur.
                //
                .setRecurring(recurring)
                //
                //We want the weather data to be synced every 3 to 4 hours. The first argument for
                //Trigger's static executionWindow method is the start of the time frame when the
                //sync should be performed. The second argument is the latest point in time at
                //which the data should be synced. Please note that this end time is not
                //guaranteed, but is more of a guideline for FirebaseJobDispatcher to go off of.
                //
                .setTrigger(trigger)
//                        Trigger.executionWindow(
//                        start_sync_time,
//                        range_sync_time))
//                .setTrigger(Trigger.NOW)
                //
                // * If a Job with the tag with provided already exists, this new job will replace
                // * the old one.
                //
                .setReplaceCurrent(true)

                //put extra information to the job
                .setExtras(trybundle)
                // Once the Job is ready, call the builder's build method to return the Job
                .build();

        // Schedule the Job with the dispatcher
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFirebaseJobDispatcher 2");
        //int return_sch = dispatcher.schedule(syncJob);
        //LogUtil.debug(TAG, "in Gongdispatch gongdispatchFirebaseJobDispatcher 3=" + return_sch);


        long millslatency = 2000;
        ComponentName mServiceComponent = new ComponentName(context, FirebaseJobService.class);
        JobInfo.Builder builder = new JobInfo.Builder(10001, mServiceComponent);
        builder.setPersisted(true)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setRequiresDeviceIdle(false)
                .setOverrideDeadline(3 * millslatency)
                .setMinimumLatency(millslatency);

        JobScheduler tm = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        int result = tm.schedule(builder.build());
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFirebaseJobDispatcher 4=" + result );

*/

    }

    /**
     * Creates periodic sync tasks and checks to see if an immediate sync is required. If an
     * immediate sync is required, this method will take care of making sure that sync occurs.
     *
     * @param context Context that will be passed to other methods and used to access the
     *                ContentResolver
     */
    synchronized public static void initialize(@NonNull final Context context) {
        LogUtil.debug(TAG, "in Gongdispatch initialize 1");

        /*
         * Only perform initialization once per app lifetime. If initialization has already been
         * performed, we have nothing to do in this method.
         */
        //gongdispatchFirebaseJobDispatcher_schedule(context);
        LogUtil.debug(TAG, "in Gongdispatch initialize 2");

        if (sInitialized) {
            return;
        }


        sInitialized = true;
        LogUtil.debug(TAG, "in Gongdispatch initialize 3");

        /*
         * This method call triggers Sunshine to create its task to synchronize weather data
         * periodically.
         */

        /*
         * We need to check to see if our ContentProvider has data to display in our forecast
         * list. However, performing a query on the main thread is a bad idea as this may
         * cause our UI to lag. Therefore, we create a thread in which we will run the query
         * to check the contents of our ContentProvider.
         */
        Thread checkForEmpty = new Thread(new Runnable() {
            @Override
            public void run() {
                LogUtil.debug(TAG, "in Gongdispatch thread 1 ");

                /* check any table & id */
                Uri latestnewsQueryUri = LatestNewsPaginationContract.PaginationEntry.CONTENT_URI;

                /*
                 * Since this query is going to be used only as a check to see if we have any
                 * data (rather than to display data), we just need to PROJECT the ID of each
                 * row. In our queries where we display data, we need to PROJECT more columns
                 * to determine what weather details need to be displayed.
                 */
                String[] projectionColumns = {LatestNewsPaginationContract.PaginationEntry._ID};

                /* Here, we perform the query to check to see if we have any weather data */
                Cursor cursor = context.getContentResolver().query(
                        latestnewsQueryUri,
                        projectionColumns,
                        null,
                        null,
                        null);
                LogUtil.debug(TAG, "in Gongdispatch thread 2 ");

                /*
                 * A Cursor object can be null for various different reasons. A few are
                 * listed below.
                 *
                 *   1) Invalid URI
                 *   2) A certain ContentProvider's query method returns null
                 *   3) A RemoteException was thrown.
                 *
                 * Bottom line, it is generally a good idea to check if a Cursor returned
                 * from a ContentResolver is null.
                 *
                 * If the Cursor was null OR if it was empty, we need to sync immediately to
                 * be able to display data to the user.
                 */

                if (null == cursor || cursor.getCount() == 0) {
                    LogUtil.debug(TAG, "in Gongdispatch thread 3 ");
                    gongdispatchFirebaseJobDispatcher_now(context);
                } else {
                    LogUtil.debug(TAG, "in Gongdispatch thread 4 ");
                    //startRegister(context);
                    gongdispatchFirebaseJobDispatcher_initial(context);
                }
                //initialize is called by OnCreate , so do the sync now
                startImmediateSync(context);
                /* Make sure to close the Cursor to avoid memory leaks! */
                LogUtil.debug(TAG, "in Gongdispatch thread 5 ");
                cursor.close();
            }
        });

        /* Finally, once the thread is prepared, fire it off to perform our checks. */
        checkForEmpty.start();
        LogUtil.debug(TAG, "in Gongdispatch initialize 4");
    }


    static void gongdispatchFJSGongNews_now(@NonNull final Context context) {
        LogUtil.debug(TAG, " gongdispatchFJSGongNews_now 1");
        //JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
        //        0,
        //        0);
        //gongdispatchFJSGongNews(context, GONGNEWS_SYNC_INITIAL_TAG,
        //        false,Trigger.NOW
        //);
        //gongdispatchFJSGongNews(context, GONGNEWS_SYNC_INITIAL_TAG,
        //        false, trigger
        //);
        gongdispatchFJSGongNews(context, GONGNEWS_SYNC_INITIAL_JOBID ,
                MINLATENCY,
                OVERRIDETIME);
    }

    static void gongdispatchFJSGongNews_schedule(@NonNull final Context context) {
        LogUtil.debug(TAG, " gongdispatchFJSGongNews_schedule 1");
        //JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
        //        SYNC_INTERVAL_SECONDS_INITIAL,
        //        SYNC_FLEXTIME_SECONDS_INITIAL);
        //gongdispatchFJSGongNews(context, GONGNEWS_SYNC_SCHEDULE_TAG,
        //        false, trigger);

        //JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
        //        SYNC_INTERVAL_SECONDS,
        //        SYNC_FLEXTIME_SECONDS);
        //gongdispatchFJSGongNews(context, GONGNEWS_SYNC_SCHEDULE_TAG,
        //        true, trigger);
        gongdispatchFJSGongNews(context, GONGNEWS_SYNC_INITIAL_JOBID ,
                (long) SYNC_INTERVAL_SECONDS_INITIAL,
                (long) SYNC_FLEXTIME_SECONDS_INITIAL);
    }

    static void gongdispatchFJSGongNews(@NonNull final Context context,
                                                  int jobid,
                                                  long minLatency,
                                                  long overridetime
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFJSGongNews 1");
        ComponentName mServiceComponent = new ComponentName(context, FirebaseJobServiceGongNews.class);
        JobInfo.Builder builder = new JobInfo.Builder(jobid, mServiceComponent);
        builder.setPersisted(true)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setRequiresDeviceIdle(false)
                .setOverrideDeadline(overridetime)
                .setMinimumLatency(minLatency);

        JobScheduler tm = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        int result = tm.schedule(builder.build());
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFJSGongNews 4=" + result );


    }


    static void gongdispatchFJSGongNews(@NonNull final Context context,
                                        String tagname,
                                        boolean recurring,
                                        JobTrigger trigger
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFJSGongNews old 1");
/*
        Bundle trybundle = new Bundle();
        trybundle.putCharSequence("hello1", "world1");
        Driver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(driver);

        // Create the Job to periodically sync Sunshine
        Job syncJob = dispatcher.newJobBuilder()
                // The Service that will be used to sync Sunshine's data
                .setService(FirebaseJobServiceGongNews.class)
                //Set the UNIQUE tag used to identify this Job
                .setTag(tagname)
                //
                // * Network constraints on which this Job should run. We choose to run on any
                // * network, but you can also choose to run only on un-metered networks or when the
                // * device is charging. It might be a good idea to include a preference for this,
                // * as some users may not want to download any data on their mobile plan. ($$$)
                // *
                .setConstraints(Constraint.ON_ANY_NETWORK)
                //
                // * setLifetime sets how long this job should persist. The options are to keep the
                // * Job "forever" or to have it die the next time the device boots up.
                // *
                .setLifetime(Lifetime.UNTIL_NEXT_BOOT)
                //
                //We want Sunshine's weather data to stay up to date, so we tell this Job to recur.
                //
                .setRecurring(recurring)
                //
                // * We want the weather data to be synced every 3 to 4 hours. The first argument for
                // * Trigger's static executionWindow method is the start of the time frame when the
                // * sync should be performed. The second argument is the latest point in time at
                // * which the data should be synced. Please note that this end time is not
                // * guaranteed, but is more of a guideline for FirebaseJobDispatcher to go off of.
                //
                .setTrigger(trigger)
//                        Trigger.executionWindow(
//                        start_sync_time,
//                        range_sync_time))
//                .setTrigger(Trigger.NOW)
                //
                // * If a Job with the tag with provided already exists, this new job will replace
                // * the old one.
                // *
                .setReplaceCurrent(true)

                //put extra information to the job
                .setExtras(trybundle)
                // Once the Job is ready, call the builder's build method to return the Job
                .build();

        // Schedule the Job with the dispatcher
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFJSGongNews 2");
        dispatcher.schedule(syncJob);
*/
    }


    synchronized public static void gongnewsinitialize(@NonNull final Context context) {
        LogUtil.debug(TAG, "in gongnewsinitialize initialize 1");


        if (gongnewsInitialized) {
            return;
        }


        gongnewsInitialized = true;
        LogUtil.debug(TAG, "in gongnewsinitialize initialize 3");

        Thread checkForEmpty = new Thread(new Runnable() {
            @Override
            public void run() {
                LogUtil.debug(TAG, "in Gongdispatch gongnewsinitialize thread 1 ");

                /* check any table & id */
                Uri gongnewsQueryUri = GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI;

                String[] projectionColumns = {GongInfoLookupContract.GongInfoLookupEntry._ID};

                /* Here, we perform the query to check to see if we have any weather data */
                Cursor cursor = context.getContentResolver().query(
                        gongnewsQueryUri,
                        projectionColumns,
                        null,
                        null,
                        null);
                LogUtil.debug(TAG, "in Gongdispatch gongnewsinitialize thread 2 ");

                /*
                 * A Cursor object can be null for various different reasons. A few are
                 * listed below.
                 *
                 *   1) Invalid URI
                 *   2) A certain ContentProvider's query method returns null
                 *   3) A RemoteException was thrown.
                 *
                 * Bottom line, it is generally a good idea to check if a Cursor returned
                 * from a ContentResolver is null.
                 *
                 * If the Cursor was null OR if it was empty, we need to sync immediately to
                 * be able to display data to the user.
                 */

                if (null == cursor || cursor.getCount() == 0) {
                    LogUtil.debug(TAG, "in Gongdispatch gongnewsinitialize thread 3 ");
                    gongdispatchFJSGongNews_now(context);
                } else {
                    LogUtil.debug(TAG, "in Gongdispatch gongnewsinitialize thread 4 ");
                    gongdispatchFJSGongNews_schedule(context);
                }
                cursor.close();
            }
        });

        /* Finally, once the thread is prepared, fire it off to perform our checks. */
        checkForEmpty.start();
        LogUtil.debug(TAG, "in Gongdispatch gongnewsinitialize 4");
    }






    static void gongdispatchFrag_now(@NonNull final Context context) {
        LogUtil.debug(TAG, " gongdispatchFrag_now 1");
        //JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
        //        0,
        //        0);
        //gongdispatchFJSGongNews(context, GONGNEWS_SYNC_INITIAL_TAG,
        //        false,Trigger.NOW
        //);
        //gongdispatchFrag(context, FRAG_SYNC_NOW_TAG,
        //        false, trigger
        //);
        gongdispatchFrag(context, FRAG_SYNC_NOW_JOBID,
                MINLATENCY,
                OVERRIDETIME);

    }

    static void gongdispatchFrag_initial(@NonNull final Context context) {
        LogUtil.debug(TAG, " gongdispatchFrag_initial 1");
        //JobTrigger.ExecutionWindowTrigger trigger = Trigger.executionWindow(
        //        SYNC_INTERVAL_SECONDS_INITIAL,
        //        SYNC_FLEXTIME_SECONDS_INITIAL);
        //gongdispatchFrag(context, FRAG_SYNC_INITIAL_TAG,
        //        false, trigger);
        gongdispatchFrag(context, FRAG_SYNC_INITIAL_JOBID,
                (long) SYNC_INTERVAL_SECONDS_INITIAL,
                (long) SYNC_FLEXTIME_SECONDS_INITIAL);

    }


    static void gongdispatchFrag(@NonNull final Context context,
                                        int jobid,
                                        long minLatency,
                                        long overridetime
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFrag 1");
        ComponentName mServiceComponent = new ComponentName(context, FirebaseJobServiceFrag.class);
        JobInfo.Builder builder = new JobInfo.Builder(jobid, mServiceComponent);
        builder.setPersisted(true)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setRequiresDeviceIdle(false)
                .setOverrideDeadline(overridetime)
                .setMinimumLatency(minLatency);

        JobScheduler tm = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        int result = tm.schedule(builder.build());
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFrag 4=" + result );


    }


    static void gongdispatchFrag(@NonNull final Context context,
                                 String tagname,
                                 boolean recurring,
                                 JobTrigger trigger
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFrag old 1");
/*
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFrag 1");
        Bundle trybundle = new Bundle();
        trybundle.putCharSequence("hello1", "world1");
        Driver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(driver);

        // Create the Job to periodically sync Sunshine
        Job syncJob = dispatcher.newJobBuilder()
                // The Service that will be used to sync Sunshine's data
                .setService(FirebaseJobServiceFrag.class)
                // Set the UNIQUE tag used to identify this Job
                .setTag(tagname)
                //
                // * Network constraints on which this Job should run. We choose to run on any
                // * network, but you can also choose to run only on un-metered networks or when the
                // * device is charging. It might be a good idea to include a preference for this,
                // * as some users may not want to download any data on their mobile plan. ($$$)
                // *
                .setConstraints(Constraint.ON_ANY_NETWORK)
                //
                // * setLifetime sets how long this job should persist. The options are to keep the
                // * Job "forever" or to have it die the next time the device boots up.
                // *
                .setLifetime(Lifetime.UNTIL_NEXT_BOOT)
                //
                //  We want Sunshine's weather data to stay up to date, so we tell this Job to recur.
                // *
                .setRecurring(recurring)
                //
                // * We want the weather data to be synced every 3 to 4 hours. The first argument for
                // * Trigger's static executionWindow method is the start of the time frame when the
                // * sync should be performed. The second argument is the latest point in time at
                // * which the data should be synced. Please note that this end time is not
                // * guaranteed, but is more of a guideline for FirebaseJobDispatcher to go off of.
                // *
                .setTrigger(trigger)
//                        Trigger.executionWindow(
//                        start_sync_time,
//                        range_sync_time))
//                .setTrigger(Trigger.NOW)
                //
                // * If a Job with the tag with provided already exists, this new job will replace
                // * the old one.
                // *
                .setReplaceCurrent(true)

                //put extra information to the job
                .setExtras(trybundle)
                // Once the Job is ready, call the builder's build method to return the Job
                .build();

        // Schedule the Job with the dispatcher
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchFrag 2");
        dispatcher.schedule(syncJob);

*/

    }


    synchronized public static void fraginitialize(@NonNull final Context context) {
        LogUtil.debug(TAG, "in fraginitialize initialize 1");


        if (fragInitialized) {
            return;
        }


        fragInitialized = true;
        LogUtil.debug(TAG, "in fraginitialize initialize 3");

        Thread checkForEmpty = new Thread(new Runnable() {
            @Override
            public void run() {
                LogUtil.debug(TAG, "in Gongdispatch fraginitialize thread 1 ");

                /* check any table & id */
                Uri fragQueryUri = GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI;

                String[] projectionColumns = {FragLookupTableContract.FragLookupEntry._ID};

                /* Here, we perform the query to check to see if we have any weather data */
                Cursor cursor = context.getContentResolver().query(
                        FragLookupTableContract.FragLookupEntry.CONTENT_URI,
                        projectionColumns,
                        null,
                        null,
                        null);
                LogUtil.debug(TAG, "in Gongdispatch fraginitialize thread 2 ");

                /*
                 * A Cursor object can be null for various different reasons. A few are
                 * listed below.
                 *
                 *   1) Invalid URI
                 *   2) A certain ContentProvider's query method returns null
                 *   3) A RemoteException was thrown.
                 *
                 * Bottom line, it is generally a good idea to check if a Cursor returned
                 * from a ContentResolver is null.
                 *
                 * If the Cursor was null OR if it was empty, we need to sync immediately to
                 * be able to display data to the user.
                 */

                if (null == cursor || cursor.getCount() == 0) {
                    LogUtil.debug(TAG, "in Gongdispatch fraginitialize thread 3 ");
                    gongdispatchFrag_now(context);
                } else {
                    LogUtil.debug(TAG, "in Gongdispatch fraginitialize thread 4 ");
                    gongdispatchFrag_initial(context);
                }
                cursor.close();
            }
        });

        /* Finally, once the thread is prepared, fire it off to perform our checks. */
        checkForEmpty.start();
        LogUtil.debug(TAG, "in Gongdispatch fraginitialize 4");
    }
















    public static void gongdispatchOneEntry(@NonNull final Context context,
                                 String sheet_id,
                                 long rowid,
                                 long articleid
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchOneEntry 1");
        //Bundle passinBundle = new Bundle();
        //passinBundle.putString(SHEET_ID, sheet_id);
        //passinBundle.putLong(ROW_ID, rowid);
        //passinBundle.putLong(ARTICLE_ID, articleid);

        PersistableBundle extras = new PersistableBundle();
        extras.putString(SHEET_ID, sheet_id);
        extras.putLong(ROW_ID, rowid);
        extras.putLong(ARTICLE_ID, articleid);
        ComponentName mServiceComponent = new ComponentName(context, FirebaseJobServiceOneEntry.class);
        JobInfo.Builder builder = new JobInfo.Builder(GONG_SYNC_ONE_ENTRY_JOBID, mServiceComponent);
        builder.setPersisted(true)
                .setExtras(extras)
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setRequiresCharging(false)
                .setRequiresDeviceIdle(false)
                .setOverrideDeadline(OVERRIDETIME)
                .setMinimumLatency(MINLATENCY);

        JobScheduler tm = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        int result = tm.schedule(builder.build());
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchOneEntry 4=" + result );


/*
        Driver driver = new GooglePlayDriver(context);
        FirebaseJobDispatcher dispatcher = new FirebaseJobDispatcher(driver);

        // Create the Job to periodically sync Sunshine
        Job syncJob = dispatcher.newJobBuilder()
                // The Service that will be used to sync Sunshine's data
                .setService(FirebaseJobServiceOneEntry.class)
                // Set the UNIQUE tag used to identify this Job
                .setTag(GONG_SYNC_ONE_ENTRY_TAG)
                //
                // * Network constraints on which this Job should run. We choose to run on any
                // * network, but you can also choose to run only on un-metered networks or when the
                // * device is charging. It might be a good idea to include a preference for this,
                // * as some users may not want to download any data on their mobile plan. ($$$)
                // *
                .setConstraints(Constraint.ON_ANY_NETWORK)
                //
                // * setLifetime sets how long this job should persist. The options are to keep the
                // * Job "forever" or to have it die the next time the device boots up.
                // *
                .setLifetime(Lifetime.UNTIL_NEXT_BOOT)
                //
                // * We want Sunshine's weather data to stay up to date, so we tell this Job to recur.
                // *
                .setRecurring(false)
                //
                // * We want the weather data to be synced every 3 to 4 hours. The first argument for
                // * Trigger's static executionWindow method is the start of the time frame when the
                // * sync should be performed. The second argument is the latest point in time at
                // * which the data should be synced. Please note that this end time is not
                // * guaranteed, but is more of a guideline for FirebaseJobDispatcher to go off of.
                // *
                .setTrigger(
                        Trigger.executionWindow(
                        0,
                        0))
//                .setTrigger(Trigger.NOW)
                //
                // * If a Job with the tag with provided already exists, this new job will replace
                // * the old one.
                // *
                .setReplaceCurrent(false)

                //put extra information to the job
                .setExtras(passinBundle)
                // Once the Job is ready, call the builder's build method to return the Job
                .build();

        // Schedule the Job with the dispatcher
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchOneEntry 2");
        dispatcher.schedule(syncJob);
*/


    }

    synchronized public static void gsheetfetchOneEntry (@NonNull final Context context,
                                                               final String sheet_id,
                                                               final long rowid,
                                                               final long articleid
                                                               ) {
        gsheetfetchOneEntryAltURI(context, sheet_id, rowid, articleid, null);
    }

    synchronized public static void gsheetfetchOneEntryAltURI (@NonNull final Context context,
                                                        final String sheet_id,
                                                        final long rowid,
                                                        final long articleid,
                                                        final Uri altURI) {
        LogUtil.debug(TAG, "in gsheetfetch initialize 1");

        new Thread(() -> {
            LogUtil.debug(TAG, "in gsheetfetch thread 1 sheet_id="+ sheet_id + ",rowid=" + rowid );
            GSheetQuery gSheetQuery = GSheetQuery.getInstance();
            //gSheetQuery.testapi();
            List<ContentValues> resultlist = gSheetQuery.getDataFromApiWithOneID(sheet_id, rowid);
            if ( (resultlist == null) || (resultlist.size() != 1)) {
                LogUtil.debug(TAG, " gsheetfetch  cannnot get only one result !!!! ");
                return;
            }

            //preload image
            String imageurl = (String) resultlist.get(0).get(ArticleTableContract.ArticleEntry.COLUMN_IMAGEURL);
            GlideApp.with(context)
                    .load(imageurl);

            Uri indIDURI;
            if (altURI != null){
                indIDURI = altURI;
            } else {
                indIDURI = ArticleTableContract.buildArticleUriWithID(articleid);
            }
            ContentValues contentValue = resultlist.get(0);
            Uri resulturi = context.getContentResolver().insert(
                    indIDURI,
                    contentValue);

            LogUtil.debug(TAG, "in gsheetfetch thread 2 resulturi=" + resulturi);

        }).start();
        /*
        Thread fetch = new Thread(new Runnable() {
            @Override
            public void run() {
                LogUtil.debug(TAG, "in gsheetfetch thread 1 ");


                GSheetQuery gSheetQuery = new GSheetQuery();
                List<ContentValues> resultlist =  gSheetQuery.getDataFromApiWithOneID(sheet_id, rowid);
                if (resultlist.size() != 1){
                    LogUtil.debug (TAG, " gsheetfetch  cannnot get only one result !!!! ");

                }

                Uri indIDURI = ArticleTableContract.buildArticleUriWithID(articleid);
                ContentValues contentValue = resultlist.get(0);
                Uri resulturi  = context.getContentResolver().insert(
                        indIDURI,
                        contentValue);

                LogUtil.debug(TAG, "in gsheetfetch thread 2 resulturi=" + resulturi);

            }
        });

        // Finally, once the thread is prepared, fire it off to perform our checks.
        fetch.start();

        */
        LogUtil.debug(TAG, "in gsheetfetch  4");
    }


    synchronized public static void gsheetfetchOneBlock(@NonNull final Context context,
                                                        final String sheet_id,
                                                        final String startColumnFirst,
                                                        final String endColumnFirst,
                                                        final String startColumnSecond,
                                                        final String endColumnSecond,
                                                        Uri uri
    ) {
        gsheetfetchOneBlockName(context, sheet_id, startColumnFirst,
                endColumnFirst, startColumnSecond, endColumnSecond, uri, null);
    }

    synchronized public static void gsheetfetchOneBlockName(@NonNull final Context context,
                                                            final String sheet_id,
                                                            final String startColumnFirst,
                                                            final String endColumnFirst,
                                                            final String startColumnSecond,
                                                            final String endColumnSecond,
                                                            Uri uri,
                                                            String name
    ) {
        gsheetfetchOneBlockNameCat(context, sheet_id, startColumnFirst,
                endColumnFirst, startColumnSecond, endColumnSecond, uri, name, 0);
    }

    synchronized public static void gsheetfetchOneBlockNameCat(@NonNull final Context context,
                                                               final String sheet_id,
                                                               final String startColumnFirst,
                                                               final String endColumnFirst,
                                                               final String startColumnSecond,
                                                               final String endColumnSecond,
                                                               Uri uri,
                                                               String name,
                                                               int categoryid
    ) {
        LogUtil.debug(TAG, "in gsheetfetchOneBlock initialize 1");

        new Thread(() -> {
            LogUtil.debug(TAG, "in gsheetfetchOneBlock thread 1 uri="
                    + uri
                    + ", sheet_id="
                    + sheet_id
                    + ", startColumnFirst=" + startColumnFirst
                    + ", endColumnFirst=" + endColumnFirst
                    + ", name=" + name
                    + ", categoryid=" + categoryid);
            GSheetQuery gSheetQuery = GSheetQuery.getInstance();
            List<ContentValues> resultlist = gSheetQuery.getDataFromApiWithOneBlockNameCat(sheet_id,
                    startColumnFirst, endColumnFirst, name, categoryid);
            if ( (resultlist == null) || (resultlist.size() == 0)) {
                LogUtil.debug(TAG, " gsheetfetchOneBlock  2 cannnot get only one result !!!! ");
                return;
            }
            ContentValues[] contentValues = new ContentValues[resultlist.size()];
            contentValues = resultlist.toArray(contentValues);

            int result = context.getContentResolver().bulkInsert(
                    uri,
                    contentValues);
            LogUtil.debug(TAG, "in gsheetfetchOneBlock thread 3 result="
                    + result
                    + ",resultlist.size()="
                    + resultlist.size());

            if ((startColumnSecond != null) && (endColumnSecond != null)) {
                LogUtil.debug(TAG, "in gsheetfetchOneBlock thread 3.4 uri="
                        + uri
                        + ", sheet_id=" + sheet_id
                        + ", startColumnSecond=" + startColumnSecond
                        + ", endColumnSecond=" + endColumnSecond
                        + ", name=" + name
                        + ", categoryid=" + categoryid);

                resultlist = gSheetQuery.getDataFromApiWithOneBlockNameCat(sheet_id,
                        startColumnSecond, endColumnSecond, name, categoryid);
                if ((resultlist== null) || (resultlist.size() == 0) ) {
                    LogUtil.debug(TAG, " gsheetfetchOneBlock 4 cannnot get only one result !!!! ");
                    return;
                }
                contentValues = new ContentValues[resultlist.size()];
                contentValues = resultlist.toArray(contentValues);

                result = context.getContentResolver().bulkInsert(
                        uri,
                        contentValues);
                LogUtil.debug(TAG, "in gsheetfetchOneBlock thread 5 result=" + result);

            }

            LogUtil.debug(TAG, "in gsheetfetchOneBlock thread 6 result=" + result);

        }).start();

        LogUtil.debug(TAG, "in gsheetfetchOneBlock  4");
    }


    /**
     * Helper method to perform a sync immediately using an IntentService for asynchronous
     * execution.
     *
     * @param context The Context used to start the IntentService for the sync.
     */


    public static void startRegister(@NonNull final Context context) {
        LogUtil.debug(TAG, "in Gongdispatch startImmediateRegister 1");
        Intent firebaseintentservice = new Intent(context, FirebaseIntentService.class);
        firebaseintentservice.putExtra(FirebaseIntentService.TABLE_UPDATE,
                FirebaseIntentService.TABLE_UPDATE_INITIAL);
        context.startService(firebaseintentservice);

        LogUtil.debug(TAG, "in Gongdispatch startImmediateRegister 3");
    }


    public static void startImmediateSync(@NonNull final Context context) {
        LogUtil.debug(TAG, "in Gongdispatch startImmediateSync 1");

        //crash for using cursorwindow
        //CursorWindow cursorWindow = new CursorWindow("cursorWindow");

        LogUtil.debug(TAG, "in Gongdispatch startImmediateSync 2");

        Intent firebaseintentservice = new Intent(context, FirebaseIntentService.class);
        firebaseintentservice.putExtra("section", "1to20");
        firebaseintentservice.putExtra(FirebaseIntentService.TABLE_UPDATE,
                FirebaseIntentService.TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION);
        context.startService(firebaseintentservice);
        LogUtil.debug(TAG, "in Gongdispatch startImmediateSync 3");
        Intent archivePageIntentservice = new Intent(context, FirebaseIntentService.class);
        archivePageIntentservice.putExtra(FirebaseIntentService.TABLE_UPDATE,
                FirebaseIntentService.TABLE_UPDATE_ARCHIVELATESTPAGELOOKUP);
        context.startService(archivePageIntentservice);

        LogUtil.debug(TAG, "in Gongdispatch startImmediateSync 4");
    }

    public static boolean retrieveSheet(int currentNoOfEntryRemote, Map<String, String> maplookupList,
                                        int pagenumber, int offset, Uri uri, String endcolumnName,
                                        int numberOfEntryToRetrieve, Context context) {
        return retrieveSheetAndName(currentNoOfEntryRemote, maplookupList,
                pagenumber, offset, uri, endcolumnName,
                numberOfEntryToRetrieve, context, null);
    }

    public static boolean retrieveSheetAndName(int currentNoOfEntryRemote, Map<String, String> maplookupList,
                                               int pagenumber, int offset, Uri uri, String endcolumnName,
                                               int numberOfEntryToRetrieve, Context context, String name) {
        return retrieveSheetAndNameCat(currentNoOfEntryRemote, maplookupList,
                pagenumber, offset, uri, endcolumnName,
                numberOfEntryToRetrieve, context, name, 0);

    }

    public static boolean retrieveSheetAndNameCat(int currentNoOfEntryRemote, Map<String, String> maplookupList,
                                                  int pagenumber, int offset, Uri uri, String endcolumnName,
                                                  int numberOfEntryToRetrieve, Context context, String name, int categoryid) {
        int highOffsetFromLastFetch = currentNoOfEntryRemote - pagenumber
                * numberOfEntryToRetrieve - offset;
        int lowOffsetFromLastFetch = highOffsetFromLastFetch > numberOfEntryToRetrieve
                ? (highOffsetFromLastFetch - numberOfEntryToRetrieve + 1)
                : 1;
        String lowOffsetSheetID = "";
        int lowOffsetHighEnd = 0;
        String highOffsetSheetID = "";
        int highOffsetLowEnd = 0;

        for (Map.Entry<String, String> mapentry : maplookupList.entrySet()) {
            if ((GSheetQuery.decodeGetLowerBound(mapentry.getKey()) <= lowOffsetFromLastFetch)
                    && (lowOffsetFromLastFetch <= GSheetQuery.decodeGetHigherBound(mapentry.getKey()))) {
                lowOffsetSheetID = mapentry.getValue();
                lowOffsetHighEnd = (int) GSheetQuery.decodeGetHigherBound(mapentry.getKey());
            }
            if ((GSheetQuery.decodeGetLowerBound(mapentry.getKey()) <= highOffsetFromLastFetch)
                    && (highOffsetFromLastFetch <= GSheetQuery.decodeGetHigherBound(mapentry.getKey()))
                    ) {
                highOffsetSheetID = mapentry.getValue();
                highOffsetLowEnd = (int) GSheetQuery.decodeGetLowerBound(mapentry.getKey());
            }
            if ((GSheetQuery.decodeGetLowerBound(mapentry.getKey()) <= highOffsetFromLastFetch)
                    && (highOffsetFromLastFetch <= GSheetQuery.decodeGetHigherBound(mapentry.getKey()))
                    && (GSheetQuery.decodeGetLowerBound(mapentry.getKey()) <= lowOffsetFromLastFetch)
                    && (lowOffsetFromLastFetch <= GSheetQuery.decodeGetHigherBound(mapentry.getKey()))

                    ) {
                //only one request
                LogUtil.debug(TAG, " gongdispatch --> retrieveSheet gsheet 1 " +
                        " start from " + "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) +
                        " end with " + endcolumnName + String.valueOf(
                        (highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) == 0 ?
                                Gongdispatch.ENTRYPERSHEET :
                                highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET));

                Gongdispatch.gsheetfetchOneBlockNameCat(context,
                        mapentry.getValue(),
                        "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                        endcolumnName + String.valueOf((highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) == 0 ?
                                Gongdispatch.ENTRYPERSHEET :
                                highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                        null, null, uri, name, categoryid);
                LogUtil.debug(TAG, " gongdispatch --> retrieveSheet gsheet 2 ");
                return true;

            }
        }
        if (lowOffsetSheetID.compareTo(highOffsetSheetID) != 0) {
            //need send request
            LogUtil.debug(TAG, " gongdispatch --> retrieveSheet gsheet 3 " +
                    " start from " + "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) +
                    " end with " + endcolumnName + String.valueOf(lowOffsetHighEnd));
            Gongdispatch.gsheetfetchOneBlockNameCat(context, lowOffsetSheetID,
                    "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                    endcolumnName + String.valueOf(lowOffsetHighEnd),
                    null, null, uri, name, categoryid);
            LogUtil.debug(TAG, " gongdispatch --> retrieveSheet gsheet 4 " +
                    " start from " + "A" + String.valueOf(highOffsetLowEnd) +
                    " end with " + endcolumnName + String.valueOf(highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET));
            Gongdispatch.gsheetfetchOneBlockNameCat(context, highOffsetSheetID,
                    "A" + String.valueOf(highOffsetLowEnd),
                    endcolumnName + String.valueOf(highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                    null, null, uri, name, categoryid);
            LogUtil.debug(TAG, " gongdispatch --> retrieveSheet gsheet 5 ");
            return true;

        }
        return false;
    }

    public static boolean isOnline(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }


}
