package com.hk.gonggongnews.ngogong.util;

import android.util.Log;

import com.hk.gonggongnews.ngogong.BuildConfig;

/**
 * Created by ismile on 1/4/2018.
 */

public class LogUtil {

    public static void debug(final String tag, String message) {
        if (BuildConfig.DEBUG) {
            Log.d(tag, message);
        }
    }
}
