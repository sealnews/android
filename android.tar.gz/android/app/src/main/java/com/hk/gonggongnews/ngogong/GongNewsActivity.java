package com.hk.gonggongnews.ngogong;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.helper.ItemTouchHelper;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.GongInfoLookupContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;
import com.hk.gonggongnews.ngogong.util.BottomNavigationViewHelper;
import com.hk.gonggongnews.ngogong.util.GongInfo;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 11/24/2017.
 */

public class GongNewsActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>,
        GongNewsAdapter.GongNewsAdapterOnClickHandler  {


    private final String TAG = GongNewsActivity.class.getSimpleName();


    private static final int ID_GONGINFOLOOKUP_ALLNAME_LOADER = 401;
    private GongNewsAdapter mGongNewsAdapter;

    private RecyclerView mRecyclerView;
    private int mPosition = RecyclerView.NO_POSITION;
    private BottomNavigationView mBottomNavigationView;

    private ProgressBar mLoadingIndicator;

    private CollapsingToolbarLayout mCollapsingToolbarLayout;
    private String mCollapsingToolbarTitle;
    private ImageView mIVGongNewsLogo;



    public class GridSpacingItemDecoration extends RecyclerView.ItemDecoration {

        private int spanCount;
        private int spacing;
        private boolean includeEdge;

        public GridSpacingItemDecoration(int spanCount, int spacing, boolean includeEdge) {
            this.spanCount = spanCount;
            this.spacing = spacing;
            this.includeEdge = includeEdge;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
            int position = parent.getChildAdapterPosition(view); // item position
            int column = position % spanCount; // item column

            if (includeEdge) {
                outRect.left = spacing - column * spacing / spanCount; // spacing - column * ((1f / spanCount) * spacing)
                outRect.right = (column + 1) * spacing / spanCount; // (column + 1) * ((1f / spanCount) * spacing)

                if (position < spanCount) { // top edge
                    outRect.top = spacing;
                }
                outRect.bottom = spacing; // item bottom
            } else {
                outRect.left = column * spacing / spanCount; // column * ((1f / spanCount) * spacing)
                outRect.right = spacing - (column + 1) * spacing / spanCount; // spacing - (column + 1) * ((1f /    spanCount) * spacing)
                if (position >= spanCount) {
                    outRect.top = spacing; // item top
                }
            }
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gongnews);
        LogUtil.debug(TAG, " GongNewsActivity oncreate 1");

        Intent intent = getIntent();


        mBottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_mainnews_navigation);
        BottomNavigationViewHelper.selection(this, mBottomNavigationView, R.id.nav_gongnews);
        Menu menu = mBottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);


        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview_slowdown);

        GridLayoutManager layoutManager =
                new GridLayoutManager(this, 2, GridLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mGongNewsAdapter = new GongNewsAdapter(this,
                this);

        mRecyclerView.setAdapter(mGongNewsAdapter);
        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mRecyclerView.getContext(),
        //        layoutManager.getOrientation());
        //mRecyclerView.addItemDecoration(dividerItemDecoration);
        int spanCount = 2; // 3 columns
        int spacing = 100; // 50px
        boolean includeEdge = true;
        //mRecyclerView.addItemDecoration(new GridSpacingItemDecoration(spanCount, spacing, includeEdge));


        mLoadingIndicator = (ProgressBar) findViewById(R.id.pb_loading_indicator);


        //getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        //getSupportActionBar().setTitle(R.string.gong_news_name);
        //getSupportActionBar().setHideOnContentScrollEnabled(true);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //toolbar.setTitle(R.string.gong_news_name);
        //toolbar.setSubtitle("how are you");
        //toolbar.setTitleMarginStart(440);

        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        //toolbar_title.setText(R.string.gong_news_name);


        TextView textview4 = (TextView) findViewById(R.id.textView4);
        //textview4.animate().setStartDelay(10000).rotation(180).setDuration(5000);
        mIVGongNewsLogo = (ImageView) findViewById(R.id.gongnews_logo_image);
        mIVGongNewsLogo.animate().setStartDelay(500).rotation(360).setDuration(1000);
        mCollapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        mCollapsingToolbarLayout.setExpandedTitleColor(getResources().getColor(android.R.color.transparent));
        mCollapsingToolbarTitle = getString(R.string.gong_news_name);


        AppBarLayout appBarLayout = (AppBarLayout) findViewById(R.id.app_bar_layout);
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = false;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                LogUtil.debug(TAG, "vertical - scrollRange=" + scrollRange + ", verticalOffset=" + verticalOffset +",isshow="+ isShow);

                if (scrollRange + verticalOffset == 0) {
                    //fully collapsed the actionbar to the top

                    mCollapsingToolbarLayout.setTitle(mCollapsingToolbarTitle);
                    mCollapsingToolbarLayout.setTitleEnabled(true);

                    isShow = true;
                    LogUtil.debug(TAG, "vertical 0 ");
                } else if(isShow) {
                    //either dragging or expanding.
                    //collapsingToolbarLayout.setTitle(" vertical1");//carefull there should a space between double quote otherwise it wont work
                    mCollapsingToolbarLayout.setTitleEnabled(false);

                    isShow = false;
                    LogUtil.debug(TAG, "vertical 1 ");
                } else {
                    LogUtil.debug(TAG, "vertical 2 ");
                    mCollapsingToolbarLayout.setTitleEnabled(false);
                    mIVGongNewsLogo.animate().cancel();
                    mIVGongNewsLogo.animate().setStartDelay(500).rotation(360).setDuration(1000);

                }
                LogUtil.debug(TAG, "vertical 3 ");
            }
        });





        getSupportLoaderManager().initLoader(ID_GONGINFOLOOKUP_ALLNAME_LOADER, null, this);

        //Gongdispatch.gongnewsinitialize(this);
        LogUtil.debug(TAG, " GongNewsActivity oncreate 2");

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        LogUtil.debug(TAG, " GongNewsActivity onrestart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        LogUtil.debug(TAG, " GongNewsActivity onstop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtil.debug(TAG, " GongNewsActivity ondestroy");
    }


    private void showLoading() {
        /* Then, hide the weather data */
        LogUtil.debug(TAG, " showloading ");
        mRecyclerView.setVisibility(View.INVISIBLE);
        /* Finally, show the loading indicator */
        mLoadingIndicator.setVisibility(View.VISIBLE);
    }
    private void showDataView() {
        /* First, hide the loading indicator */
        LogUtil.debug(TAG, " showdatashow ");
        mLoadingIndicator.setVisibility(View.INVISIBLE);
        /* Finally, make sure the weather data is visible */
        mRecyclerView.setVisibility(View.VISIBLE);
    }




    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        LogUtil.debug(TAG, "----> oncreateloader ");
        switch (id) {
            case ID_GONGINFOLOOKUP_ALLNAME_LOADER:
            default:
                if (id != ID_GONGINFOLOOKUP_ALLNAME_LOADER) {
                    Log.w(TAG, "Loader Not Implemented: " + id);
                }
                Uri gonginfolookupQueryUri = GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI_ALLNAME;
                String gonginfolookupsortOrder = GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SHEETID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                return new CursorLoader(this,
                        gonginfolookupQueryUri,
                        GongInfoLookupContract.ALLNAME_PROJECTION,
                        null,
                        null,
                        gonginfolookupsortOrder);



                //throw new RuntimeException("Loader Not Implemented: " + id);
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, "  onloadfinished 1 ");

        switch (loader.getId()) {
            case ID_GONGINFOLOOKUP_ALLNAME_LOADER:
                if ((data != null) && (data.getCount() > 0)) {
                    LogUtil.debug(TAG, " ID_GONGINFOLOOKUP_ALLNAME_LOADER getcount>0 =" + data.getCount());

                    mGongNewsAdapter.swapCursor(data);
                    showDataView();

                } else {
                    showLoading();
                    if (!Gongdispatch.isOnline(this)){
                        Toast.makeText(this, R.string.check_network_setting, Toast.LENGTH_LONG).show();

                    }
                    LogUtil.debug(TAG, "  onloadinfished ID_GONGINFOLOOKUP_ALLNAME_LOADER getcount=0");
                }
                LogUtil.debug(TAG, " ID_GONGINFOLOOKUP_ALLNAME_LOADER =" + data.getCount());

                break;

            default:
                LogUtil.debug(TAG, "  onloadfinished 4 loaderid=" + loader.getId());
                break;
        }
        //data.close();

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        LogUtil.debug(TAG, "----> onloaderreset ");

    }

    @Override
    public void onClickIndEntity(String title, int id){
        LogUtil.debug(TAG, " --> onClickIndEntity title= "+ title + ",id="+ id);
        Intent intent = new Intent(this, GongNewsDetailActivity.class);
        intent.putExtra(GongNewsDetailActivity.ENTITY_NAME, title);
        intent.putExtra(GongNewsDetailActivity.ENTITY_ID, id);
        startActivity(intent);

    }


}


