package com.hk.gonggongnews.ngogong.data;

import android.annotation.TargetApi;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.util.Log;

import com.hk.gonggongnews.ngogong.util.LogUtil;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by ismile on 10/11/2017.
 */


public class GongProvider extends ContentProvider {
    private final String TAG = GongProvider.class.getSimpleName();

    /*
     * These constant will be used to match URIs with the data they are looking for. We will take
     * advantage of the UriMatcher class to make that matching MUCH easier than doing something
     * ourselves, such as using regular expressions.
     */
    public static final int CODE_PAGINATION = 101;
    public static final int CODE_PAGINATION_WITH_FROMANDTO = 102;

    public static final int CODE_CATEGORY= 103;
    public static final int CODE_DOMAIN= 104;
    public static final int CODE_FIRSTSUBDOMAIN= 105;
    public static final int CODE_ARTICLELOOKUP = 106;
    public static final int CODE_ARTICLE = 107;
    public static final int CODE_SIGNAL = 108;
    public static final int CODE_PAGINATION_ARCHIVE = 109;
    public static final int CODE_ARCHIVELATESTLOOKUP = 110;
    public static final int CODE_ARCHIVELATESTPAGELOOKUP = 111;
    public static final int CODE_ARTICLE_BOOKMARK = 112;
    public static final int CODE_GONGINFO = 113;
    public static final int CODE_GONGINFO_NAME_NAME = 114;
    public static final int CODE_GONGINFOLOOKUP  = 115;
    public static final int CODE_GONGINFOLOOKUP_NAME_TYPE_NAME  = 116;
    public static final int CODE_GONGINFOLOOKUP_INFONAME  = 117;
    public static final int CODE_GONGINFOLOOKUP_ALLNAME = 118;
    public static final int CODE_FRAGARTICLEARC = 119;
    public static final int CODE_FRAGARTICLEARC_NAME  = 120;
    public static final int CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN  = 121;
    public static final int CODE_FRAGARTICLEARC_CATEGORY = 122;
    public static final int CODE_FRAGARTICLE = 123;
    public static final int CODE_FRAGARTICLE_NAME  = 124;
    public static final int CODE_FRAGARTICLE_FIRSTSUBDOMAIN  = 125;
    public static final int CODE_FRAGARTICLE_CATEGORY = 126;
    public static final int CODE_FRAGLOOKUP  = 127;
    public static final int CODE_FRAGLOOKUP_NAME  = 128;
    public static final int CODE_SIGNAL_FINDNOTIN = 129;



    public static final int CODE_CATEGORY_WITH_ID = 203;
    public static final int CODE_DOMAIN_WITH_ID = 204;
    public static final int CODE_FIRSTSUBDOMAIN_WITH_ID = 205;
    public static final int CODE_ARTICLELOOKUP_WITH_ID  = 206;
    public static final int CODE_ARTICLE_WITH_ID  = 207;
    public static final int CODE_SIGNAL_WITH_ID  = 208;
    public static final int CODE_ARCHIVELATESTLOOKUP_WITH_ID = 210;
    public static final int CODE_ARCHIVELATESTPAGELOOKUP_WITH_ID = 211;
    public static final int CODE_GONGINFO_WITH_ID = 213;
    public static final int CODE_GONGINFOLOOKUP_WITH_ID   = 214;
    public static final int CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN_ID  = 215;
    public static final int CODE_FRAGARTICLEARC_CATEGORY_ID = 216;
    public static final int CODE_FRAGARTICLE_FIRSTSUBDOMAIN_ID  = 217;
    public static final int CODE_FRAGARTICLE_CATEGORY_ID = 218;
    public static final int CODE_FRAGARTICLEARC_NAME_NAME   = 219;
    public static final int CODE_FRAGARTICLE_NAME_NAME  = 220;
    public static final int CODE_FRAGLOOKUP_NAME_NAME  = 221;



    public static final int INITIAL_MASK_ALL = 0x001f;
    public static final int INITIAL_MASK_ARTICLELOOKUPTABLE = 0x0001;
    public static final int INITIAL_MASK_CATEGORYTABLE = 0x0002;
    public static final int INITIAL_MASK_DOMAINTABLE = 0x0004;
    public static final int INITIAL_MASK_FIRSTSUBDOMAINTABLE = 0x0008;
    public static final int INITIAL_MASK_LATESTNEWSPAGINATIONTABLE = 0x0010;
    private int mCurrent_initial_mask = 0x0000;


    /*
     * The URI Matcher used by this content provider. The leading "s" in this variable name
     * signifies that this UriMatcher is a static member variable of WeatherProvider and is a
     * common convention in Android programming.
     */
    private static final UriMatcher sUriMatcher = buildUriMatcher();
    private GongDbHelper mOpenHelper;

    public static UriMatcher buildUriMatcher() {

        /*
         * All paths added to the UriMatcher have a corresponding code to return when a match is
         * found. The code passed into the constructor of UriMatcher here represents the code to
         * return for the root URI. It's common to use NO_MATCH as the code for this case.
         */
        final UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        final String authority = LatestNewsPaginationContract.CONTENT_AUTHORITY;


        matcher.addURI(authority, LatestNewsPaginationContract.PATH_PAGINATION, CODE_PAGINATION);
        matcher.addURI(authority, LatestNewsPaginationContract.PATH_PAGINATION + "/FROM/#/TO/#", CODE_PAGINATION_WITH_FROMANDTO);
        matcher.addURI(authority, LatestNewsPaginationArcContract.PATH_PAGINATION_ARCHIVE, CODE_PAGINATION_ARCHIVE);


        matcher.addURI(authority, CategoryTableContract.PATH_CATEGORY, CODE_CATEGORY);
        matcher.addURI(authority, DomainTableContract.PATH_DOMAIN, CODE_DOMAIN);
        matcher.addURI(authority, FirstSubdomainTableContract.PATH_FIRSTSUBDOMAIN, CODE_FIRSTSUBDOMAIN);
        matcher.addURI(authority, ArticleLookupTableContract.PATH_ARTICLELOOKUP, CODE_ARTICLELOOKUP);
        matcher.addURI(authority, ArticleTableContract.PATH_ARTICLE, CODE_ARTICLE);
        matcher.addURI(authority, SignalContract.PATH_SIGNAL, CODE_SIGNAL);
        matcher.addURI(authority, ArchiveLatestLookupContract.PATH_ARCHIVELATESTLOOKUP, CODE_ARCHIVELATESTLOOKUP);
        matcher.addURI(authority, ArchiveLatestPageLookupContract.PATH_ARCHIVELATESTPAGELOOKUP, CODE_ARCHIVELATESTPAGELOOKUP);
        matcher.addURI(authority, ArticleTableContract.PATH_ARTICLE_BOOKMARK , CODE_ARTICLE_BOOKMARK);
        matcher.addURI(authority, GongInfoContract.PATH_GONGINFO , CODE_GONGINFO);
        matcher.addURI(authority, GongInfoContract.PATH_GONGINFO + "/"
                + GongInfoContract.PATH_NAME + "/*" , CODE_GONGINFO_NAME_NAME);
        matcher.addURI(authority, GongInfoLookupContract.PATH_GONGINFOLOOKUP , CODE_GONGINFOLOOKUP);
        matcher.addURI(authority, GongInfoLookupContract.PATH_GONGINFOLOOKUP + "/"
                + GongInfoLookupContract.PATH_NAME + "/*" , CODE_GONGINFOLOOKUP_NAME_TYPE_NAME);
        matcher.addURI(authority, GongInfoLookupContract.PATH_GONGINFOLOOKUP + "/"
                + GongInfoLookupContract.PATH_INFONAME + "/*" , CODE_GONGINFOLOOKUP_INFONAME);
        matcher.addURI(authority, GongInfoLookupContract.PATH_GONGINFOLOOKUP + "/"
                + GongInfoLookupContract.PATH_ALLNAME , CODE_GONGINFOLOOKUP_ALLNAME);

        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC, CODE_FRAGARTICLEARC);
        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC + "/"
                + FragArticleArcTableContract.PATH_NAME , CODE_FRAGARTICLEARC_NAME);
        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC + "/"
                + FragArticleArcTableContract.PATH_NAME + "/*", CODE_FRAGARTICLEARC_NAME_NAME);
        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC + "/"
                + FragArticleArcTableContract.PATH_CATEGORY , CODE_FRAGARTICLEARC_CATEGORY);
        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC + "/"
                + FragArticleArcTableContract.PATH_CATEGORY+ "/#", CODE_FRAGARTICLEARC_CATEGORY_ID);
        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC + "/"
                + FragArticleArcTableContract.PATH_FIRSTSUBDOMAIN , CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN);
        matcher.addURI(authority, FragArticleArcTableContract.PATH_FRAGARTICLEARC + "/"
                + FragArticleArcTableContract.PATH_FIRSTSUBDOMAIN+ "/#", CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN_ID);

        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE, CODE_FRAGARTICLE);
        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE + "/"
                + FragArticleTableContract.PATH_NAME , CODE_FRAGARTICLE_NAME);
        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE + "/"
                + FragArticleTableContract.PATH_NAME + "/*", CODE_FRAGARTICLE_NAME_NAME);
        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE + "/"
                + FragArticleTableContract.PATH_CATEGORY , CODE_FRAGARTICLE_CATEGORY);
        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE + "/"
                + FragArticleTableContract.PATH_CATEGORY+ "/#", CODE_FRAGARTICLE_CATEGORY_ID);
        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE + "/"
                + FragArticleTableContract.PATH_FIRSTSUBDOMAIN , CODE_FRAGARTICLE_FIRSTSUBDOMAIN);
        matcher.addURI(authority, FragArticleTableContract.PATH_FRAGARTICLE + "/"
                + FragArticleTableContract.PATH_FIRSTSUBDOMAIN+ "/#", CODE_FRAGARTICLE_FIRSTSUBDOMAIN_ID);

        matcher.addURI(authority, FragLookupTableContract.PATH_FRAGLOOKUP, CODE_FRAGLOOKUP);
        matcher.addURI(authority, FragLookupTableContract.PATH_FRAGLOOKUP + "/"
                + FragLookupTableContract.PATH_NAME , CODE_FRAGLOOKUP_NAME);
        matcher.addURI(authority, FragLookupTableContract.PATH_FRAGLOOKUP + "/"
                + FragLookupTableContract.PATH_NAME + "/*", CODE_FRAGLOOKUP_NAME_NAME);



        matcher.addURI(authority, CategoryTableContract.PATH_CATEGORY + "/#", CODE_CATEGORY_WITH_ID);
        matcher.addURI(authority, DomainTableContract.PATH_DOMAIN + "/#", CODE_DOMAIN_WITH_ID);
        matcher.addURI(authority, FirstSubdomainTableContract.PATH_FIRSTSUBDOMAIN + "/#", CODE_FIRSTSUBDOMAIN_WITH_ID);
        matcher.addURI(authority, ArticleLookupTableContract.PATH_ARTICLELOOKUP + "/#", CODE_ARTICLELOOKUP_WITH_ID);
        matcher.addURI(authority, ArticleTableContract.PATH_ARTICLE + "/#", CODE_ARTICLE_WITH_ID);
        matcher.addURI(authority, SignalContract.PATH_SIGNAL + "/#", CODE_SIGNAL_WITH_ID);
        matcher.addURI(authority, ArchiveLatestLookupContract.PATH_ARCHIVELATESTLOOKUP  + "/#", CODE_ARCHIVELATESTLOOKUP_WITH_ID);
        matcher.addURI(authority, ArchiveLatestPageLookupContract.PATH_ARCHIVELATESTPAGELOOKUP  + "/#", CODE_ARCHIVELATESTPAGELOOKUP_WITH_ID);


        matcher.addURI(authority, SignalContract.PATH_SIGNAL + "/" +
                SignalContract.PATH_SIGNAL_FINDNOTIN , CODE_SIGNAL_FINDNOTIN);


        LogUtil.debug("matching-uri", "-------------> after matcher.adduri" );
        return matcher;
    }

    @Override
    public boolean onCreate() {
        /*
         * As noted in the comment above, onCreate is run on the main thread, so performing any
         * lengthy operations will cause lag in your app. Since WeatherDbHelper's constructor is
         * very lightweight, we are safe to perform that initialization here.
         */
        mOpenHelper = new GongDbHelper(getContext());
        Cursor cursor;
        String[] projectionColumns = {ArticleLookupTableContract.ArticleLookupEntry._ID};

        cursor  = mOpenHelper.getReadableDatabase().query(
                ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);

        if ( (cursor != null) && (cursor.getCount() > 0)){
            mCurrent_initial_mask |= INITIAL_MASK_ARTICLELOOKUPTABLE;
        }


        projectionColumns[0] = CategoryTableContract.CategoryEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                CategoryTableContract.CategoryEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);

        if ( (cursor != null) && (cursor.getCount() > 0)){
            mCurrent_initial_mask |= INITIAL_MASK_CATEGORYTABLE;
        }

        projectionColumns[0] = DomainTableContract.DomainEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                DomainTableContract.DomainEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);

        if ( (cursor != null) && (cursor.getCount() > 0)){
            mCurrent_initial_mask |= INITIAL_MASK_DOMAINTABLE;
        }

        projectionColumns[0] = FirstSubdomainTableContract.FirstSubdomainEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);

        if ( (cursor != null) && (cursor.getCount() > 0)){
            mCurrent_initial_mask |= INITIAL_MASK_FIRSTSUBDOMAINTABLE;
        }

        projectionColumns[0] = LatestNewsPaginationContract.PaginationEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                LatestNewsPaginationContract.PaginationEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);

        if ( (cursor != null) && (cursor.getCount() > 0)){
            mCurrent_initial_mask |= INITIAL_MASK_LATESTNEWSPAGINATIONTABLE;
        }

        projectionColumns[0] = LatestNewsPaginationArcContract.PaginationArcEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                LatestNewsPaginationArcContract.PaginationArcEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);



        projectionColumns[0] = ArchiveLatestLookupContract.ArchiveLatestLookupEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);

        projectionColumns[0] = ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry._ID;
        cursor  = mOpenHelper.getReadableDatabase().query(
                ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME,
                projectionColumns,
                null,
                null,
                null,
                null,
                null);



        LogUtil.debug(TAG, " onCreate mcurrent_initial_mask = "  + mCurrent_initial_mask);
        return true;
    }

    /**
     * Handles requests to insert a set of new rows. In Sunshine, we are only going to be
     * inserting multiple rows of data at a time from a weather forecast. There is no use case
     * for inserting a single row of data into our ContentProvider, and so we are only going to
     * implement bulkInsert. In a normal ContentProvider's implementation, you will probably want
     * to provide proper functionality for the insert method as well.
     *
     * @param uri    The content:// URI of the insertion request.
     * @param values An array of sets of column_name/value pairs to add to the database.
     *               This must not be {@code null}.
     *
     * @return The number of values that were inserted.
     */
    @Override
    public int bulkInsert(@NonNull Uri uri, @NonNull ContentValues[] values) {
        final SQLiteDatabase db = mOpenHelper.getWritableDatabase();
        int rowsInserted = 0;
        String tablenameToInsert="NOTABLE";
        LogUtil.debug(TAG, "---> gongprovider  bulkinsert uri=" + uri);
        int mask =0;

        switch (sUriMatcher.match(uri)) {

            case CODE_PAGINATION :

                tablenameToInsert = LatestNewsPaginationContract.PaginationEntry.TABLE_NAME;
                mask = INITIAL_MASK_LATESTNEWSPAGINATIONTABLE;
                break;
            case CODE_CATEGORY:
                tablenameToInsert = CategoryTableContract.CategoryEntry.TABLE_NAME;
                mask = INITIAL_MASK_CATEGORYTABLE;
                break;

            case CODE_DOMAIN:
                tablenameToInsert = DomainTableContract.DomainEntry.TABLE_NAME;
                mask = INITIAL_MASK_DOMAINTABLE;
                break;

            case CODE_FIRSTSUBDOMAIN:
                tablenameToInsert = FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME;
                mask = INITIAL_MASK_FIRSTSUBDOMAINTABLE;
                break;

            case CODE_ARTICLELOOKUP:
                tablenameToInsert = ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME;
                mask = INITIAL_MASK_ARTICLELOOKUPTABLE;

                break;

            case CODE_ARTICLE:
                tablenameToInsert = ArticleTableContract.ArticleEntry.TABLE_NAME;

                break;

            case CODE_SIGNAL:
                tablenameToInsert = SignalContract.SignalEntry.TABLE_NAME;

                break;
            case CODE_PAGINATION_ARCHIVE :
                tablenameToInsert = LatestNewsPaginationArcContract.PaginationArcEntry.TABLE_NAME;
                //Collections.reverse(Arrays.asList(values));

                break;

            case CODE_ARCHIVELATESTLOOKUP:
                tablenameToInsert = ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME;

                break;

            case CODE_ARCHIVELATESTPAGELOOKUP:
                tablenameToInsert = ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME;

                break;

            case CODE_GONGINFO:
            case CODE_GONGINFO_NAME_NAME:
                tablenameToInsert = GongInfoContract.GongInfoEntry.TABLE_NAME;
                break;

            case CODE_GONGINFOLOOKUP:
            case CODE_GONGINFOLOOKUP_INFONAME:
            case CODE_GONGINFOLOOKUP_NAME_TYPE_NAME:
            case CODE_GONGINFOLOOKUP_ALLNAME:
                tablenameToInsert = GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME;
                break;

            case CODE_FRAGARTICLEARC :
            case CODE_FRAGARTICLEARC_NAME  :
            case CODE_FRAGARTICLEARC_NAME_NAME  :
            case CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN  :
            case CODE_FRAGARTICLEARC_CATEGORY :
                tablenameToInsert = FragArticleArcTableContract.FragArticleArcEntry.TABLE_NAME;
                break;

            case CODE_FRAGARTICLE :
            case CODE_FRAGARTICLE_NAME  :
            case CODE_FRAGARTICLE_NAME_NAME  :
            case CODE_FRAGARTICLE_FIRSTSUBDOMAIN  :
            case CODE_FRAGARTICLE_CATEGORY :
                tablenameToInsert = FragArticleTableContract.FragArticleEntry.TABLE_NAME;
                break;

            case CODE_FRAGLOOKUP  :
            case CODE_FRAGLOOKUP_NAME  :
            case CODE_FRAGLOOKUP_NAME_NAME  :
                tablenameToInsert = FragLookupTableContract.FragLookupEntry.TABLE_NAME;
                break;


            default:
                return super.bulkInsert(uri, values);
        }
        db.beginTransaction();
        rowsInserted = 0;
        try {
            LogUtil.debug(TAG, " bulkinsert tabletoinsert name =" + tablenameToInsert);
            for (ContentValues value : values) {
                long _id = db.insertWithOnConflict(tablenameToInsert, null, value, SQLiteDatabase.CONFLICT_REPLACE);
//                long _id = db.insert(tablenameToInsert, null, value);
//                LogUtil.debug(TAG, "---> OCDE_PAGINATION db.insert id=" + _id + ", value=" + value);
                if (_id != -1) {
                    rowsInserted++;
                }
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }

        if (rowsInserted > 0) {
            if  ( (mCurrent_initial_mask ^ INITIAL_MASK_ALL) ==0) {
                //after all done the initial state
                LogUtil.debug(TAG, " bulkinsert 0 rowsinserted=" + rowsInserted);
                getContext().getContentResolver().notifyChange(uri, null);

            } else {

                mCurrent_initial_mask |= mask;
                LogUtil.debug(TAG, " bulkinsert 1 mcurrent_mask = " + mCurrent_initial_mask + ", mask=" + mask);
                if ((mask == INITIAL_MASK_LATESTNEWSPAGINATIONTABLE)
                        && ((mCurrent_initial_mask ^ INITIAL_MASK_ALL) == 0)) {
                    LogUtil.debug(TAG, " bulkinsert 2");
                    // all table have initialzed, the current URI is latestnewspaginationtable
                    getContext().getContentResolver().notifyChange(uri, null);
                    LogUtil.debug(TAG, " bulkinsert 3");
                } else if ((mCurrent_initial_mask ^ INITIAL_MASK_ALL) == 0) {
                    //all done for table initial
                    // all table have initialzed, the current URI is not latestnewspaginationtable
                    LogUtil.debug(TAG, " bulkinsert 4");
                    getContext().getContentResolver().notifyChange(LatestNewsPaginationContract.PaginationEntry.CONTENT_URI, null);
                    LogUtil.debug(TAG, " bulkinsert 5");
                    getContext().getContentResolver().notifyChange(uri, null);
                    LogUtil.debug(TAG, " bulkinsert 6");
                } else if ((mask != INITIAL_MASK_LATESTNEWSPAGINATIONTABLE)
                        ) {
                    //any URI but not latestnewspaginationtable
                    LogUtil.debug(TAG, " bulkinsert 7");
                    getContext().getContentResolver().notifyChange(uri, null);
                }
            }
        }

        return rowsInserted;

    }

    /**
     * Handles query requests from clients. We will use this method in Sunshine to query for all
     * of our weather data as well as to query for the weather on a particular day.
     *
     * @param uri           The URI to query
     * @param projection    The list of columns to put into the cursor. If null, all columns are
     *                      included.
     * @param selection     A selection criteria to apply when filtering rows. If null, then all
     *                      rows are included.
     * @param selectionArgs You may include ?s in selection, which will be replaced by
     *                      the values from selectionArgs, in order that they appear in the
     *                      selection.
     * @param sortOrder     How the rows in the cursor should be sorted.
     * @return A Cursor containing the results of the query. In our implementation,
     */
    @Override
    public Cursor query(@NonNull Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {

        //initialize cursor
        Cursor cursor=null;
                /*
                = mOpenHelper.getReadableDatabase().query(
                SignalContract.SignalEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                sortOrder);
                */
        Cursor hello;
        LogUtil.debug(TAG, "---> gongprovider query uri=" + uri);
        String lastPathSegment = uri.getLastPathSegment();
        LogUtil.debug(TAG, "---> gongprovider query lastpathsegment=" + lastPathSegment
                + ", selection=" + selection );
        String[] selectionArguments = new String[]{lastPathSegment};
        List<String> uriList = uri.getPathSegments();
        for (String x : uriList){
            LogUtil.debug(TAG, "---> gongprovider query uripath=" + x);
        }
        /*
         * Here's the switch statement that, given a URI, will determine what kind of request is
         * being made and query the database accordingly.
         */
        switch (sUriMatcher.match(uri)) {

            case CODE_PAGINATION :
                /*
                cursor  = mOpenHelper.getReadableDatabase().query(
                        LatestNewsPaginationContract.PaginationEntry.TABLE_NAME,
                        projection,
                        null,
                        null,
                        null,
                        null,
                        sortOrder);
                */

                LogUtil.debug(TAG, "query , CODE_PAGINATION");
                cursor = mOpenHelper.getReadableDatabase().rawQuery(LatestNewsPaginationContract.RAWQUERYPAGINATIONSTRING, null);
                if (cursor.getCount() > 0 ) {
                    mCurrent_initial_mask |= INITIAL_MASK_LATESTNEWSPAGINATIONTABLE;
                }

                break;

            case CODE_PAGINATION_ARCHIVE :

                LogUtil.debug(TAG, "query , CODE_PAGINATION_ARCHIVE 1 selection=" + selection );
                if (selectionArgs != null) {
                    for (int y = 0; y < selectionArgs.length; y++) {
                        LogUtil.debug(TAG, ",selectionargs=" + selectionArgs[y]);
                    }

                    cursor = mOpenHelper.getReadableDatabase().rawQuery(
                            LatestNewsPaginationArcContract.RAWQUERYPAGINATIONSELECTIONSTRING
                                    + " where "
                                    + selection
                                    + LatestNewsPaginationArcContract.RAWQUERYORDERSTRING, selectionArgs);
                    LogUtil.debug(TAG, "query , CODE_PAGINATION_ARCHIVE 2 cursor.getcount=" + cursor.getCount());
                } else {
                    cursor = mOpenHelper.getReadableDatabase().rawQuery(
                            LatestNewsPaginationArcContract.RAWQUERYPAGINATIONSELECTIONSTRING
                                    + LatestNewsPaginationArcContract.RAWQUERYORDERSTRING, null);
                    LogUtil.debug(TAG, "query , CODE_PAGINATION_ARCHIVE 3 cursor.getcount=" + cursor.getCount());

                }
                break;



            case CODE_ARTICLELOOKUP :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARTICLELOOKUP");
                if (cursor.getCount() > 0 ) {
                    mCurrent_initial_mask |= INITIAL_MASK_ARTICLELOOKUPTABLE;
                }


                break;

            case CODE_ARTICLE :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArticleTableContract.ArticleEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARTICLE");

                break;

            case CODE_CATEGORY :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        CategoryTableContract.CategoryEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_CATEGORY");
                if (cursor.getCount() > 0 ) {
                    mCurrent_initial_mask |= INITIAL_MASK_CATEGORYTABLE;
                }


                break;

            case CODE_DOMAIN:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        DomainTableContract.DomainEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_DOMAIN");
                if (cursor.getCount() > 0 ) {
                    mCurrent_initial_mask |= INITIAL_MASK_DOMAINTABLE;
                }

                break;


            case CODE_FIRSTSUBDOMAIN:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_FIRSTSUBDOMAIN");
                if (cursor.getCount() > 0 ) {
                    mCurrent_initial_mask |= INITIAL_MASK_FIRSTSUBDOMAINTABLE;
                }


                break;

            case CODE_SIGNAL:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        SignalContract.SignalEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_SIGNAL");

                break;


            case CODE_ARTICLELOOKUP_WITH_ID :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME,
                        projection,
                        ArticleLookupTableContract.ArticleLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARTICLELOOKUP_WITH_ID");

                break;

            case CODE_ARTICLE_WITH_ID :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArticleTableContract.ArticleEntry.TABLE_NAME,
                        projection,
                        ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARTICLE_WITH_ID");

                break;

            case CODE_CATEGORY_WITH_ID:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        CategoryTableContract.CategoryEntry.TABLE_NAME,
                        projection,
                        CategoryTableContract.CategoryEntry.COLUMN_CATEGORYTABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_CATEGORY_WITH_ID");

                break;

            case CODE_DOMAIN_WITH_ID:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        DomainTableContract.DomainEntry.TABLE_NAME,
                        projection,
                        DomainTableContract.DomainEntry.COLUMN_DOMAINTABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_DOMAIN_WITH_ID");
                break;

            case CODE_FIRSTSUBDOMAIN_WITH_ID:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME,
                        projection,
                        FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_FIRSTSUBDOMAIN_WITH_ID");

                break;

            case CODE_SIGNAL_WITH_ID:
                cursor  = mOpenHelper.getReadableDatabase().query(
                        SignalContract.SignalEntry.TABLE_NAME,
                        projection,
                        SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_SIGNAL_WITH_ID");

                break;

            case CODE_PAGINATION_WITH_FROMANDTO:
                List<String> pathSegment = uri.getPathSegments();
                if (pathSegment.size() < 4) {
                    Log.w(TAG,"Unknown or wrong CODE_PAGINATION_WITH_FROMANDTO uri: " + uri);
                    break;
                    //throw new UnsupportedOperationException(
                    //        "Unknown or wrong CODE_PAGINATION_WITH_FROMANDTO uri: " + uri);
                }

                List<String> fromtoPathSegment = pathSegment.subList(pathSegment.size() - 4, pathSegment.size());
                if ((fromtoPathSegment.get(0).compareTo("FROM") != 0)
                        && (fromtoPathSegment.get(3).compareTo("TO") != 0)) {
                    Log.w(TAG,"Unknown or wrong FROM TO uri: " + uri);
                    break;
                    //throw new UnsupportedOperationException(
                    //        "Unknown or wrong FROM TO uri: " + uri);
                }
                selectionArguments = new String[] { fromtoPathSegment.get(1) , fromtoPathSegment.get(3) };
                /*
                cursor = mOpenHelper.getReadableDatabase().query(
                        LatestNewsPaginationContract.PaginationEntry.TABLE_NAME,
                        projection,
                        LatestNewsPaginationContract.PaginationEntry._ID + " >= ? " +
                          LatestNewsPaginationContract.PaginationEntry._ID + " <= ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                */

                cursor = mOpenHelper.getReadableDatabase().rawQuery(LatestNewsPaginationContract.RAWQUERYPAGINATIONRANGESTRING,
                        selectionArguments);
                LogUtil.debug(TAG, "query , CODE_PAGINATION_WITH_FROMANDTO");

                break;



            case CODE_ARCHIVELATESTLOOKUP :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARCHIVELATESTLOOKUP");
                break;

            case CODE_ARCHIVELATESTLOOKUP_WITH_ID :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME,
                        projection,
                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARCHIVELATESTLOOKUP_WITH_ID");

                break;

            case CODE_ARCHIVELATESTPAGELOOKUP :
                cursor  = mOpenHelper.getReadableDatabase().query(
//                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME,
                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARCHIVELATESTPAGELOOKUP");
                break;

            case CODE_ARCHIVELATESTPAGELOOKUP_WITH_ID :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME,
                        projection,
                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_ARCHIVELATESTPAGELOOKUP_WITH_ID");

                break;

            case CODE_ARTICLE_BOOKMARK:
                LogUtil.debug(TAG, "query , CODE_ARTICLE_BOOKMARK");
                cursor = mOpenHelper.getReadableDatabase().rawQuery(ArticleTableContract.RAWQUERYBOOKMARKSTRING, null);
                break;

            case CODE_SIGNAL_FINDNOTIN:
                LogUtil.debug(TAG, "query , CODE_ARTICLE_BOOKMARK");
                cursor = mOpenHelper.getReadableDatabase().rawQuery(SignalContract.RAWFINDNOTINARTICLETABLE, null);
                break;


            case CODE_GONGINFO :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        GongInfoContract.GongInfoEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_GONGINFO");

                break;

            case CODE_GONGINFO_NAME_NAME :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(GongInfoContract.RAWQUERYGONGINFONAMESTRING,
                        selectionArguments);

                LogUtil.debug(TAG, "query , CODE_GONGINFO_NAME_NAME");
                break;

            case CODE_GONGINFOLOOKUP :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_GONGINFOLOOKUP");

                break;

            case CODE_GONGINFOLOOKUP_NAME_TYPE_NAME :
                //getting one nmae's sheeturl
                cursor  = mOpenHelper.getReadableDatabase().query(
                        GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME,
                        GongInfoLookupContract.PROJECTION,
                        GongInfoLookupContract.SELECTION_NAME,
                        selectionArguments,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_GONGINFOLOOKUP");

                break;

            case CODE_GONGINFOLOOKUP_INFONAME :
                //getting one nmae's sheeturl
                cursor  = mOpenHelper.getReadableDatabase().query(
                        GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME,
                        GongInfoLookupContract.PROJECTION,
                        GongInfoLookupContract.SELECTION_NAME,
                        selectionArguments,
                        GongInfoLookupContract.GROUP_BY_NAME,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_GONGINFOLOOKUP");

                break;

            case CODE_GONGINFOLOOKUP_ALLNAME :
                //
                cursor  = mOpenHelper.getReadableDatabase().query(
                        GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME,
                        GongInfoLookupContract.ALLNAME_PROJECTION,
                        null,
                        null,
                        GongInfoLookupContract.GROUP_BY_NAME,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_GONGINFOLOOKUP");

                break;


            case CODE_FRAGARTICLEARC :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        FragArticleArcTableContract.FragArticleArcEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_FRAGARTICLEARC");

                break;

            case CODE_FRAGARTICLEARC_NAME_NAME  :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(FragArticleArcTableContract.RAWQUERY_FRAGARTICLEARC_SELECTIONSTRING
                                + " where "
                                + selection
                                + FragArticleArcTableContract.RAWQUERY_ORDERSTRING,
                        selectionArgs);

                LogUtil.debug(TAG, "query , CODE_FRAGARTICLEARC_NAME_NAME");
                break;

            case CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN_ID  :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(FragArticleArcTableContract.RAWQUERY_FRAGARTICLEARC_FIRSTSUBSTRING,
                        selectionArguments);

                LogUtil.debug(TAG, "query , CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN_ID");
                break;

            case CODE_FRAGARTICLEARC_CATEGORY_ID :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(FragArticleArcTableContract.RAWQUERY_FRAGARTICLEARC_CATEGORYSTRING,
                        selectionArguments);

                LogUtil.debug(TAG, "query , CODE_FRAGARTICLEARC_CATEGORY_ID");
                break;

            case CODE_FRAGARTICLE :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        FragArticleTableContract.FragArticleEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_FRAGARTICLE");

                break;

            case CODE_FRAGARTICLE_NAME_NAME  :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(FragArticleTableContract.RAWQUERY_FRAGARTICLE_NAMESTRING,
                        selectionArguments);

                LogUtil.debug(TAG, "query , CODE_FRAGARTICLE_NAME_NAME");
                break;

            case CODE_FRAGARTICLE_FIRSTSUBDOMAIN_ID  :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(FragArticleTableContract.RAWQUERY_FRAGARTICLE_FIRSTSUBSTRING,
                        selectionArguments);

                LogUtil.debug(TAG, "query , CODE_FRAGARTICLE_FIRSTSUBDOMAIN_ID");
                break;
            case CODE_FRAGARTICLE_CATEGORY_ID :
                cursor = mOpenHelper.getReadableDatabase().rawQuery(FragArticleTableContract.RAWQUERY_FRAGARTICLE_CATEGORYSTRING,
                        selectionArguments);

                LogUtil.debug(TAG, "query , CODE_FRAGARTICLE_CATEGORY_ID");
                break;

            case CODE_FRAGLOOKUP  :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        FragLookupTableContract.FragLookupEntry.TABLE_NAME,
                        projection,
                        selection,
                        selectionArgs,
                        null,
                        null,
                        sortOrder);
                LogUtil.debug(TAG, "query , CODE_FRAGLOOKUP");

                break;

            case CODE_FRAGLOOKUP_NAME_NAME  :
                cursor  = mOpenHelper.getReadableDatabase().query(
                        FragLookupTableContract.FragLookupEntry.TABLE_NAME,
                        FragLookupTableContract.PROJECTION,
                        FragLookupTableContract.SELECTION_NAME,
                        selectionArguments,
                        null,
                        null,
                        FragLookupTableContract.ORDER_BY_SHEER_ID);
                LogUtil.debug(TAG, "query , CODE_FRAGLOOKUP_NAME_NAME");

                break;


            default:
                throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        //Uri forecastQueryUri = WeatherContract.WeatherEntry.CONTENT_URI;
        //cursor.setNotificationUri(getContext().getContentResolver(), forecastQueryUri);
        if (cursor != null) {
            cursor.setNotificationUri(getContext().getContentResolver(), uri);
            LogUtil.debug(TAG, " query setnotification=" + uri + " ,cursor.getcount= " + cursor.getCount());
        }//getApplicationContext().getContentResolver().notifyChange(forecastQueryUri, null);

        return cursor;
    }

    /**
     * Deletes data at a given URI with optional arguments for more fine tuned deletions.
     *
     * @param uri           The full URI to query
     * @param selection     An optional restriction to apply to rows when deleting.
     * @param selectionArgs Used in conjunction with the selection statement
     * @return The number of rows deleted
     */
    @Override
    public int delete(@NonNull Uri uri, String selection, String[] selectionArgs) {
        LogUtil.debug(TAG, "---> gongprovider delete uri=" + uri);
        String lastPathSegment = uri.getLastPathSegment();
        String[] selectionArguments = new String[]{lastPathSegment};
        String[] finalselectionArg = selectionArgs;

        /* Users of the delete method will expect the number of rows deleted to be returned. */
        int numRowsDeleted=0;
        String tablenameToDelete="NOTABLE";

        /*
         * If we pass null as the selection to SQLiteDatabase#delete, our entire table will be
         * deleted. However, if we do pass null and delete all of the rows in the table, we won't
         * know how many rows were deleted. According to the documentation for SQLiteDatabase,
         * passing "1" for the selection will delete all rows and return the number of rows
         * deleted, which is what the caller of this method expects.
         */
        if (null == selection) selection = "1";
        LogUtil.debug(TAG, "---> gongprovider delete match-uri="+ sUriMatcher.match(uri));
        switch (sUriMatcher.match(uri)) {

            case CODE_PAGINATION:
                tablenameToDelete = LatestNewsPaginationContract.PaginationEntry.TABLE_NAME;
                break;

            case CODE_PAGINATION_ARCHIVE:
                tablenameToDelete = LatestNewsPaginationArcContract.PaginationArcEntry.TABLE_NAME;
                break;

            case CODE_ARTICLELOOKUP:
                tablenameToDelete = ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME;
                break;

            case CODE_ARTICLE:
                tablenameToDelete = ArticleTableContract.ArticleEntry.TABLE_NAME;
                break;

            case CODE_ARTICLE_WITH_ID:
                tablenameToDelete = ArticleTableContract.ArticleEntry.TABLE_NAME;
                finalselectionArg = selectionArguments;
                break;


            case CODE_CATEGORY:
                tablenameToDelete = CategoryTableContract.CategoryEntry.TABLE_NAME;
                break;

            case CODE_DOMAIN:
                tablenameToDelete = DomainTableContract.DomainEntry.TABLE_NAME;
                break;

            case CODE_FIRSTSUBDOMAIN:
                tablenameToDelete = FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME;
                break;

            case CODE_SIGNAL:
                tablenameToDelete = SignalContract.SignalEntry.TABLE_NAME;
                break;

            case CODE_ARCHIVELATESTLOOKUP:
                tablenameToDelete = ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME;
                break;

            case CODE_ARCHIVELATESTPAGELOOKUP:
                tablenameToDelete = ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME;
                break;

            case CODE_GONGINFO:
                tablenameToDelete = GongInfoContract.GongInfoEntry.TABLE_NAME;
                break;

            case CODE_GONGINFOLOOKUP:
                tablenameToDelete = GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME;
                break;


            default:
                Log.w(TAG, "Unknown uri: " + uri);
                break;
                //throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        numRowsDeleted = mOpenHelper.getWritableDatabase().delete(
                tablenameToDelete,
                selection,
                finalselectionArg);

        /* If we actually deleted any rows, notify that a change has occurred to this URI */
        if (numRowsDeleted != 0) {
            //getContext().getContentResolver().notifyChange(uri, null);
        }

        return numRowsDeleted;
    }

    /**
     * In Sunshine, we aren't going to do anything with this method. However, we are required to
     * override it as WeatherProvider extends ContentProvider and getType is an abstract method in
     * ContentProvider. Normally, this method handles requests for the MIME type of the data at the
     * given URI. For example, if your app provided images at a particular URI, then you would
     * return an image URI from this method.
     *
     * @param uri the URI to query.
     * @return nothing in Sunshine, but normally a MIME type string, or null if there is no type.
     */
    @Override
    public String getType(@NonNull Uri uri) {
        LogUtil.debug(TAG, "---> gongprovider gettype uri=" + uri);
        return "image/png"; // just return something instead of throw

        //throw new RuntimeException("We are not implementing getType in Sunshine.");
    }

    /**
     * In Sunshine, we aren't going to do anything with this method. However, we are required to
     * override it as WeatherProvider extends ContentProvider and insert is an abstract method in
     * ContentProvider. Rather than the single insert method, we are only going to implement
     *
     *
     * @param uri    The URI of the insertion request. This must not be null.
     * @param values A set of column_name/value pairs to add to the database.
     *               This must not be null
     * @return nothing in Sunshine, but normally the URI for the newly inserted item.
     */
    @Override
    public Uri insert(@NonNull Uri uri, ContentValues values) {

        LogUtil.debug(TAG, "---> gongprovider insert uri=" + uri);
        String lastPathSegment = uri.getLastPathSegment();
        String[] selectionArguments = new String[]{lastPathSegment};
        LogUtil.debug(TAG, "---> gongprovider insert uri=" + uri +", lastpathsegment=" + lastPathSegment);

        LogUtil.debug(TAG, "---> gongprovider insert match uri=" + sUriMatcher.match(uri));

        long rowresult=0;
        Cursor cursor;
        String sortOrder;
        switch (sUriMatcher.match(uri)) {

            case CODE_FRAGARTICLEARC :
            case CODE_FRAGARTICLEARC_NAME_NAME  :
            case CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN  :
            case CODE_FRAGARTICLEARC_CATEGORY :
                rowresult = mOpenHelper.getWritableDatabase().insertWithOnConflict(
                        FragArticleArcTableContract.FragArticleArcEntry.TABLE_NAME,
                        null,
                        values,
                        SQLiteDatabase.CONFLICT_REPLACE);
                LogUtil.debug(TAG, " insert update CODE_FRAGARTICLEARC rowresult = " + rowresult);
                break;

            case CODE_FRAGARTICLE :
            case CODE_FRAGARTICLE_NAME_NAME  :
            case CODE_FRAGARTICLE_FIRSTSUBDOMAIN  :
            case CODE_FRAGARTICLE_CATEGORY :
                rowresult = mOpenHelper.getWritableDatabase().insertWithOnConflict(
                        FragArticleTableContract.FragArticleEntry.TABLE_NAME,
                        null,
                        values,
                        SQLiteDatabase.CONFLICT_REPLACE);
                LogUtil.debug(TAG, " insert update CODE_FRAGARTICLE rowresult = " + rowresult);
                break;

            case CODE_FRAGLOOKUP  :
            case CODE_FRAGLOOKUP_NAME  :
                rowresult = mOpenHelper.getWritableDatabase().insertWithOnConflict(
                        FragLookupTableContract.FragLookupEntry.TABLE_NAME,
                        null,
                        values,
                        SQLiteDatabase.CONFLICT_REPLACE);
                LogUtil.debug(TAG, " insert  CODE_FRAGLOOKUP rowresult = " + rowresult);
                break;


            case CODE_ARTICLE_BOOKMARK :
                rowresult = mOpenHelper.getWritableDatabase().insertWithOnConflict(
                        ArticleTableContract.ArticleEntry.TABLE_NAME,
                        null,
                        values,
                        SQLiteDatabase.CONFLICT_REPLACE);
                LogUtil.debug(TAG, " insert  CODE_ARTICLE_BOOKMARK rowresult = " + rowresult);
                break;

            case CODE_SIGNAL :
            case CODE_SIGNAL_WITH_ID :
                //find whether there is one
                int articleID=0;

                if (values.containsKey(SignalContract.SignalEntry.COLUMN_ARTICLE_ID)){
                    articleID = (int) values.get(SignalContract.SignalEntry.COLUMN_ARTICLE_ID);
                    selectionArguments = new String[]{String.valueOf(articleID)};
                }
                sortOrder = SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " ASC ";
                cursor  = mOpenHelper.getReadableDatabase().query(
                        SignalContract.SignalEntry.TABLE_NAME,
                        SignalContract.PROJECTION,
                        SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);

                if ( (cursor == null) || (cursor.getCount() == 0)) {
                    rowresult  = mOpenHelper.getWritableDatabase().insert(SignalContract.SignalEntry.TABLE_NAME,
                            null,
                            values);
                    if (rowresult == -1){
                        Log.w(TAG, " insert error in gong. code_signal ");
                        //throw new RuntimeException(
                        //        " insert error in gong. code_signal ");

                    }
                    LogUtil.debug(TAG, " insert rowresult = " + rowresult);
                    getContext().getContentResolver().notifyChange(SignalContract.SignalEntry.CONTENT_URI, null);
                    return SignalContract.SignalEntry.CONTENT_URI;
                } else {
                    //do update if there is one
                    //String[] whereargs = { String.valueOf( (long) cursor.getLong(SignalContract.INDEX_ARTICLE_ID)) };

                    rowresult = mOpenHelper.getWritableDatabase().update(
                            SignalContract.SignalEntry.TABLE_NAME,
                            values,
                            SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " = ? ",
                            selectionArguments
                    );
                    if (rowresult != 1){
                        Log.w(TAG, " insert update error in gong. code_signal ");
                        //throw new RuntimeException(
                        //        " insert update error in gong. code_signal ");

                    }
                    LogUtil.debug(TAG, " insert update CODE_SIGNAL_WITH_ID rowresult = " + rowresult);
                    getContext().getContentResolver().notifyChange(SignalContract.SignalEntry.CONTENT_URI, null);
                    return  uri;
                }
            case CODE_ARTICLE_WITH_ID :
                //find whether there is one
                LogUtil.debug(TAG, " insert CODE_ARTICLE_WITH_ID lastPathSegment = " + lastPathSegment);
                sortOrder = ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID  + " ASC ";
                cursor  = mOpenHelper.getReadableDatabase().query(
                        ArticleTableContract.ArticleEntry.TABLE_NAME,
                        ArticleTableContract.PROJECTION,
                        ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " = ? ",
                        selectionArguments,
                        null,
                        null,
                        sortOrder);

                if ( (cursor == null) || (cursor.getCount() == 0)) {
                    rowresult  = mOpenHelper.getWritableDatabase().insert(ArticleTableContract.ArticleEntry.TABLE_NAME,
                            null,
                            values);
                    if (rowresult == -1){
                        Log.w(TAG, " insert error in gong. CODE_ARTICLE_WITH_ID ");
                        //throw new RuntimeException(
                        //        " insert error in gong. CODE_ARTICLE_WITH_ID ");

                    }
                    LogUtil.debug(TAG, " insert CODE_ARTICLE_WITH_ID rowresult = " + rowresult);
                    getContext().getContentResolver().notifyChange(uri, null);

                    return uri;
                } else {
                    //do update if there is one
                    //String[] whereargs = { String.valueOf( (long) cursor.getLong(SignalContract.INDEX_ARTICLE_ID)) };

                    rowresult = mOpenHelper.getWritableDatabase().update(
                            ArticleTableContract.ArticleEntry.TABLE_NAME,
                            values,
                            ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID  + " = ? ",
                            selectionArguments
                    );
                    if (rowresult != 1){
                        Log.w(TAG, " insert update error in gong. CODE_ARTICLE_WITH_ID ");
                        //throw new RuntimeException(
                        //        " insert update error in gong. CODE_ARTICLE_WITH_ID ");

                    }
                    LogUtil.debug(TAG, " insert update CODE_ARTICLE_WITH_ID rowresult = " + rowresult);
                    getContext().getContentResolver().notifyChange(uri, null);

                    return  uri;
                }

            case CODE_PAGINATION:
            case CODE_PAGINATION_ARCHIVE:
            case CODE_PAGINATION_WITH_FROMANDTO :
            case CODE_CATEGORY :
            case CODE_DOMAIN :
            case CODE_FIRSTSUBDOMAIN :
            case CODE_ARTICLELOOKUP :
            case CODE_ARTICLE :
            case CODE_CATEGORY_WITH_ID :
            case CODE_DOMAIN_WITH_ID :
            case CODE_FIRSTSUBDOMAIN_WITH_ID :
            case CODE_ARTICLELOOKUP_WITH_ID :
            case CODE_ARCHIVELATESTLOOKUP :
            case CODE_ARCHIVELATESTLOOKUP_WITH_ID :
            case CODE_ARCHIVELATESTPAGELOOKUP :
            case CODE_ARCHIVELATESTPAGELOOKUP_WITH_ID :
            case CODE_GONGINFO:
            case CODE_GONGINFO_NAME_NAME:
            case CODE_GONGINFO_WITH_ID:
            case CODE_GONGINFOLOOKUP:
            case CODE_GONGINFOLOOKUP_ALLNAME:
            case CODE_GONGINFOLOOKUP_INFONAME:
            case CODE_GONGINFOLOOKUP_NAME_TYPE_NAME:
            case CODE_GONGINFOLOOKUP_WITH_ID:
            default:
                Log.w(TAG, "We are not implementing insert in gong for " + sUriMatcher.match(uri));
                //throw new RuntimeException(
                //        "We are not implementing insert in gong for " + sUriMatcher.match(uri));

        }
        getContext().getContentResolver().notifyChange(uri, null);
        return uri;
    }

    @Override
    public int update(@NonNull Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        LogUtil.debug(TAG, "--> gongprovider update uri=" + uri);
        String lastPathSegment = uri.getLastPathSegment();
        String[] selectionArguments = new String[]{lastPathSegment};
        LogUtil.debug(TAG, "---> gongprovider update uri=" + uri +", lastpathsegment=" + lastPathSegment);

        LogUtil.debug(TAG, "---> gongprovider update match uri=" + sUriMatcher.match(uri));

        int rowresult=0;
        Cursor cursor;
        String sortOrder;
        switch (sUriMatcher.match(uri)) {

            case CODE_FRAGLOOKUP  :
            case CODE_FRAGLOOKUP_NAME  :
            case CODE_FRAGLOOKUP_NAME_NAME  :
                rowresult = mOpenHelper.getWritableDatabase().updateWithOnConflict(
                        FragLookupTableContract.FragLookupEntry.TABLE_NAME,
                        values,
                        FragLookupTableContract.SELECTION_NAME,
                        selectionArguments,
                        SQLiteDatabase.CONFLICT_REPLACE);
                LogUtil.debug(TAG, "  update CODE_FRAGLOOKUP rowresult = " + rowresult);
                break;

            case CODE_FRAGARTICLE :
            case CODE_FRAGARTICLE_NAME  :
            case CODE_FRAGARTICLE_FIRSTSUBDOMAIN  :
            case CODE_FRAGARTICLE_CATEGORY :
            case CODE_FRAGARTICLEARC :
            case CODE_FRAGARTICLEARC_NAME  :
            case CODE_FRAGARTICLEARC_FIRSTSUBDOMAIN  :
            case CODE_FRAGARTICLEARC_CATEGORY :
            case CODE_SIGNAL :
            case CODE_SIGNAL_WITH_ID :
            case CODE_ARTICLE_WITH_ID :
            case CODE_PAGINATION:
            case CODE_PAGINATION_ARCHIVE:
            case CODE_PAGINATION_WITH_FROMANDTO :
            case CODE_CATEGORY :
            case CODE_DOMAIN :
            case CODE_FIRSTSUBDOMAIN :
            case CODE_ARTICLELOOKUP :
            case CODE_ARTICLE :
            case CODE_CATEGORY_WITH_ID :
            case CODE_DOMAIN_WITH_ID :
            case CODE_FIRSTSUBDOMAIN_WITH_ID :
            case CODE_ARTICLELOOKUP_WITH_ID :
            case CODE_ARCHIVELATESTLOOKUP :
            case CODE_ARCHIVELATESTLOOKUP_WITH_ID :
            case CODE_ARCHIVELATESTPAGELOOKUP :
            case CODE_ARCHIVELATESTPAGELOOKUP_WITH_ID :
            case CODE_GONGINFO:
            case CODE_GONGINFO_NAME_NAME:
            case CODE_GONGINFO_WITH_ID:
            case CODE_GONGINFOLOOKUP:
            case CODE_GONGINFOLOOKUP_ALLNAME:
            case CODE_GONGINFOLOOKUP_INFONAME:
            case CODE_GONGINFOLOOKUP_NAME_TYPE_NAME:
            case CODE_GONGINFOLOOKUP_WITH_ID:
            default:
                Log.w(TAG, "We are not implementing insert in gong for " + sUriMatcher.match(uri));

                //throw new RuntimeException(
                //        "We are not implementing insert in gong for " + sUriMatcher.match(uri));

        }


        getContext().getContentResolver().notifyChange(uri, null);

        return rowresult;
    }

    /**
     * You do not need to call this method. This is a method specifically to assist the testing
     * framework in running smoothly. You can read more at:
     * http://developer.android.com/reference/android/content/ContentProvider.html#shutdown()
     */
    @Override
    @TargetApi(11)
    public void shutdown() {
        mOpenHelper.close();
        super.shutdown();
    }
}
