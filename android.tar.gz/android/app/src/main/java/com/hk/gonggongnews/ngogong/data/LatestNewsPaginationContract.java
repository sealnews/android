package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;




/**
 * Created by ismile on 10/6/2017.
 */

public class LatestNewsPaginationContract {
    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_PAGINATION = "latestnewspagination";
    public static final int INDEX_RAWQUERY_PAGINATION_ID = 0;
    public static final int INDEX_RAWQUERY_PAGINATION_FINALURL = 1;
    public static final int INDEX_RAWQUERY_PAGINATION_TIMESTAMPONDOC = 2;
    public static final int INDEX_RAWQUERY_PAGINATION_TITLE = 3;
    public static final int INDEX_RAWQUERY_PAGINATION_IMAGEURL = 4;
    public static final int INDEX_RAWQUERY_PAGINATION_SIMILARITIESCOUNT = 5;
    public static final int INDEX_RAWQUERY_PAGINATION_ENTRY = 6;
    public static final int INDEX_RAWQUERY_PAGINATION_FIRSTSUBDOMAINTABLE_ID= 7;
    public static final int INDEX_RAWQUERY_PAGINATION_TIMESTAMPONDOCANDID = 8;
    public static final int INDEX_RAWQUERY_PAGINATION_ARTICLE_ID = 9;
    public static final int INDEX_RAWQUERY_SIGNAL_BOOKMARKALREADY = 10;
    public static final int INDEX_RAWQUERY_SIGNAL_READALREADY = 11;
    public static final int INDEX_RAWQUERY_FIRSTSUBDOMAIN_SOURCEICONURL = 12;
    public static final String RAWQUERYORDERSTRING = " order by pagination.timestampondocandid DESC ";
    public static final String RAWQUERYPAGINATIONWHERESTRING = " pagination._id >= ? and pagination._id <= ? ";
    public static final String RAWQUERYPAGINATIONSELECTIONSTRING =
            " select pagination._id as pagination_id, "
                    + " pagination.finalurl as pagination_finalurl, "
                    + " pagination.timestampondoc as pagination_timestampondoc, "
                    + " pagination.title as pagination_title, "
                    + " pagination.imageurl as pagination_imageurl, "
                    + " pagination.similiaritiescount as pagination_similaritiescount, "
                    + " pagination.entry as pagination_entry, "
                    + " pagination.firstsubdomaintable_id as pagination_firstsubdomaintable_id, "
                    + " pagination.timestampondocandid as pagination_timestampondocandid, "
                    + " pagination.article_id as pagination_article_id, "
                    + " signal.bookmarkalready as signal_bookmarkalready, "
                    + " signal.readalready as signal_readalready, "
                    + " firstsubdomain.sourceiconurl as firstsubdomain_sourceiconurl "
                    + " from pagination "
                    + " left join firstsubdomain on pagination.firstsubdomaintable_id = firstsubdomain.firstsubdomaintable_id "
                    + " left join signal on pagination.article_id = signal.article_id ";
    public static final String RAWQUERYPAGINATIONRANGESTRING = RAWQUERYPAGINATIONSELECTIONSTRING
            + " where " + RAWQUERYPAGINATIONWHERESTRING
            + RAWQUERYORDERSTRING;
    public static final String RAWQUERYPAGINATIONSTRING = RAWQUERYPAGINATIONSELECTIONSTRING
            + RAWQUERYORDERSTRING;

    public static final class PaginationEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_PAGINATION)
                .build();

        public static final String TABLE_NAME = "pagination";

        public static final String COLUMN_TIMESTAMPONDOC_AND_ID = "timestampondocandid";
        public static final String COLUMN_ARTICLEID = "article_id";
        public static final String COLUMN_TIMESTAMPONDOC = "timestampondoc";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_FINALURL = "finalurl";
        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_IMAGEURL = "imageurl";
        public static final String COLUMN_SIMILARITIESCOUNT = "similiaritiescount";
        public static final String COLUMN_ENTRY = "entry";

        public static Uri buildPaginationUriWithTimestampondocAndId(String timestampondocandid) {
            return CONTENT_URI.buildUpon()
                    .appendPath(timestampondocandid)
                    .build();
        }

        public static String decodeGetTimestampondoc(String timestampondocandid) {
            String timestamp = timestampondocandid.split("Z")[0];
            return timestamp;
        }

        public static String decodeGetId(String timestampondocandid) {
            String id = timestampondocandid.split("Z")[1];
            return id;
        }
    }
}

