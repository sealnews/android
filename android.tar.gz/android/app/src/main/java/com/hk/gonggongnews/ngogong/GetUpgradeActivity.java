package com.hk.gonggongnews.ngogong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.View;

import com.hk.gonggongnews.ngogong.util.LogUtil;

/**
 * Created by ismile on 2/19/2018.
 */

public class GetUpgradeActivity extends AppCompatActivity {

    private final String TAG = GetUpgradeActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getupgrade);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);

        View textview = findViewById(R.id.upgrade_text);
        textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.hk.gonggongnews.ngogong"));
                startActivity(intent);
            }
        });


    }

}


