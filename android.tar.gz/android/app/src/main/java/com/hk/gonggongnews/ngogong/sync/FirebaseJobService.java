package com.hk.gonggongnews.ngogong.sync;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.preference.PreferenceManager;

import com.hk.gonggongnews.ngogong.R;
import com.hk.gonggongnews.ngogong.data.GongDbHelper;
import com.hk.gonggongnews.ngogong.util.LogUtil;

//import com.firebase.jobdispatcher.Job;
/*
import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
*/
import android.app.job.JobParameters;
import android.app.job.JobService;

import com.firebase.jobdispatcher.JobTrigger;
import com.firebase.jobdispatcher.RetryStrategy;
import com.firebase.jobdispatcher.Trigger;
import com.firebase.jobdispatcher.TriggerReason;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hk.gonggongnews.ngogong.data.ArchiveLatestLookupContract;
import com.hk.gonggongnews.ngogong.data.ArchiveLatestPageLookupContract;
import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.CategoryTableContract;
import com.hk.gonggongnews.ngogong.data.DomainTableContract;
import com.hk.gonggongnews.ngogong.data.FirstSubdomainTableContract;
import com.hk.gonggongnews.ngogong.data.GongPreference;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import static com.hk.gonggongnews.ngogong.sync.FirebaseIntentService.ARTICLELOOKUPTABLE;
//import static com.hk.gonggongnews.ngogong.sync.FirebaseIntentService.ENTRY;

/**
 * Created by ismile on 10/11/2017.
 */


public class FirebaseJobService extends JobService {
    private final String TAG = FirebaseJobService.class.getSimpleName();
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mLatestNewsTableDatabaseReference;


    private AsyncTask<Void, Void, Void> mFetchFirebaseTask;


    private AsyncTask<Void, Void, Void> mCheckArticleLookupTableTask;
    private AsyncTask<Void, Void, Void> mCheckCategoryTableTask;
    private AsyncTask<Void, Void, Void> mCheckDomainTableTask;
    private AsyncTask<Void, Void, Void> mCheckFirstSubDomainTableTask;
    private AsyncTask<Void, Void, Void> mCheckLatestNewsTableTask;
    private AsyncTask<Void, Void, Void> mCheckArchiveLatestLookupTableTask;
    private AsyncTask<Void, Void, Void> mCheckArchiveLatestPageLookupTableTask;


    private FirebaseJobService.CheckArticleLookupTableTask mArticleLookupTableTask;
    private FirebaseJobService.CheckCategoryTableTask mCategoryTableTask;
    private FirebaseJobService.CheckDomainTableTask mDomainTableTask ;
    private FirebaseJobService.CheckFirstSubDomainTableTask mFirstSubDomainTableTask;
    private FirebaseJobService.CheckArchiveLatestLookupTableTask mArchiveLatestLookupTableTask ;
    private FirebaseJobService.CheckArchiveLatestPageLookupTableTask mArchiveLatestPageLookupTableTask ;
    private FirebaseJobService.CheckMinUpgradeTask mMinUpgradeTask ;


    private static class CheckArticleLookupTableTask  extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckArticleLookupTableTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckArticleLookupTableTask(JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckArticleLookupTableTask constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckArticleLookupTableTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.ARTICLELOOKUP_LASTUPDATETIME_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.ARTICLELOOKUPTABLE)
                    .child(FirebaseIntentService.LASTUPDATETIME)
                    .addValueEventListener(eventlastUpdateTime);
            ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.ARTICLELOOKUP_NOOFENTRY_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.ARTICLELOOKUPTABLE)
                    .child(FirebaseIntentService.NOOFENTRY)
                    .addValueEventListener(eventnoofentry);
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.ARTICLELOOKUPTABLE)
                    .child(FirebaseIntentService.ENTRY);
            reference.keepSynced(true);

            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange 1");
                            Map<String, String> entrymap = (Map<String, String>)
                                    (dataSnapshot.getValue());
                            int sizeOfEntryMap = entrymap.size();
                            if (sizeOfEntryMap > 0) {
                                ContentValues singlearticleentryvalue;
                                ContentValues[] entryvalues = new ContentValues[sizeOfEntryMap];
                                int count = 0;
                                for (Map.Entry<String, String> indrelatedata : entrymap.entrySet()) {
                                    LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID,
                                            indrelatedata.getKey());
                                    singlearticleentryvalue.put(ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID_URL,
                                            indrelatedata.getValue());
                                    entryvalues[count++] = singlearticleentryvalue;
                                }
                                ContentResolver gongContentResolver = mContextReference.get().getContentResolver();

                                        /* Insert our new weather data into Sunshine's ContentProvider */
                                int result = 0;
                                result = gongContentResolver.delete(
                                        ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI,
                                        null,
                                        null);
                                LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange  done delete result=" + result);
                                result = gongContentResolver.bulkInsert(
                                        ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI,
                                        entryvalues);
                                LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange  DONE INSERT result =" + result);
                            }
                            LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange 2");
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckArticleLookupTableTask oncancelled ");
                        }
                    });

            LogUtil.debug(TAG, " CheckArticleLookupTableTask 4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }


    }


    private static class CheckCategoryTableTask   extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckCategoryTableTask .class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckCategoryTableTask (JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckCategoryTableTask  constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckCategoryTableTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.CATEGORY_LASTUPDATETIME_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.CATEGORYTABLE)
                    .child(FirebaseIntentService.LASTUPDATETIME)
                    .addValueEventListener(eventlastUpdateTime);
            ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.CATEGORY_NOOFENTRY_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.CATEGORYTABLE)
                    .child(FirebaseIntentService.NOOFENTRY)
                    .addValueEventListener(eventnoofentry);

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.CATEGORYTABLE)
                    .child(FirebaseIntentService.ENTRY);
            reference.keepSynced(true);
            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange 1 ");
                            ArrayList<Map<String, Object>> arrayList = (ArrayList<Map<String, Object>>) dataSnapshot.getValue();
                            int sizeOfArrayList = arrayList.size();
                            boolean firstelementIsNull = false;
                            if ((sizeOfArrayList > 0) && (arrayList.get(0) == null)) {
                                firstelementIsNull = true;
                            }
                            //Map<String, Object> entrymap = (Map<String, Object>)
                            //        (((HashMap<String, Object>) dataSnapshot.getValue()));

                            //int sizeOfEntryMap = entrymap.size();
                            //if (sizeOfEntryMap > 0) {
                            if (sizeOfArrayList > 0) {
                                ContentValues singlearticleentryvalue;
                                ContentValues[] entryvalues = new ContentValues[firstelementIsNull ? sizeOfArrayList - 1 : sizeOfArrayList];
                                int count = 0;
                                int startarrayListIndex = firstelementIsNull ? 1 : 0;
                                //for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                for (Map<String, Object> indrelatedata : arrayList) {
                                    LogUtil.debug(TAG, " map information ");
                                    if (indrelatedata == null) {
                                        continue;
                                    }

                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(CategoryTableContract.CategoryEntry.COLUMN_CATEGORYTABLE_ID,
                                            (long) indrelatedata.get("id"));
                                    singlearticleentryvalue.put(CategoryTableContract.CategoryEntry.COLUMN_CHI_NAME,
                                            (String) indrelatedata.get(
                                                    CategoryTableContract.CategoryEntry.COLUMN_CHI_NAME
                                            ));
                                    singlearticleentryvalue.put(CategoryTableContract.CategoryEntry.COLUMN_ENG_NAME,
                                            (String) indrelatedata.get(
                                                    CategoryTableContract.CategoryEntry.COLUMN_ENG_NAME
                                            ));

                                    entryvalues[count++] = singlearticleentryvalue;


                                }
                                LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange 1.2 ");
                                ContentResolver gongContentResolver = mContextReference.get().getContentResolver();
                                LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange 2 ");

                                int result = 0;
                                result = gongContentResolver.delete(
                                        CategoryTableContract.CategoryEntry.CONTENT_URI,
                                        null,
                                        null);
                                LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange  done delete result=" + result);
                                result = gongContentResolver.bulkInsert(
                                        CategoryTableContract.CategoryEntry.CONTENT_URI,
                                        entryvalues);
                                LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange  DONE INSERT result =" + result);
                            }
                        }


                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckCategoryTableTask oncancelled ");
                        }
                    });


            LogUtil.debug(TAG, " CheckCategoryTableTask  4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }


    }

    private static class CheckDomainTableTask    extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckDomainTableTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckDomainTableTask  (JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckDomainTableTask   constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckDomainTableTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.DOMAIN_LASTUPDATETIME_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.DOMAINTABLE)
                    .child(FirebaseIntentService.LASTUPDATETIME)
                    .addValueEventListener(eventlastUpdateTime);
            ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.DOMAIN_NOOFENTRY_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.DOMAINTABLE)
                    .child(FirebaseIntentService.NOOFENTRY)
                    .addValueEventListener(eventnoofentry);

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.DOMAINTABLE)
                    .child(FirebaseIntentService.ENTRY);
            reference.keepSynced(true);
            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckDomainTableTask ondatachange ");
                            ArrayList<Map<String, Object>> arrayList = (ArrayList<Map<String, Object>>) dataSnapshot.getValue();
                            int sizeOfArrayList = arrayList.size();
                            boolean firstelementIsNull = false;
                            if ((sizeOfArrayList > 0) && (arrayList.get(0) == null)) {
                                firstelementIsNull = true;
                            }

                            //Map<String, Object> entrymap = (Map<String, Object>)
                            //        (((HashMap<String, Object>) dataSnapshot.getValue()).get("entry"));

                            //int sizeOfEntryMap = entrymap.size();
                            if (sizeOfArrayList > 0) {
                                ContentValues singlearticleentryvalue;
                                ContentValues[] entryvalues = new ContentValues[firstelementIsNull ? sizeOfArrayList - 1 : sizeOfArrayList];
                                int count = 0;
                                int startarrayListIndex = firstelementIsNull ? 1 : 0;
                                //for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                for (Map<String, Object> indrelatedata : arrayList) {
                                    LogUtil.debug(TAG, " map information ");
                                    if (indrelatedata == null) {
                                        continue;
                                    }

                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_DOMAINTABLE_ID,
                                            (Long) indrelatedata.get("id"));
                                    singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_CHI_NAME,
                                            (String) indrelatedata.get(
                                                    DomainTableContract.DomainEntry.COLUMN_CHI_NAME
                                            ));
                                    singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_ENG_NAME,
                                            (String) indrelatedata.get(
                                                    DomainTableContract.DomainEntry.COLUMN_ENG_NAME
                                            ));
                                    singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_BASEURL,
                                            (String) indrelatedata.get(
                                                    DomainTableContract.DomainEntry.COLUMN_BASEURL
                                            ));

                                    entryvalues[count++] = singlearticleentryvalue;
                                }
                                ContentResolver gongContentResolver = mContextReference.get().getContentResolver();

                                int result = 0;
                                result = gongContentResolver.delete(
                                        DomainTableContract.DomainEntry.CONTENT_URI,
                                        null,
                                        null);
                                LogUtil.debug(TAG, "mCheckDomainTableTask ondatachange  done delete result=" + result);
                                result = gongContentResolver.bulkInsert(
                                        DomainTableContract.DomainEntry.CONTENT_URI,
                                        entryvalues);
                                LogUtil.debug(TAG, "mCheckDomainTableTask ondatachange  DONE INSERT result =" + result);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckDomainTableTask oncancelled ");
                        }
                    });


            LogUtil.debug(TAG, " CheckDomainTableTask   4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }
    }



    private static class CheckFirstSubDomainTableTask     extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckFirstSubDomainTableTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckFirstSubDomainTableTask   (JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckFirstSubDomainTableTask    constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckFirstSubDomainTableTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.FIRSTSUBDOMAIN_LASTUPDATETIME_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.FIRSTSUBDOMAINTABLE)
                    .child(FirebaseIntentService.LASTUPDATETIME)
                    .addValueEventListener(eventlastUpdateTime);
            ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.FIRSTSUBDOMAIN_NOOFENTRY_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.FIRSTSUBDOMAINTABLE)
                    .child(FirebaseIntentService.NOOFENTRY)
                    .addValueEventListener(eventnoofentry);

            LogUtil.debug(TAG, " mCheckFirstSubDomainTableTask 4 ");

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.FIRSTSUBDOMAINTABLE)
                    .child(FirebaseIntentService.ENTRY);
            reference.keepSynced(true);
            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask ondatachange ");
                            ArrayList<Map<String, Object>> arrayList = (ArrayList<Map<String, Object>>) dataSnapshot.getValue();
                            int sizeOfArrayList = arrayList.size();
                            boolean firstelementIsNull = false;
                            if ((sizeOfArrayList > 0) && (arrayList.get(0) == null)) {
                                firstelementIsNull = true;
                            }

                            //Map<String, Object> entrymap = (Map<String, Object>)
                            //        (((HashMap<String, Object>) dataSnapshot.getValue()).get("entry"));

                            //int sizeOfEntryMap = entrymap.size();
                            if (sizeOfArrayList > 0) {
                                ContentValues singlearticleentryvalue;
                                ContentValues[] entryvalues = new ContentValues[firstelementIsNull ? sizeOfArrayList - 1 : sizeOfArrayList];
                                int count = 0;
                                int startarrayListIndex = firstelementIsNull ? 1 : 0;
                                //for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                for (Map<String, Object> indrelatedata : arrayList) {
                                    LogUtil.debug(TAG, " map information ");
                                    if (indrelatedata == null) {
                                        continue;
                                    }

                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                                            (Long) indrelatedata.get("id"));
                                    singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_CATEGORYTABLE_ID,
                                            (Long) indrelatedata.get(
                                                    FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_CATEGORYTABLE_ID
                                            ));
                                    singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_DOMAINTABLE_ID,
                                            (Long) indrelatedata.get(
                                                    FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_DOMAINTABLE_ID
                                            ));
                                    singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_SOURCEICONURL,
                                            (String) indrelatedata.get(
                                                    FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_SOURCEICONURL
                                            ));

                                    entryvalues[count++] = singlearticleentryvalue;
                                }
                                ContentResolver gongContentResolver = mContextReference.get().getContentResolver();

                                int result = 0;
                                result = gongContentResolver.delete(
                                        FirstSubdomainTableContract.FirstSubdomainEntry.CONTENT_URI,
                                        null,
                                        null);
                                LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask ondatachange  done delete result=" + result);
                                result = gongContentResolver.bulkInsert(
                                        FirstSubdomainTableContract.FirstSubdomainEntry.CONTENT_URI,
                                        entryvalues);
                                LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask ondatachange  DONE INSERT result =" + result);
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask oncancelled ");
                        }
                    });


            LogUtil.debug(TAG, " CheckFirstSubDomainTableTask    4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }
    }


    private static class CheckArchiveLatestLookupTableTask extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckArchiveLatestLookupTableTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckArchiveLatestLookupTableTask    (JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckArchiveLatestLookupTableTask     constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckArchiveLatestLookupTableTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.ARCHIVELATESTLOOKUP_LASTUPDATETIME_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.ARCHIVELATESTLOOKUP)
                    .child(FirebaseIntentService.LASTUPDATETIME)
                    .addValueEventListener(eventlastUpdateTime);
            ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.ARCHIVELATESTLOOKUP_NOOFENTRY_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.ARCHIVELATESTLOOKUP)
                    .child(FirebaseIntentService.NOOFENTRY)
                    .addValueEventListener(eventnoofentry);

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.ARCHIVELATESTLOOKUP)
                    .child(FirebaseIntentService.ENTRY);
            reference.keepSynced(true);
            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange 1");
                            Map<String, String> entrymap = (Map<String, String>)
                                    (dataSnapshot.getValue());
                            int sizeOfEntryMap = entrymap.size();
                            if (sizeOfEntryMap > 0) {
                                ContentValues singlearticleentryvalue;
                                ContentValues[] entryvalues = new ContentValues[sizeOfEntryMap];
                                int count = 0;
                                for (Map.Entry<String, String> indrelatedata : entrymap.entrySet()) {
                                    LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID,
                                            indrelatedata.getKey());
                                    singlearticleentryvalue.put(ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID_URL,
                                            indrelatedata.getValue());
                                    entryvalues[count++] = singlearticleentryvalue;
                                }
                                ContentResolver gongContentResolver = mContextReference.get().getContentResolver();

                                int result = 0;
                                result = gongContentResolver.delete(
                                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.CONTENT_URI,
                                        null,
                                        null);
                                LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange  done delete result=" + result);
                                result = gongContentResolver.bulkInsert(
                                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.CONTENT_URI,
                                        entryvalues);
                                LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange  DONE INSERT result =" + result);
                            }
                            LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange 2");
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask oncancelled ");
                        }
                    });

            LogUtil.debug(TAG, " CheckArchiveLatestLookupTableTask     4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }
    }


    private static class CheckArchiveLatestPageLookupTableTask     extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckArchiveLatestPageLookupTableTask   .class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckArchiveLatestPageLookupTableTask   (JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckArchiveLatestPageLookupTableTask    constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckArchiveLatestPageLookupTableTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");

            ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_ID,
                    true); //true for now, we will check the updatetime difference
            FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.ARCHIVELATESTPAGELOOKUP)
                    .child(FirebaseIntentService.LASTUPDATETIME)
                    .addValueEventListener(eventlastUpdateTime);
            ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                    mContextReference.get(),
                    GongPreference.ARCHIVELATESTPAGELOOKUP_NOOFENTRY_ID,
                    false);
            FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.ARCHIVELATESTPAGELOOKUP)
                    .child(FirebaseIntentService.NOOFENTRY)
                    .addValueEventListener(eventnoofentry);


            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(GongDbHelper.DATABASE_VERSION_STRING)
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.ARCHIVELATESTPAGELOOKUP)
                    .child(FirebaseIntentService.ENTRY);
            reference.keepSynced(true);
            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange 1");
                            Map<String, String> entrymap = (Map<String, String>)
                                    (dataSnapshot.getValue());
                            int sizeOfEntryMap = entrymap.size();
                            if (sizeOfEntryMap > 0) {
                                ContentValues singlearticleentryvalue;
                                ContentValues[] entryvalues = new ContentValues[sizeOfEntryMap];
                                int count = 0;
                                for (Map.Entry<String, String> indrelatedata : entrymap.entrySet()) {
                                    LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID,
                                            indrelatedata.getKey());
                                    singlearticleentryvalue.put(ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID_URL,
                                            indrelatedata.getValue());
                                    entryvalues[count++] = singlearticleentryvalue;
                                }
                                ContentResolver gongContentResolver = mContextReference.get().getContentResolver();

                                int result = 0;
                                result = gongContentResolver.delete(
                                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.CONTENT_URI,
                                        null,
                                        null);
                                LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange  done delete result=" + result);
                                result = gongContentResolver.bulkInsert(
                                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.CONTENT_URI,
                                        entryvalues);
                                LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange  DONE INSERT result =" + result);
                            }
                            LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange 2");
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask oncancelled ");
                        }
                    });

            LogUtil.debug(TAG, " CheckArchiveLatestPageLookupTableTask    4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }
    }





    private static class CheckMinUpgradeTask     extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobService.CheckMinUpgradeTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public CheckMinUpgradeTask   (JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " CheckMinUpgradeTask    constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobService.CheckMinUpgradeTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(FirebaseIntentService.LATESTNEWSTABLE)
                    .child(FirebaseIntentService.SETTINGS);
            reference.keepSynced(true);
            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, "mCheckMinUpgradeTask ondatachange 1");
                            Map<String, Object> entrymap = (Map<String, Object>)
                                    (dataSnapshot.getValue());
                            int sizeOfEntryMap = entrymap.size();
                            if (sizeOfEntryMap > 0) {
                                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContextReference.get());
                                SharedPreferences.Editor editor = sp.edit();
                                long version = (Long) entrymap.get(FirebaseIntentService.MINAPPUPGRADEVER);
                                editor.putInt(mContextReference.get().getString(R.string.current_appversion),
                                        (int) version);
                                editor.apply();
                                LogUtil.debug(TAG, "mCheckMinUpgradeTask ondatachange 2=" + version);
                                version = (Long) entrymap.get(FirebaseIntentService.MINDATABASEUPGRADEVER);
                                editor.putInt(mContextReference.get().getString(R.string.current_databaseversion),
                                        (int) version);
                                editor.apply();
                                LogUtil.debug(TAG, "mCheckMinUpgradeTask ondatachange 3=" + version);
                            }
                            LogUtil.debug(TAG, "mCheckMinUpgradeTask ondatachange 4");
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "mCheckMinUpgradeTask oncancelled ");
                        }
                    });

            LogUtil.debug(TAG, " mCheckMinUpgradeTask    4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }
    }






    /**
     * The entry point to your Job. Implementations should offload work to another thread of
     * execution as soon as possible.
     * <p>
     * This is called by the Job Dispatcher to tell us we should start our job. Keep in mind this
     * method is run on the application's main thread, so we need to offload work to a background
     * thread.
     *
     * @return whether there is more work remaining.
     */
    @Override
    public boolean onStartJob(final JobParameters jobParameters) {

        LogUtil.debug(TAG, "--> in FirebaseJobService onstartjob 1 ");
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        //FirebaseIntentService.setPersistenceenabledIfNot();

        mArticleLookupTableTask = new FirebaseJobService.CheckArticleLookupTableTask (jobParameters, getApplicationContext(), this);
        mArticleLookupTableTask.execute();
        mCategoryTableTask = new FirebaseJobService.CheckCategoryTableTask (jobParameters, getApplicationContext(), this);
        mCategoryTableTask.execute();
        mDomainTableTask = new FirebaseJobService.CheckDomainTableTask (jobParameters, getApplicationContext(), this);
        mDomainTableTask.execute();
        mFirstSubDomainTableTask = new FirebaseJobService.CheckFirstSubDomainTableTask (jobParameters, getApplicationContext(), this);
        mFirstSubDomainTableTask.execute();
        mArchiveLatestLookupTableTask = new FirebaseJobService.CheckArchiveLatestLookupTableTask (jobParameters, getApplicationContext(), this);
        mArchiveLatestLookupTableTask.execute();
        mArchiveLatestPageLookupTableTask = new FirebaseJobService.CheckArchiveLatestPageLookupTableTask (jobParameters, getApplicationContext(), this);
        mArchiveLatestPageLookupTableTask.execute();
        mMinUpgradeTask= new FirebaseJobService.CheckMinUpgradeTask(jobParameters, getApplicationContext(), this);
        mMinUpgradeTask.execute();



/*
        mCheckArticleLookupTableTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if ((GongPreference.getArticlelookupLastupdatetime(getApplicationContext()) >
                        GongPreference.getArticlelookupLastupdatetimeLocal(getApplicationContext()))
                        ||
                        (jobParameters.getTrigger() == Trigger.NOW)
                        ) {
                    LogUtil.debug(TAG, " mCheckArticleLookupTableTask 1 ");
                    int currentNoOfEntry = 0;
                    if (jobParameters.getTrigger() != Trigger.NOW) {
                        LogUtil.debug(TAG, " mCheckArticleLookupTableTask 2 ");

                        GongPreference.setArticlelookupLastupdatetimeLocal(getApplicationContext(),
                                GongPreference.getArticlelookupLastupdatetime(getApplicationContext()));

                        currentNoOfEntry = GongPreference.getArticlelookupNoOfEntry(getApplicationContext());
                        GongPreference.setArticlelookupNoOfEntryLocal(getApplicationContext(),
                                currentNoOfEntry);
                    } else {
                        LogUtil.debug(TAG, " mCheckArticleLookupTableTask 3 ");

                        ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.ARTICLELOOKUP_LASTUPDATETIME_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.ARTICLELOOKUPTABLE)
                                .child(FirebaseIntentService.LASTUPDATETIME)
                                .addValueEventListener(eventlastUpdateTime);
                        ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.ARTICLELOOKUP_NOOFENTRY_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.ARTICLELOOKUPTABLE)
                                .child(FirebaseIntentService.NOOFENTRY)
                                .addValueEventListener(eventnoofentry);
                    }

                    LogUtil.debug(TAG, " mCheckArticleLookupTableTask 4 ");

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                            .child(FirebaseIntentService.ARTICLELOOKUPTABLE)
                            .child(FirebaseIntentService.ENTRY);
                    reference.keepSynced(true);

                    reference.orderByKey()
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange 1");
                                    Map<String, String> entrymap = (Map<String, String>)
                                            (dataSnapshot.getValue());
                                    int sizeOfEntryMap = entrymap.size();
                                    if (sizeOfEntryMap > 0) {
                                        ContentValues singlearticleentryvalue;
                                        ContentValues[] entryvalues = new ContentValues[sizeOfEntryMap];
                                        int count = 0;
                                        for (Map.Entry<String, String> indrelatedata : entrymap.entrySet()) {
                                            LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                            singlearticleentryvalue = new ContentValues();
                                            singlearticleentryvalue.put(ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID,
                                                    indrelatedata.getKey());
                                            singlearticleentryvalue.put(ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID_URL,
                                                    indrelatedata.getValue());
                                            entryvalues[count++] = singlearticleentryvalue;
                                        }
                                        ContentResolver gongContentResolver = getApplicationContext().getContentResolver();

                                        int result = 0;
                                        result = gongContentResolver.delete(
                                                ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI,
                                                null,
                                                null);
                                        LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange  done delete result=" + result);
                                        result = gongContentResolver.bulkInsert(
                                                ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI,
                                                entryvalues);
                                        LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange  DONE INSERT result =" + result);
                                    }
                                    LogUtil.debug(TAG, "mCheckArticleLookupTableTask ondatachange 2");
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    LogUtil.debug(TAG, "mCheckArticleLookupTableTask oncancelled ");
                                }
                            });
                }
                LogUtil.debug(TAG, " mCheckArticleLookupTableTask 4 ");
                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mCheckArticleLookupTableTask.execute();


        mCheckCategoryTableTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if ((GongPreference.getCategoryLastupdatetime(getApplicationContext()) >
                        GongPreference.getCategoryLastupdatetimeLocal(getApplicationContext()))
                        ||
                        (jobParameters.getTrigger() == Trigger.NOW)
                        ) {
                    LogUtil.debug(TAG, " mCheckCategoryTableTask 1 ");

                    int currentNoOfEntry = 0;
                    if (jobParameters.getTrigger() != Trigger.NOW) {
                        LogUtil.debug(TAG, " mCheckCategoryTableTask 2 ");

                        GongPreference.setCategoryLastupdatetimeLocal(getApplicationContext(),
                                GongPreference.getCategoryLastupdatetime(getApplicationContext()));

                        currentNoOfEntry = GongPreference.getCategoryNoOfEntry(getApplicationContext());
                        GongPreference.setCategoryNoOfEntryLocal(getApplicationContext(),
                                currentNoOfEntry);
                    } else {
                        LogUtil.debug(TAG, " mCheckCategoryTableTask 3 ");

                        ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.CATEGORY_LASTUPDATETIME_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.CATEGORYTABLE)
                                .child(FirebaseIntentService.LASTUPDATETIME)
                                .addValueEventListener(eventlastUpdateTime);
                        ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.CATEGORY_NOOFENTRY_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.CATEGORYTABLE)
                                .child(FirebaseIntentService.NOOFENTRY)
                                .addValueEventListener(eventnoofentry);
                    }

                    LogUtil.debug(TAG, " mCheckCategoryTableTask 4 ");

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                            .child(FirebaseIntentService.CATEGORYTABLE)
                            .child(FirebaseIntentService.ENTRY);
                    reference.keepSynced(true);
                    reference.orderByKey()
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange 1 ");
                                    ArrayList<Map<String, Object>> arrayList = (ArrayList<Map<String, Object>>) dataSnapshot.getValue();
                                    int sizeOfArrayList = arrayList.size();
                                    boolean firstelementIsNull = false;
                                    if ((sizeOfArrayList > 0) && (arrayList.get(0) == null)) {
                                        firstelementIsNull = true;
                                    }
                                    //Map<String, Object> entrymap = (Map<String, Object>)
                                    //        (((HashMap<String, Object>) dataSnapshot.getValue()));

                                    //int sizeOfEntryMap = entrymap.size();
                                    //if (sizeOfEntryMap > 0) {
                                    if (sizeOfArrayList > 0) {
                                        ContentValues singlearticleentryvalue;
                                        ContentValues[] entryvalues = new ContentValues[firstelementIsNull ? sizeOfArrayList - 1 : sizeOfArrayList];
                                        int count = 0;
                                        int startarrayListIndex = firstelementIsNull ? 1 : 0;
                                        //for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                        for (Map<String, Object> indrelatedata : arrayList) {
                                            LogUtil.debug(TAG, " map information ");
                                            if (indrelatedata == null) {
                                                continue;
                                            }

                                            singlearticleentryvalue = new ContentValues();
                                            singlearticleentryvalue.put(CategoryTableContract.CategoryEntry.COLUMN_CATEGORYTABLE_ID,
                                                    (long) indrelatedata.get("id"));
                                            singlearticleentryvalue.put(CategoryTableContract.CategoryEntry.COLUMN_CHI_NAME,
                                                    (String) indrelatedata.get(
                                                            CategoryTableContract.CategoryEntry.COLUMN_CHI_NAME
                                                    ));
                                            singlearticleentryvalue.put(CategoryTableContract.CategoryEntry.COLUMN_ENG_NAME,
                                                    (String) indrelatedata.get(
                                                            CategoryTableContract.CategoryEntry.COLUMN_ENG_NAME
                                                    ));

                                            entryvalues[count++] = singlearticleentryvalue;


                                        }
                                        LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange 1.2 ");
                                        ContentResolver gongContentResolver = getApplicationContext().getContentResolver();
                                        LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange 2 ");

                                        int result = 0;
                                        result = gongContentResolver.delete(
                                                CategoryTableContract.CategoryEntry.CONTENT_URI,
                                                null,
                                                null);
                                        LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange  done delete result=" + result);
                                        result = gongContentResolver.bulkInsert(
                                                CategoryTableContract.CategoryEntry.CONTENT_URI,
                                                entryvalues);
                                        LogUtil.debug(TAG, "mCheckCategoryTableTask ondatachange  DONE INSERT result =" + result);
                                    }
                                }


                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    LogUtil.debug(TAG, "mCheckCategoryTableTask oncancelled ");
                                }
                            });
                }
                LogUtil.debug(TAG, " mCheckCategoryTableTask 5 ");
                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mCheckCategoryTableTask.execute();


        mCheckDomainTableTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if ((GongPreference.getCategoryLastupdatetime(getApplicationContext()) >
                        GongPreference.getCategoryLastupdatetimeLocal(getApplicationContext()))
                        ||
                        (jobParameters.getTrigger() == Trigger.NOW)
                        ) {
                    LogUtil.debug(TAG, " mCheckDomainTableTask 1 ");

                    int currentNoOfEntry = 0;
                    if (jobParameters.getTrigger() != Trigger.NOW) {
                        LogUtil.debug(TAG, " mCheckDomainTableTask 2 ");
                        GongPreference.setCategoryLastupdatetimeLocal(getApplicationContext(),
                                GongPreference.getCategoryLastupdatetime(getApplicationContext()));

                        currentNoOfEntry = GongPreference.getCategoryNoOfEntry(getApplicationContext());
                        GongPreference.setCategoryNoOfEntryLocal(getApplicationContext(),
                                currentNoOfEntry);
                    } else {
                        LogUtil.debug(TAG, " mCheckDomainTableTask 3 ");

                        ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.DOMAIN_LASTUPDATETIME_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.DOMAINTABLE)
                                .child(FirebaseIntentService.LASTUPDATETIME)
                                .addValueEventListener(eventlastUpdateTime);
                        ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.DOMAIN_NOOFENTRY_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.DOMAINTABLE)
                                .child(FirebaseIntentService.NOOFENTRY)
                                .addValueEventListener(eventnoofentry);
                    }
                    LogUtil.debug(TAG, " mCheckDomainTableTask 4 ");

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                            .child(FirebaseIntentService.DOMAINTABLE)
                            .child(FirebaseIntentService.ENTRY);
                    reference.keepSynced(true);
                    reference.orderByKey()
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    LogUtil.debug(TAG, "mCheckDomainTableTask ondatachange ");
                                    ArrayList<Map<String, Object>> arrayList = (ArrayList<Map<String, Object>>) dataSnapshot.getValue();
                                    int sizeOfArrayList = arrayList.size();
                                    boolean firstelementIsNull = false;
                                    if ((sizeOfArrayList > 0) && (arrayList.get(0) == null)) {
                                        firstelementIsNull = true;
                                    }

                                    //Map<String, Object> entrymap = (Map<String, Object>)
                                    //        (((HashMap<String, Object>) dataSnapshot.getValue()).get("entry"));

                                    //int sizeOfEntryMap = entrymap.size();
                                    if (sizeOfArrayList > 0) {
                                        ContentValues singlearticleentryvalue;
                                        ContentValues[] entryvalues = new ContentValues[firstelementIsNull ? sizeOfArrayList - 1 : sizeOfArrayList];
                                        int count = 0;
                                        int startarrayListIndex = firstelementIsNull ? 1 : 0;
                                        //for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                        for (Map<String, Object> indrelatedata : arrayList) {
                                            LogUtil.debug(TAG, " map information ");
                                            if (indrelatedata == null) {
                                                continue;
                                            }

                                            singlearticleentryvalue = new ContentValues();
                                            singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_DOMAINTABLE_ID,
                                                    (Long) indrelatedata.get("id"));
                                            singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_CHI_NAME,
                                                    (String) indrelatedata.get(
                                                            DomainTableContract.DomainEntry.COLUMN_CHI_NAME
                                                    ));
                                            singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_ENG_NAME,
                                                    (String) indrelatedata.get(
                                                            DomainTableContract.DomainEntry.COLUMN_ENG_NAME
                                                    ));
                                            singlearticleentryvalue.put(DomainTableContract.DomainEntry.COLUMN_BASEURL,
                                                    (String) indrelatedata.get(
                                                            DomainTableContract.DomainEntry.COLUMN_BASEURL
                                                    ));

                                            entryvalues[count++] = singlearticleentryvalue;
                                        }
                                        ContentResolver gongContentResolver = getApplicationContext().getContentResolver();

                                        int result = 0;
                                        result = gongContentResolver.delete(
                                                DomainTableContract.DomainEntry.CONTENT_URI,
                                                null,
                                                null);
                                        LogUtil.debug(TAG, "mCheckDomainTableTask ondatachange  done delete result=" + result);
                                        result = gongContentResolver.bulkInsert(
                                                DomainTableContract.DomainEntry.CONTENT_URI,
                                                entryvalues);
                                        LogUtil.debug(TAG, "mCheckDomainTableTask ondatachange  DONE INSERT result =" + result);
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    LogUtil.debug(TAG, "mCheckDomainTableTask oncancelled ");
                                }
                            });
                }
                LogUtil.debug(TAG, " mCheckDomainTableTask 5 ");
                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mCheckDomainTableTask.execute();


        mCheckFirstSubDomainTableTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if ((GongPreference.getCategoryLastupdatetime(getApplicationContext()) >
                        GongPreference.getCategoryLastupdatetimeLocal(getApplicationContext()))
                        ||
                        (jobParameters.getTrigger() == Trigger.NOW)
                        ) {
                    LogUtil.debug(TAG, " mCheckFirstSubDomainTableTask 1 ");

                    int currentNoOfEntry = 0;
                    if (jobParameters.getTrigger() != Trigger.NOW) {
                        LogUtil.debug(TAG, " mCheckFirstSubDomainTableTask 2 ");

                        GongPreference.setCategoryLastupdatetimeLocal(getApplicationContext(),
                                GongPreference.getCategoryLastupdatetime(getApplicationContext()));

                        currentNoOfEntry = GongPreference.getCategoryNoOfEntry(getApplicationContext());
                        GongPreference.setCategoryNoOfEntryLocal(getApplicationContext(),
                                currentNoOfEntry);
                    } else {
                        LogUtil.debug(TAG, " mCheckFirstSubDomainTableTask 3 ");

                        ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.FIRSTSUBDOMAIN_LASTUPDATETIME_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.FIRSTSUBDOMAINTABLE)
                                .child(FirebaseIntentService.LASTUPDATETIME)
                                .addValueEventListener(eventlastUpdateTime);
                        ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.FIRSTSUBDOMAIN_NOOFENTRY_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.FIRSTSUBDOMAINTABLE)
                                .child(FirebaseIntentService.NOOFENTRY)
                                .addValueEventListener(eventnoofentry);
                    }

                    LogUtil.debug(TAG, " mCheckFirstSubDomainTableTask 4 ");

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                            .child(FirebaseIntentService.FIRSTSUBDOMAINTABLE)
                            .child(FirebaseIntentService.ENTRY);
                    reference.keepSynced(true);
                    reference.orderByKey()
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask ondatachange ");
                                    ArrayList<Map<String, Object>> arrayList = (ArrayList<Map<String, Object>>) dataSnapshot.getValue();
                                    int sizeOfArrayList = arrayList.size();
                                    boolean firstelementIsNull = false;
                                    if ((sizeOfArrayList > 0) && (arrayList.get(0) == null)) {
                                        firstelementIsNull = true;
                                    }

                                    //Map<String, Object> entrymap = (Map<String, Object>)
                                    //        (((HashMap<String, Object>) dataSnapshot.getValue()).get("entry"));

                                    //int sizeOfEntryMap = entrymap.size();
                                    if (sizeOfArrayList > 0) {
                                        ContentValues singlearticleentryvalue;
                                        ContentValues[] entryvalues = new ContentValues[firstelementIsNull ? sizeOfArrayList - 1 : sizeOfArrayList];
                                        int count = 0;
                                        int startarrayListIndex = firstelementIsNull ? 1 : 0;
                                        //for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                        for (Map<String, Object> indrelatedata : arrayList) {
                                            LogUtil.debug(TAG, " map information ");
                                            if (indrelatedata == null) {
                                                continue;
                                            }

                                            singlearticleentryvalue = new ContentValues();
                                            singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                                                    (Long) indrelatedata.get("id"));
                                            singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_CATEGORYTABLE_ID,
                                                    (Long) indrelatedata.get(
                                                            FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_CATEGORYTABLE_ID
                                                    ));
                                            singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_DOMAINTABLE_ID,
                                                    (Long) indrelatedata.get(
                                                            FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_DOMAINTABLE_ID
                                                    ));
                                            singlearticleentryvalue.put(FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_SOURCEICONURL,
                                                    (String) indrelatedata.get(
                                                            FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_SOURCEICONURL
                                                    ));

                                            entryvalues[count++] = singlearticleentryvalue;
                                        }
                                        ContentResolver gongContentResolver = getApplicationContext().getContentResolver();

                                        int result = 0;
                                        result = gongContentResolver.delete(
                                                FirstSubdomainTableContract.FirstSubdomainEntry.CONTENT_URI,
                                                null,
                                                null);
                                        LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask ondatachange  done delete result=" + result);
                                        result = gongContentResolver.bulkInsert(
                                                FirstSubdomainTableContract.FirstSubdomainEntry.CONTENT_URI,
                                                entryvalues);
                                        LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask ondatachange  DONE INSERT result =" + result);
                                    }
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    LogUtil.debug(TAG, "mCheckFirstSubDomainTableTask oncancelled ");
                                }
                            });
                }
                LogUtil.debug(TAG, " mCheckFirstSubDomainTableTask 5 ");
                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mCheckFirstSubDomainTableTask.execute();


        mCheckArchiveLatestLookupTableTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if ((GongPreference.getArchiveLatestlookupLastupdatetime(getApplicationContext()) >
                        GongPreference.getArchiveLatestlookupLastupdatetimeLocal(getApplicationContext()))
                        ||
                        (jobParameters.getTrigger() == Trigger.NOW)
                        ) {
                    LogUtil.debug(TAG, " mCheckArchiveLatestLookupTableTask 1 ");
                    int currentNoOfEntry = 0;
                    if (jobParameters.getTrigger() != Trigger.NOW) {
                        LogUtil.debug(TAG, " mCheckArchiveLatestLookupTableTask 2 ");

                        GongPreference.setArchiveLatestlookupLastupdatetimeLocal(getApplicationContext(),
                                GongPreference.getArchiveLatestlookupLastupdatetime(getApplicationContext()));

                        currentNoOfEntry = GongPreference.getArchiveLatestlookupNoOfEntry(getApplicationContext());
                        GongPreference.setArchiveLatestlookupNoOfEntryLocal(getApplicationContext(),
                                currentNoOfEntry);
                    } else {
                        LogUtil.debug(TAG, " mCheckArchiveLatestLookupTableTask 3 ");

                        ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.ARCHIVELATESTLOOKUP_LASTUPDATETIME_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.LATESTNEWSTABLE)
                                .child(FirebaseIntentService.ARCHIVELATESTLOOKUP)
                                .child(FirebaseIntentService.LASTUPDATETIME)
                                .addValueEventListener(eventlastUpdateTime);
                        ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.ARCHIVELATESTLOOKUP_NOOFENTRY_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.LATESTNEWSTABLE)
                                .child(FirebaseIntentService.ARCHIVELATESTLOOKUP)
                                .child(FirebaseIntentService.NOOFENTRY)
                                .addValueEventListener(eventnoofentry);
                    }

                    LogUtil.debug(TAG, " mCheckArchiveLatestLookupTableTask 4 ");

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                            .child(FirebaseIntentService.LATESTNEWSTABLE)
                            .child(FirebaseIntentService.ARCHIVELATESTLOOKUP)
                            .child(FirebaseIntentService.ENTRY);
                    reference.keepSynced(true);
                    reference.orderByKey()
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange 1");
                                    Map<String, String> entrymap = (Map<String, String>)
                                            (dataSnapshot.getValue());
                                    int sizeOfEntryMap = entrymap.size();
                                    if (sizeOfEntryMap > 0) {
                                        ContentValues singlearticleentryvalue;
                                        ContentValues[] entryvalues = new ContentValues[sizeOfEntryMap];
                                        int count = 0;
                                        for (Map.Entry<String, String> indrelatedata : entrymap.entrySet()) {
                                            LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                            singlearticleentryvalue = new ContentValues();
                                            singlearticleentryvalue.put(ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID,
                                                    indrelatedata.getKey());
                                            singlearticleentryvalue.put(ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID_URL,
                                                    indrelatedata.getValue());
                                            entryvalues[count++] = singlearticleentryvalue;
                                        }
                                        ContentResolver gongContentResolver = getApplicationContext().getContentResolver();

                                        int result = 0;
                                        result = gongContentResolver.delete(
                                                ArchiveLatestLookupContract.ArchiveLatestLookupEntry.CONTENT_URI,
                                                null,
                                                null);
                                        LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange  done delete result=" + result);
                                        result = gongContentResolver.bulkInsert(
                                                ArchiveLatestLookupContract.ArchiveLatestLookupEntry.CONTENT_URI,
                                                entryvalues);
                                        LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange  DONE INSERT result =" + result);
                                    }
                                    LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask ondatachange 2");
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    LogUtil.debug(TAG, "mCheckArchiveLatestLookupTableTask oncancelled ");
                                }
                            });
                }
                LogUtil.debug(TAG, " mCheckArchiveLatestLookupTableTask 4 ");
                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mCheckArchiveLatestLookupTableTask.execute();


        mCheckArchiveLatestPageLookupTableTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                if ((GongPreference.getArchiveLatestPagelookupLastupdatetime(getApplicationContext()) >
                        GongPreference.getArchiveLatestPagelookupLastupdatetimeLocal(getApplicationContext()))
                        ||
                        (jobParameters.getTrigger() == Trigger.NOW)
                        ) {
                    LogUtil.debug(TAG, " mCheckArchiveLatestPageLookupTableTask 1 ");
                    int currentNoOfEntry = 0;
                    if (jobParameters.getTrigger() != Trigger.NOW) {
                        LogUtil.debug(TAG, " mCheckArchiveLatestPageLookupTableTask 2 ");

                        GongPreference.setArchiveLatestPagelookupLastupdatetimeLocal(getApplicationContext(),
                                GongPreference.getArchiveLatestPagelookupLastupdatetime(getApplicationContext()));

                        currentNoOfEntry = GongPreference.getArchiveLatestPagelookupNoOfEntry(getApplicationContext());
                        GongPreference.setArchiveLatestPagelookupNoOfEntryLocal(getApplicationContext(),
                                currentNoOfEntry);
                    } else {
                        LogUtil.debug(TAG, " mCheckArchiveLatestPageLookupTableTask 3 ");

                        ValueEventListener eventlastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.LATESTNEWSTABLE)
                                .child(FirebaseIntentService.ARCHIVELATESTPAGELOOKUP)
                                .child(FirebaseIntentService.LASTUPDATETIME)
                                .addValueEventListener(eventlastUpdateTime);
                        ValueEventListener eventnoofentry = GongValueEventListener.get_TableValueEventListener(
                                getApplicationContext(),
                                GongPreference.ARCHIVELATESTPAGELOOKUP_NOOFENTRY_ID,
                                true);
                        FirebaseDatabase.getInstance().getReference()
                                .child(FirebaseIntentService.LATESTNEWSTABLE)
                                .child(FirebaseIntentService.ARCHIVELATESTPAGELOOKUP)
                                .child(FirebaseIntentService.NOOFENTRY)
                                .addValueEventListener(eventnoofentry);
                    }

                    LogUtil.debug(TAG, " mCheckArchiveLatestPageLookupTableTask 4 ");

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                            .child(FirebaseIntentService.LATESTNEWSTABLE)
                            .child(FirebaseIntentService.ARCHIVELATESTPAGELOOKUP)
                            .child(FirebaseIntentService.ENTRY);
                    reference.keepSynced(true);
                    reference.orderByKey()
                            .addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {
                                    LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange 1");
                                    Map<String, String> entrymap = (Map<String, String>)
                                            (dataSnapshot.getValue());
                                    int sizeOfEntryMap = entrymap.size();
                                    if (sizeOfEntryMap > 0) {
                                        ContentValues singlearticleentryvalue;
                                        ContentValues[] entryvalues = new ContentValues[sizeOfEntryMap];
                                        int count = 0;
                                        for (Map.Entry<String, String> indrelatedata : entrymap.entrySet()) {
                                            LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                            singlearticleentryvalue = new ContentValues();
                                            singlearticleentryvalue.put(ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID,
                                                    indrelatedata.getKey());
                                            singlearticleentryvalue.put(ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID_URL,
                                                    indrelatedata.getValue());
                                            entryvalues[count++] = singlearticleentryvalue;
                                        }
                                        ContentResolver gongContentResolver = getApplicationContext().getContentResolver();

                                        int result = 0;
                                        result = gongContentResolver.delete(
                                                ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.CONTENT_URI,
                                                null,
                                                null);
                                        LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange  done delete result=" + result);
                                        result = gongContentResolver.bulkInsert(
                                                ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.CONTENT_URI,
                                                entryvalues);
                                        LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange  DONE INSERT result =" + result);
                                    }
                                    LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask ondatachange 2");
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    LogUtil.debug(TAG, "mCheckArchiveLatestPageLookupTableTask oncancelled ");
                                }
                            });
                }
                LogUtil.debug(TAG, " mCheckArchiveLatestPageLookupTableTask 4 ");
                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mCheckArchiveLatestPageLookupTableTask.execute();
*/

        mFetchFirebaseTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... voids) {
                Context context = getApplicationContext();
                LogUtil.debug(TAG, "----> FirebaseJobService asynctask doinbackground ");
                        /* Build the URI for today's weather in order to show up to date data in notification */
        /*
         * The MAIN_FORECAST_PROJECTION array passed in as the second parameter is defined in our WeatherContract
         * class and is used to limit the columns returned in our cursor.
         */
        /*
                Uri forecastQueryUri = WeatherContract.WeatherEntry.CONTENT_URI;

                int hello  = context.getContentResolver().update(
                        forecastQueryUri,
                        null,
                        null,
                        null);

                SunshineSyncTask.syncWeathertest(context, "CA94401");
                SunshineSyncTask.syncWeathertest(context, "CA94063");
                SunshineSyncTask.syncWeathertest(context, "CA94015");
                SunshineSyncTask.syncWeathertest(context, "CA94621");
          */


                jobFinished(jobParameters, false);
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                jobFinished(jobParameters, false);
            }
        };

        mFetchFirebaseTask.execute();
        return true;
    }

    /**
     * Called when the scheduling engine has decided to interrupt the execution of a running job,
     * most likely because the runtime constraints associated with the job are no longer satisfied.
     *
     * @return whether the job should be retried
     * //@see Job.Builder#setRetryStrategy(RetryStrategy)
     * //@see RetryStrategy
     */
    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        LogUtil.debug(TAG, "----> FirebaseJobService onstopjob  ");
        if (mFetchFirebaseTask != null) {
            mFetchFirebaseTask.cancel(true);
        }
        return true;
    }


}
