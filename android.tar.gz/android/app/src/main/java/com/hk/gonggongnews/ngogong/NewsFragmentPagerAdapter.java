package com.hk.gonggongnews.ngogong;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.ViewGroup;

import com.hk.gonggongnews.ngogong.util.FragInfo;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ismile on 9/21/2017.
 */

public class NewsFragmentPagerAdapter
        extends FragmentPagerAdapter {
    private static final String TAG = NewsFragmentPagerAdapter.class.getName();

    public static final String FRAGMENT_NAME = "fragment_name";
    public static final String FRAGMENT_POS = "fragment_pos";

    public interface TalkToIndividualFragment {
        public int checkHowManyNewItem();
        public void initPreferredFirstSubDomain(int[] arrayOfFSD );
        public void clearPreferredFirstSubDomain();
        public void swiperefreshNow();

    }

    private Map<Integer, String> mFragmentIDMap;

    private FragmentManager mFragmentManger;

    public NewsFragmentPagerAdapter(FragmentManager fm) {
        super(fm);
        mFragmentIDMap = new HashMap<Integer, String>();
        mFragmentManger = fm;
    }

    @Override
    public Fragment getItem(int position) {
        LogUtil.debug(TAG, " NewsFragmentPagerAdapter getitem=" + position + " end");

        if (position == 0) {
            return new NewsFragment();
        } else if ( (position >= 1) && ( position < FragInfo.getInstance().get_tablistSize() )) {
            Fragment containerfragment = new ContainerFragment();
            Bundle bundle = new Bundle();
            bundle.putString(FRAGMENT_NAME, FragInfo.getInstance().get_tablistFragTableName(position));
            bundle.putInt(FRAGMENT_POS, position);
            containerfragment.setArguments(bundle);
            return containerfragment;
        }
        return new NewsFragment();


    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        LogUtil.debug(TAG, " NewsFragmentPagerAdapter getpagetitle=" + position + " end");
        return FragInfo.getInstance().get_tablistname(position);
    }

    @Override
    public int getCount() {
        LogUtil.debug(TAG, " NewsFragmentPagerAdapter getcount end= length=" + FragInfo.getInstance().get_tablistSize() );
        return FragInfo.getInstance().get_tablistSize() ;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Fragment createdFragment = (Fragment) super.instantiateItem(container, position);


        mFragmentIDMap.put(position,createdFragment.getTag());

        return createdFragment;
    }

    public Fragment getFragment(int position) {
        String fragmenttag = mFragmentIDMap.get(position);
        return mFragmentManger.findFragmentByTag(fragmenttag);
    }

    public int shouldShowMoreItemSnackBar(int position) {

        String fragmenttag = mFragmentIDMap.get(position);
        Fragment fragment = mFragmentManger.findFragmentByTag(fragmenttag);
        LogUtil.debug (TAG, " shouldShowMoreItemSnackBar 1 position=" + position);
        return ((TalkToIndividualFragment) fragment).checkHowManyNewItem();

    }



    public int getCurrentFragmentCategory(int position){
        LogUtil.debug (TAG, " getCurrentFragmentCategory 1");

        return FragInfo.getInstance().get_category(position);
    }


    public void passInPreferredFSD (int position, int[] arrayOfFSD ){
        String fragmenttag = mFragmentIDMap.get(position);
        Fragment fragment = mFragmentManger.findFragmentByTag(fragmenttag);
        LogUtil.debug (TAG, " passInPreferredFSD 1=" + arrayOfFSD.length);

//        if (arrayOfFSD.length > 0) {
            LogUtil.debug (TAG, " passInPreferredFSD 2" );
            ((TalkToIndividualFragment) fragment).initPreferredFirstSubDomain(arrayOfFSD);
//        } else {
//            LogUtil.debug (TAG, " passInPreferredFSD 3");
//            ((TalkToIndividualFragment) fragment).clearPreferredFirstSubDomain();
//        }
    }


    public void clearInPreferredFSD (int position){
        String fragmenttag = mFragmentIDMap.get(position);
        Fragment fragment = mFragmentManger.findFragmentByTag(fragmenttag);
        LogUtil.debug (TAG, " clearInPreferredFSD 1 position=" + position);
        ((TalkToIndividualFragment) fragment).clearPreferredFirstSubDomain();
        LogUtil.debug (TAG, " clearInPreferredFSD 2");

    }

    public void goupdateNow(int position){
        String fragmenttag = mFragmentIDMap.get(position);
        Fragment fragment = mFragmentManger.findFragmentByTag(fragmenttag);
        LogUtil.debug (TAG, " goupdateNow 1 position=" + position);
        ((TalkToIndividualFragment) fragment).swiperefreshNow();
        LogUtil.debug (TAG, " goupdateNow 2 position=" + position);

    }

}
