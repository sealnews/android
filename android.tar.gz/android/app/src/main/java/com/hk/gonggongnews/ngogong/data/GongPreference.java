package com.hk.gonggongnews.ngogong.data;

/**
 * Created by ismile on 10/17/2017.
 */
import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.StringDef;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class GongPreference {


    public static final String DEFAULT_PREFERRED_LIST_STRING = "12 15 9 10 7 6 1 2 4 11 8 13 16 17 18 14 19 20 21 22";
    public static final String PREFERRED_LIST = "preferred_list";
    public static final String DEFAULT_PREFERRED_LIST_DELIMITER = " ";

    public static final long DEFAULT_LASTUPDATETIME_VALUE =0;
    public static final int DEFAULT_NOOFENTRY_VALUE =0;
    public static final int PREFERENCE_LASTUPDATETIME_START =101;
    public static final int PREFERENCE_LASTUPDATETIME_END =200;
    public static final int PREFERENCE_NOOFENTRY_START =201;
    public static final int PREFERENCE_NOOFENTRY_END =300;
    public static final int PREFERENCE_LASTUPDATETIME_LOCAL_START =301;
    public static final int PREFERENCE_LASTUPDATETIME_LOCAL_END =400;
    public static final int PREFERENCE_NOOFENTRY_LOCAL_START =401;
    public static final int PREFERENCE_NOOFENTRY_LOCAL_END =500;

    public static final Map<Integer, String> ID_KEY_MAP = new HashMap<Integer, String>();
    public static final Map<Integer, Integer> ID_REMOTE_LOCAL_MAP = new HashMap<Integer, Integer>();


    public static final String ARTICLELOOKUP_LASTUPDATETIME = "articlelookup_lastupdatetime";
    public static final String ARTICLELOOKUP_NOOFENTRY = "articlelookup_noofentry";
    public static final int ARTICLELOOKUP_LASTUPDATETIME_ID = 101;
    public static final int ARTICLELOOKUP_NOOFENTRY_ID = 201;
    public static final String ARTICLELOOKUP_LASTUPDATETIME_LOCAL = "articlelookup_lastupdatetime_local";
    public static final String ARTICLELOOKUP_NOOFENTRY_LOCAL  = "articlelookup_noofentry_local";
    public static final int ARTICLELOOKUP_LASTUPDATETIME_LOCAL_ID = 301;
    public static final int ARTICLELOOKUP_NOOFENTRY_LOCAL_ID  = 401;

    public static final String ARTICLE_LASTUPDATETIME = "article_lastupdatetime";
    public static final String ARTICLE_NOOFENTRY = "article_noofentry";
    public static final int ARTICLE_LASTUPDATETIME_ID = 102;
    public static final int ARTICLE_NOOFENTRY_ID = 202;
    public static final String ARTICLE_LASTUPDATETIME_LOCAL = "article_lastupdatetime_local";
    public static final String ARTICLE_NOOFENTRY_LOCAL  = "article_noofentry_local";
    public static final int ARTICLE_LASTUPDATETIME_LOCAL_ID = 302;
    public static final int ARTICLE_NOOFENTRY_LOCAL_ID  = 402;

    public static final String CATEGORY_LASTUPDATETIME = "category_lastupdatetime";
    public static final String CATEGORY_NOOFENTRY = "category_noofentry";
    public static final int CATEGORY_LASTUPDATETIME_ID = 103;
    public static final int CATEGORY_NOOFENTRY_ID = 203;
    public static final String CATEGORY_LASTUPDATETIME_LOCAL = "category_lastupdatetime_local";
    public static final String CATEGORY_NOOFENTRY_LOCAL  = "category_noofentry_local";
    public static final int CATEGORY_LASTUPDATETIME_LOCAL_ID = 303;
    public static final int CATEGORY_NOOFENTRY_LOCAL_ID  = 403;



    public static final String DOMAIN_LASTUPDATETIME = "domain_lastupdatetime";
    public static final String DOMAIN_NOOFENTRY = "domain_noofentry";
    public static final int DOMAIN_LASTUPDATETIME_ID = 104;
    public static final int DOMAIN_NOOFENTRY_ID = 204;
    public static final String DOMAIN_LASTUPDATETIME_LOCAL = "domain_lastupdatetime_local";
    public static final String DOMAIN_NOOFENTRY_LOCAL  = "domain_noofentry_local";
    public static final int DOMAIN_LASTUPDATETIME_LOCAL_ID = 304;
    public static final int DOMAIN_NOOFENTRY_LOCAL_ID  = 404;

    public static final String FIRSTSUBDOMAIN_LASTUPDATETIME = "firstsubdomain_lastupdatetime";
    public static final String FIRSTSUBDOMAIN_NOOFENTRY = "firstsubdomain_noofentry";
    public static final int FIRSTSUBDOMAIN_LASTUPDATETIME_ID = 105;
    public static final int FIRSTSUBDOMAIN_NOOFENTRY_ID = 205;
    public static final String FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL = "firstsubdomain_lastupdatetime_local";
    public static final String FIRSTSUBDOMAIN_NOOFENTRY_LOCAL  = "firstsubdomain_noofentry_local";
    public static final int FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL_ID = 305;
    public static final int FIRSTSUBDOMAIN_NOOFENTRY_LOCAL_ID  = 405;

    public static final String LATESTNEWSPAGINATION_LASTUPDATETIME = "latestnewspagination_lastupdatetime";
    public static final String LATESTNEWSPAGINATION_NOOFENTRY = "latestnewspagination_noofentry";
    public static final int LATESTNEWSPAGINATION_LASTUPDATETIME_ID = 106;
    public static final int LATESTNEWSPAGINATION_NOOFENTRY_ID = 206;
    public static final String LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL = "latestnewspagination_lastupdatetime_local";
    public static final String LATESTNEWSPAGINATION_NOOFENTRY_LOCAL  = "latestnewspagination_noofentry_local";
    public static final int LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL_ID = 306;
    public static final int LATESTNEWSPAGINATION_NOOFENTRY_LOCAL_ID  = 406;

    public static final String ARCHIVELATESTLOOKUP_LASTUPDATETIME = "archivelatestlookup_lastupdatetime";
    public static final String ARCHIVELATESTLOOKUP_NOOFENTRY = "archivelatestlookup_noofentry";
    public static final int ARCHIVELATESTLOOKUP_LASTUPDATETIME_ID = 107;
    public static final int ARCHIVELATESTLOOKUP_NOOFENTRY_ID = 207;
    public static final String ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL = "archivelatestlookup_lastupdatetime_local";
    public static final String ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL  = "archivelatestlookup_noofentry_local";
    public static final int ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL_ID = 307;
    public static final int ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL_ID  = 407;

    public static final String ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME = "archivelatestpagelookup_lastupdatetime";
    public static final String ARCHIVELATESTPAGELOOKUP_NOOFENTRY = "archivelatestpagelookup_noofentry";
    public static final int ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_ID = 108;
    public static final int ARCHIVELATESTPAGELOOKUP_NOOFENTRY_ID = 208;
    public static final String ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL = "archivelatestpagelookup_lastupdatetime_local";
    public static final String ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL  = "archivelatestpagelookup_noofentry_local";
    public static final int ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL_ID = 308;
    public static final int ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL_ID  = 408;

    public static final String ARCHIVELATESTPAGINATION_LASTUPDATETIME = "archivelatestpagination_lastupdatetime";
    public static final String ARCHIVELATESTPAGINATION_NOOFENTRY = "archivelatestpagination_noofentry";
    public static final int ARCHIVELATESTPAGINATION_LASTUPDATETIME_ID = 109;
    public static final int ARCHIVELATESTPAGINATION_NOOFENTRY_ID = 209;
    public static final String ARCHIVELATESTPAGINATION_LASTUPDATETIME_LOCAL = "archivelatestpaginationp_lastupdatetime_local";
    public static final String ARCHIVELATESTPAGINATION_NOOFENTRY_LOCAL  = "archivelatestpagination_noofentry_local";
    public static final int ARCHIVELATESTPAGINATION_LASTUPDATETIME_LOCAL_ID = 309;
    public static final int ARCHIVELATESTPAGINATION_NOOFENTRY_LOCAL_ID  = 409;






    static {
        ID_KEY_MAP.put(ARTICLELOOKUP_LASTUPDATETIME_ID, ARTICLELOOKUP_LASTUPDATETIME);
        ID_KEY_MAP.put(ARTICLELOOKUP_NOOFENTRY_ID, ARTICLELOOKUP_NOOFENTRY);
        ID_KEY_MAP.put(ARTICLELOOKUP_LASTUPDATETIME_LOCAL_ID, ARTICLELOOKUP_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(ARTICLELOOKUP_NOOFENTRY_LOCAL_ID, ARTICLELOOKUP_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(ARTICLE_LASTUPDATETIME_ID, ARTICLE_LASTUPDATETIME);
        ID_KEY_MAP.put(ARTICLE_NOOFENTRY_ID, ARTICLE_NOOFENTRY);
        ID_KEY_MAP.put(ARTICLE_LASTUPDATETIME_LOCAL_ID, ARTICLE_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(ARTICLE_NOOFENTRY_LOCAL_ID, ARTICLE_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(CATEGORY_LASTUPDATETIME_ID, CATEGORY_LASTUPDATETIME);
        ID_KEY_MAP.put(CATEGORY_NOOFENTRY_ID, CATEGORY_NOOFENTRY);
        ID_KEY_MAP.put(CATEGORY_LASTUPDATETIME_LOCAL_ID, CATEGORY_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(CATEGORY_NOOFENTRY_LOCAL_ID, CATEGORY_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(DOMAIN_LASTUPDATETIME_ID, DOMAIN_LASTUPDATETIME);
        ID_KEY_MAP.put(DOMAIN_NOOFENTRY_ID, DOMAIN_NOOFENTRY);
        ID_KEY_MAP.put(DOMAIN_LASTUPDATETIME_LOCAL_ID, DOMAIN_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(DOMAIN_NOOFENTRY_LOCAL_ID, DOMAIN_NOOFENTRY_LOCAL);


        ID_KEY_MAP.put(FIRSTSUBDOMAIN_LASTUPDATETIME_ID, FIRSTSUBDOMAIN_LASTUPDATETIME);
        ID_KEY_MAP.put(FIRSTSUBDOMAIN_NOOFENTRY_ID, FIRSTSUBDOMAIN_NOOFENTRY);
        ID_KEY_MAP.put(FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL_ID, FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(FIRSTSUBDOMAIN_NOOFENTRY_LOCAL_ID, FIRSTSUBDOMAIN_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(LATESTNEWSPAGINATION_LASTUPDATETIME_ID, LATESTNEWSPAGINATION_LASTUPDATETIME);
        ID_KEY_MAP.put(LATESTNEWSPAGINATION_NOOFENTRY_ID, LATESTNEWSPAGINATION_NOOFENTRY);
        ID_KEY_MAP.put(LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL_ID, LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(LATESTNEWSPAGINATION_NOOFENTRY_LOCAL_ID, LATESTNEWSPAGINATION_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(ARCHIVELATESTLOOKUP_LASTUPDATETIME_ID, ARCHIVELATESTLOOKUP_LASTUPDATETIME);
        ID_KEY_MAP.put(ARCHIVELATESTLOOKUP_NOOFENTRY_ID, ARCHIVELATESTLOOKUP_NOOFENTRY);
        ID_KEY_MAP.put(ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL_ID, ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL_ID, ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_ID, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME);
        ID_KEY_MAP.put(ARCHIVELATESTPAGELOOKUP_NOOFENTRY_ID, ARCHIVELATESTPAGELOOKUP_NOOFENTRY);
        ID_KEY_MAP.put(ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL_ID, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL_ID, ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL);

        ID_KEY_MAP.put(ARCHIVELATESTPAGINATION_LASTUPDATETIME_ID, ARCHIVELATESTPAGINATION_LASTUPDATETIME);
        ID_KEY_MAP.put(ARCHIVELATESTPAGINATION_NOOFENTRY_ID, ARCHIVELATESTPAGINATION_NOOFENTRY);
        ID_KEY_MAP.put(ARCHIVELATESTPAGINATION_LASTUPDATETIME_LOCAL_ID, ARCHIVELATESTPAGINATION_LASTUPDATETIME_LOCAL);
        ID_KEY_MAP.put(ARCHIVELATESTPAGINATION_NOOFENTRY_LOCAL_ID, ARCHIVELATESTPAGINATION_NOOFENTRY_LOCAL);




        ID_REMOTE_LOCAL_MAP.put(ARTICLELOOKUP_LASTUPDATETIME_ID, ARTICLELOOKUP_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARTICLELOOKUP_NOOFENTRY_ID, ARTICLELOOKUP_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARTICLE_LASTUPDATETIME_ID, ARTICLE_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARTICLE_NOOFENTRY_ID, ARTICLE_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(CATEGORY_LASTUPDATETIME_ID, CATEGORY_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(CATEGORY_NOOFENTRY_ID, CATEGORY_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(DOMAIN_LASTUPDATETIME_ID, DOMAIN_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(DOMAIN_NOOFENTRY_ID, DOMAIN_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(FIRSTSUBDOMAIN_LASTUPDATETIME_ID, FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(FIRSTSUBDOMAIN_NOOFENTRY_ID, FIRSTSUBDOMAIN_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(LATESTNEWSPAGINATION_LASTUPDATETIME_ID, LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(LATESTNEWSPAGINATION_NOOFENTRY_ID, LATESTNEWSPAGINATION_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARCHIVELATESTLOOKUP_LASTUPDATETIME_ID, ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARCHIVELATESTLOOKUP_NOOFENTRY_ID, ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_ID, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARCHIVELATESTPAGELOOKUP_NOOFENTRY_ID, ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARCHIVELATESTPAGINATION_LASTUPDATETIME_ID, ARCHIVELATESTPAGINATION_LASTUPDATETIME_LOCAL_ID );
        ID_REMOTE_LOCAL_MAP.put(ARCHIVELATESTPAGINATION_NOOFENTRY_ID, ARCHIVELATESTPAGINATION_NOOFENTRY_LOCAL_ID );


    }


    public static long getLastupdatetime(Context context, String key){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //String defaultLocation = context.getString(R.string.pref_location_default);
        return sp.getLong(key, DEFAULT_LASTUPDATETIME_VALUE);
    }
    public static void setLastupdatetime (Context context, long lastupdatetime, String key){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.putLong(key, lastupdatetime);
        editor.apply();
    }

    public static int getNoOfEntry(Context context, String key){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //String defaultLocation = context.getString(R.string.pref_location_default);
        return sp.getInt(key,  DEFAULT_NOOFENTRY_VALUE);
    }
    public static void setNoOfEntry(Context context, int noofentry, String key){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(key, noofentry);
        editor.apply();
    }


    public static long getArticlelookupLastupdatetime(Context context) {
        return getLastupdatetime(context, ARTICLELOOKUP_LASTUPDATETIME);
    }

    public static void setArticlelookupLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARTICLELOOKUP_LASTUPDATETIME);
    }

    public static int getArticlelookupNoOfEntry(Context context) {
        return getNoOfEntry(context, ARTICLELOOKUP_NOOFENTRY);
    }

    public static void setArticlelookupNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARTICLELOOKUP_NOOFENTRY);
    }



    public static long getArticlelookupLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, ARTICLELOOKUP_LASTUPDATETIME_LOCAL);
    }

    public static void setArticlelookupLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARTICLELOOKUP_LASTUPDATETIME_LOCAL);
    }

    public static int getArticlelookupNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, ARTICLELOOKUP_NOOFENTRY_LOCAL);
    }

    public static void setArticlelookupNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARTICLELOOKUP_NOOFENTRY_LOCAL);
    }










    public static long getArticleLastupdatetime(Context context) {
        return getLastupdatetime(context, ARTICLE_LASTUPDATETIME);
    }

    public static void setArticleLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARTICLE_LASTUPDATETIME);
    }

    public static int getArticleNoOfEntry(Context context) {
        return getNoOfEntry(context, ARTICLE_NOOFENTRY);
    }

    public static void setArticleNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARTICLE_NOOFENTRY);
    }


    public static long getArticleLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, ARTICLE_LASTUPDATETIME_LOCAL);
    }

    public static void setArticleLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARTICLE_LASTUPDATETIME_LOCAL);
    }

    public static int getArticleNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, ARTICLE_NOOFENTRY_LOCAL);
    }

    public static void setArticleNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARTICLE_NOOFENTRY_LOCAL);
    }








    public static long getCategoryLastupdatetime(Context context) {
        return getLastupdatetime(context, CATEGORY_LASTUPDATETIME);
    }

    public static void setCategoryLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, CATEGORY_LASTUPDATETIME);
    }

    public static int getCategoryNoOfEntry(Context context) {
        return getNoOfEntry(context, CATEGORY_NOOFENTRY);
    }

    public static void setCategoryNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, CATEGORY_NOOFENTRY);
    }



    public static long getCategoryLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, CATEGORY_LASTUPDATETIME_LOCAL);
    }

    public static void setCategoryLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, CATEGORY_LASTUPDATETIME_LOCAL);
    }

    public static int getCategoryNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, CATEGORY_NOOFENTRY_LOCAL);
    }

    public static void setCategoryNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, CATEGORY_NOOFENTRY_LOCAL);
    }






    public static long getDomainLastupdatetime(Context context) {
        return getLastupdatetime(context, DOMAIN_LASTUPDATETIME);
    }

    public static void setDomainLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, DOMAIN_LASTUPDATETIME);
    }

    public static int getDomainNoOfEntry(Context context) {
        return getNoOfEntry(context, DOMAIN_NOOFENTRY);
    }

    public static void setDomainNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, DOMAIN_NOOFENTRY);
    }



    public static long getDomainLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, DOMAIN_LASTUPDATETIME_LOCAL);
    }

    public static void setDomainLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, DOMAIN_LASTUPDATETIME_LOCAL);
    }

    public static int getDomainNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, DOMAIN_NOOFENTRY_LOCAL);
    }

    public static void setDomainNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, DOMAIN_NOOFENTRY_LOCAL);
    }






    public static long getFirstSubDomainLastupdatetime(Context context) {
        return getLastupdatetime(context, FIRSTSUBDOMAIN_LASTUPDATETIME);
    }

    public static void setFirstSubDomainLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, FIRSTSUBDOMAIN_LASTUPDATETIME);
    }

    public static int getFirstSubDomainNoOfEntry(Context context) {
        return getNoOfEntry(context, FIRSTSUBDOMAIN_NOOFENTRY);
    }

    public static void setFirstSubDomainNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, FIRSTSUBDOMAIN_NOOFENTRY);
    }


    public static long getFirstSubDomainLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL);
    }

    public static void setFirstSubDomainLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, FIRSTSUBDOMAIN_LASTUPDATETIME_LOCAL);
    }

    public static int getFirstSubDomainNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, FIRSTSUBDOMAIN_NOOFENTRY_LOCAL);
    }

    public static void setFirstSubDomainNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, FIRSTSUBDOMAIN_NOOFENTRY_LOCAL);
    }






    public static long getLatestNewsPaginationLastupdatetime(Context context) {
        return getLastupdatetime(context, LATESTNEWSPAGINATION_LASTUPDATETIME);
    }

    public static void setLatestNewsPaginationLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, LATESTNEWSPAGINATION_LASTUPDATETIME);
    }

    public static int getLatestNewsPaginationNoOfEntry(Context context) {
        return getNoOfEntry(context, LATESTNEWSPAGINATION_NOOFENTRY);
    }

    public static void setLatestNewsPaginationNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, LATESTNEWSPAGINATION_NOOFENTRY);
    }


    public static long getLatestNewsPaginationLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL);
    }

    public static void setLatestNewsPaginationLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, LATESTNEWSPAGINATION_LASTUPDATETIME_LOCAL);
    }

    public static int getLatestNewsPaginationNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, LATESTNEWSPAGINATION_NOOFENTRY_LOCAL);
    }

    public static void setLatestNewsPaginationNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, LATESTNEWSPAGINATION_NOOFENTRY_LOCAL);
    }



    public static long getArchiveLatestlookupLastupdatetime(Context context) {
        return getLastupdatetime(context, ARCHIVELATESTLOOKUP_LASTUPDATETIME);
    }

    public static void setArchiveLatestlookupLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARCHIVELATESTLOOKUP_LASTUPDATETIME);
    }

    public static int getArchiveLatestlookupNoOfEntry(Context context) {
        return getNoOfEntry(context, ARCHIVELATESTLOOKUP_NOOFENTRY);
    }

    public static void setArchiveLatestlookupNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARCHIVELATESTLOOKUP_NOOFENTRY);
    }


    public static long getArchiveLatestlookupLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL);
    }

    public static void setArchiveLatestlookupLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARCHIVELATESTLOOKUP_LASTUPDATETIME_LOCAL);
    }

    public static int getArchiveLatestlookupNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL);
    }

    public static void setArchiveLatestlookupNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARCHIVELATESTLOOKUP_NOOFENTRY_LOCAL);
    }





    public static long getArchiveLatestPagelookupLastupdatetime(Context context) {
        return getLastupdatetime(context, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME);
    }

    public static void setArchiveLatestPagelookupLastupdatetime(Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME);
    }

    public static int getArchiveLatestPagelookupNoOfEntry(Context context) {
        return getNoOfEntry(context, ARCHIVELATESTPAGELOOKUP_NOOFENTRY);
    }

    public static void setArchiveLatestPagelookupNoOfEntry(Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARCHIVELATESTPAGELOOKUP_NOOFENTRY);
    }


    public static long getArchiveLatestPagelookupLastupdatetimeLocal (Context context) {
        return getLastupdatetime(context, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL);
    }

    public static void setArchiveLatestPagelookupLastupdatetimeLocal (Context context, long lastupdatetime) {
        setLastupdatetime(context, lastupdatetime, ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_LOCAL);
    }

    public static int getArchiveLatestPagelookupNoOfEntryLocal (Context context) {
        return getNoOfEntry(context, ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL);
    }

    public static void setArchiveLatestPagelookupNoOfEntryLocal (Context context, int noofentry) {
        setNoOfEntry(context, noofentry, ARCHIVELATESTPAGELOOKUP_NOOFENTRY_LOCAL);
    }









    //the following is for gongnews
    public static int getLastUpdateNoOfEntry(Context context, String key){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //String defaultLocation = context.getString(R.string.pref_location_default);
        return sp.getInt(key+"_lastupdatenoofentry",  DEFAULT_NOOFENTRY_VALUE);
    }
    public static void setLastUpdateNoOfEntry(Context context, int noofentry, String key){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        editor.putInt(key+"_lastupdatenoofentry", noofentry);
        editor.apply();
    }







    public static List<Integer> getPreferredlist(Context context){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        //String defaultLocation = context.getString(R.string.pref_location_default);
        String result = sp.getString(PREFERRED_LIST, DEFAULT_PREFERRED_LIST_STRING);

        List<Integer> resultlist = new ArrayList<Integer>();
        for (String s : result.split(DEFAULT_PREFERRED_LIST_DELIMITER)){
            resultlist.add(Integer.valueOf(s));
        }

        return resultlist;
    }
    public static void setPreferredlist (Context context, List<Integer> intlist){
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        SharedPreferences.Editor editor = sp.edit();
        StringBuilder sb = new StringBuilder();

        for(int x: intlist) {
            sb.append(String.valueOf(x)).append(DEFAULT_PREFERRED_LIST_DELIMITER);
        }
        sb.deleteCharAt(sb.length()-1);

        editor.putString(PREFERRED_LIST, sb.toString());
        editor.apply();
    }



}
