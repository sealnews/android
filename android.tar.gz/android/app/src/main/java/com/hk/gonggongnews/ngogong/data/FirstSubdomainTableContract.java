package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by ismile on 10/15/2017.
 */

public class FirstSubdomainTableContract {
    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_FIRSTSUBDOMAIN= "firstsubdomain";

    public static final class FirstSubdomainEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FIRSTSUBDOMAIN)
                .build();

        public static final String TABLE_NAME = "firstsubdomain";

        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_DOMAINTABLE_ID = "domaintable_id";
        public static final String COLUMN_CATEGORYTABLE_ID = "categorytable_id";
        public static final String COLUMN_SOURCEICONURL = "sourceiconurl";

    }


}
