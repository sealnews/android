package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.FragLookupTableContract.FragLookupEntry.CONTENT_URI;
import static com.hk.gonggongnews.ngogong.data.FragLookupTableContract.FragLookupEntry.CONTENT_URI_NAME;

/**
 * Created by ismile on 12/5/2017.
 */

public class FragLookupTableContract {




    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final int INDEX_NAME = 0;
    public static final int INDEX_CATEGORYTABLE_ID= 1;
    public static final int INDEX_NOOFENTRY= 2;
    public static final int INDEX_LASTUPDATETIME = 3;
    public static final int INDEX_SHEETID = 4;
    public static final int INDEX_SHEETID_URL  = 5;
    public static final String[] PROJECTION = {
            FragLookupEntry.COLUMN_NAME,
            FragLookupEntry.COLUMN_CATEGORYTABLE_ID,
            FragLookupEntry.COLUMN_NOOFENTRY,
            FragLookupEntry.COLUMN_LASTUPDATETIME,
            FragLookupEntry.COLUMN_SHEETID,
            FragLookupEntry.COLUMN_SHEETID_URL
    };


    public static final String SELECTION_NAME = " fraglookup.name = ? ";
    public static final String SELECTION_CATEGORYTABLE_ID = " fraglookup.categorytable_id = ? ";
    public static final String SELECTION_SHEET_ID = " fraglookup.sheetid == ? ";
    public static final String GROUP_BY_NAME = " fraglookup.name ";
    public static final String ORDER_BY_SHEER_ID = " fraglookup.sheetid ASC ";



    public static final String PATH_FRAGLOOKUP = "fraglookup";
    public static final String PATH_NAME = "name";

    public static final class FragLookupEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGLOOKUP)
                .build();

        public static final Uri CONTENT_URI_NAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGLOOKUP)
                .appendPath(PATH_NAME)
                .build();


        public static final String TABLE_NAME = "fraglookup";

        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_CATEGORYTABLE_ID = "categorytable_id";
        public static final String COLUMN_NOOFENTRY = "noofentry";
        public static final String COLUMN_LASTUPDATETIME = "lastupdatetime";
        public static final String COLUMN_SHEETID = "sheetid";
        public static final String COLUMN_SHEETID_URL = "sheetid_url";

    }

    public static long decodeGetLowerBound(String range) {
        String result  = range.split("ZZ")[0];
        return Long.valueOf(result);
    }

    public static long decodeGetHigherBound(String range) {
        String result = range.split("ZZ")[1];
        return Long.valueOf(result);
    }

    public static Uri buildUriWithNamePathAndName ( String name) {
        return CONTENT_URI_NAME.buildUpon()
                .appendPath(name)
                .build();
    }



}
