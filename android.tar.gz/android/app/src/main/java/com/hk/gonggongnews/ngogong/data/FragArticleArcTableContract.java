package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.FragArticleArcTableContract.FragArticleArcEntry.CONTENT_URI;
import static com.hk.gonggongnews.ngogong.data.FragArticleArcTableContract.FragArticleArcEntry.CONTENT_URI_CATEGORY;
import static com.hk.gonggongnews.ngogong.data.FragArticleArcTableContract.FragArticleArcEntry.CONTENT_URI_FIRSTSUBDOMAIN;
import static com.hk.gonggongnews.ngogong.data.FragArticleArcTableContract.FragArticleArcEntry.CONTENT_URI_NAME;

/**
 * Created by ismile on 12/5/2017.
 */

public class FragArticleArcTableContract {

    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final int INDEX_RAWQUERY_NAME = 13;
    public static final int INDEX_RAWQUERY_CATEGORYTABLE_ID = 14;

    public static final String RAWQUERY_ORDERSTRING = " order by fragarticlearc.timestampondoc DESC , fragarticlearc.title DESC  ";
    public static final String RAWQUERY_FRAGARTICLEARC_WHEREIDSTRING = " fragarticlearc._id >= ? and fragarticlearc._id <= ? ";
    public static final String RAWQUERY_FRAGARTICLEARC_WHERENAMESTRING = " fragarticlearc.name = ? ";
    public static final String RAWQUERY_FRAGARTICLEARC_WHEREFIRSTSUBSTRING = " fragarticlearc.firstsubdomaintable_id == ?  ";
    public static final String RAWQUERY_FRAGARTICLEARC_WHERECATEGORYSTRING = " fragarticlearc.categorytable_id  = ?  ";
    public static final String RAWQUERY_FRAGARTICLEARC_SELECTIONSTRING =
            " select fragarticlearc._id as fragarticlearc_id, "
                    + " fragarticlearc.finalurl as fragarticlearc_finalurl, "
                    + " fragarticlearc.timestampondoc as fragarticlearc_timestampondoc, "
                    + " fragarticlearc.title as fragarticlearc_title, "
                    + " fragarticlearc.imageurl as fragarticlearc_imageurl, "
                    + " fragarticlearc.similiaritiescount as fragarticlearc_similaritiescount, "
                    + " fragarticlearc.entry as fragarticlearc_entry, "
                    + " fragarticlearc.firstsubdomaintable_id as fragarticlearc_firstsubdomaintable_id, "
                    + " fragarticlearc.timestampondocandid as fragarticlearc_timestampondocandid, "
                    + " fragarticlearc.article_id as fragarticlearc_article_id, "
                    + " signal.bookmarkalready as signal_bookmarkalready, "
                    + " signal.readalready as signal_readalready, "
                    + " firstsubdomain.sourceiconurl as firstsubdomain_sourceiconurl, "
                    + " fragarticlearc.name as fragarticlearc_name, "
                    + " fragarticlearc.categorytable_id as fragarticlearc_categorytable_id "
                    + " from fragarticlearc "
                    + " left join firstsubdomain on fragarticlearc.firstsubdomaintable_id = firstsubdomain.firstsubdomaintable_id "
                    + " left join signal on fragarticlearc.article_id = signal.article_id ";
    public static final String RAWQUERY_FRAGARTICLEARC_RANGESTRING = RAWQUERY_FRAGARTICLEARC_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLEARC_WHEREIDSTRING
            + RAWQUERY_ORDERSTRING;
    public static final String RAWQUERY_FRAGARTICLEARC_NAMESTRING = RAWQUERY_FRAGARTICLEARC_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLEARC_WHERENAMESTRING
            + RAWQUERY_ORDERSTRING;
    public static final String RAWQUERY_FRAGARTICLEARC_CATEGORYSTRING = RAWQUERY_FRAGARTICLEARC_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLEARC_WHERECATEGORYSTRING
            + RAWQUERY_ORDERSTRING;
    public static final String RAWQUERY_FRAGARTICLEARC_FIRSTSUBSTRING = RAWQUERY_FRAGARTICLEARC_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLEARC_WHEREFIRSTSUBSTRING
            + RAWQUERY_ORDERSTRING;

    public static final String PATH_FRAGARTICLEARC = "fragarticlearc";
    public static final String PATH_NAME = "name";
    public static final String PATH_FIRSTSUBDOMAIN = "firstsubdomain";
    public static final String PATH_CATEGORY = "category";



    public static final class FragArticleArcEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLEARC)
                .build();

        public static final Uri CONTENT_URI_NAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLEARC)
                .appendPath(PATH_NAME)
                .build();

        public static final Uri CONTENT_URI_FIRSTSUBDOMAIN  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLEARC)
                .appendPath(PATH_FIRSTSUBDOMAIN)
                .build();

        public static final Uri CONTENT_URI_CATEGORY = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLEARC)
                .appendPath(PATH_CATEGORY)
                .build();


        public static final String TABLE_NAME = "fragarticlearc";

        public static final String COLUMN_TIMESTAMPONDOC_AND_ID = "timestampondocandid";
        public static final String COLUMN_ARTICLEID = "article_id";
        public static final String COLUMN_TIMESTAMPONDOC = "timestampondoc";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_FINALURL = "finalurl";
        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_IMAGEURL = "imageurl";
        public static final String COLUMN_SIMILARITIESCOUNT = "similiaritiescount";
        public static final String COLUMN_ENTRY = "entry";
        public static final String COLUMN_NAME= "name";
        public static final String COLUMN_CATEGORYTABLE_ID = "categorytable_id";

    }

    public static Uri buildPaginationUriWithTimestampondocAndId(String timestampondocandid) {
        return CONTENT_URI.buildUpon()
                .appendPath(timestampondocandid)
                .build();
    }

    public static String decodeGetTimestampondoc(String timestampondocandid) {
        String timestamp = timestampondocandid.split("Z")[0];
        return timestamp;
    }

    public static String decodeGetId(String timestampondocandid) {
        String id = timestampondocandid.split("Z")[1];
        return id;
    }


    public static Uri buildUriWithNamePathAndName ( String name) {
        return CONTENT_URI_NAME.buildUpon()
                .appendPath(name)
                .build();
    }

    public static Uri buildUriWithFSD ( int id) {
        return CONTENT_URI_FIRSTSUBDOMAIN.buildUpon()
                .appendPath(String.valueOf(id))
                .build();
    }

    public static Uri buildUriWithCategory ( int id) {
        return CONTENT_URI_CATEGORY.buildUpon()
                .appendPath(String.valueOf(id))
                .build();
    }




}
