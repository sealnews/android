package com.hk.gonggongnews.ngogong;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.load.MultiTransformation;
import com.bumptech.glide.request.RequestOptions;
import com.hk.gonggongnews.ngogong.data.GongInfoContract;
import com.hk.gonggongnews.ngogong.data.GongInfoLookupContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.util.GongInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropTransformation;

import static com.hk.gonggongnews.ngogong.GlideOptions.bitmapTransform;

/**
 * Created by ismile on 11/24/2017.
 */

public class GongNewsAdapter extends
        RecyclerView.Adapter<GongNewsAdapter.GongNewsViewHolder> {

    private final String TAG = GongNewsAdapter.class.getSimpleName();

    /* The context we use to utility methods, app resources and layout inflaters */
    private final Context mContext;
    private List<GongInfo> mGongInfoList;


    private View.OnClickListener mcallGongNewsActivity;

    private Cursor mCursor;

    /*
     * Below, we've defined an interface to handle clicks on items within this Adapter. In the
     * constructor of our ForecastAdapter, we receive an instance of a class that has implemented
     * said interface. We store that instance in this variable to call the onClick method whenever
     * an item is clicked in the list.
     */
    private GongNewsAdapter.GongNewsAdapterOnClickHandler mClickHandler;

    /**
     * The interface that receives onClick messages.
     */
    public interface GongNewsAdapterOnClickHandler {
        void onClickIndEntity(String title, int id);

    }



    /**
     * Creates a ForecastAdapter.
     *
     * @param context      Used to talk to the UI and app resources
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */

    public GongNewsAdapter(@NonNull Context context,
                           GongNewsAdapter.GongNewsAdapterOnClickHandler clickHandler) {
        mContext = context;
        mClickHandler = clickHandler;
        mGongInfoList = new ArrayList<>();




        mcallGongNewsActivity = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String sourcetitle = (String) view.getTag(R.string.VIEWTAG_TITLE);
                int sourceid = (int) view.getTag(R.string.VIEWTAG_TITLE_ID);

                //should start detailactivity if available
                LogUtil.debug(TAG, "---------------------> starting mcallGongNewsActivity sourcetitle="
                        + sourcetitle
                        + ",sourceid="
                        + sourceid);
                mClickHandler.onClickIndEntity(sourcetitle, sourceid);
            }
        };
        LogUtil.debug (TAG, " GongNewsAdapter constructor ");
    }


    /**
     * This gets called when each new ViewHolder is created. This happens when the RecyclerView
     * is laid out. Enough ViewHolders will be created to fill the screen and allow for scrolling.
     *
     * @param viewGroup The ViewGroup that these ViewHolders are contained within.
     * @param viewType  If your RecyclerView has more than one type of item (like ours does) you
     *                  can use this viewType integer to provide a different layout. See
     *                  {@link android.support.v7.widget.RecyclerView.Adapter#getItemViewType(int)}
     *                  for more details.
     * @return A new ForecastAdapterViewHolder that holds the View for each list item
     */
    @Override
    public GongNewsAdapter.GongNewsViewHolder
    onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        int layoutId;
        View view;

        layoutId = R.layout.entity_card;
        view = LayoutInflater.from(mContext).inflate(layoutId, viewGroup, false);

        view.setFocusable(true);
        LogUtil.debug(TAG, "GongNewsAdapter.GongNewsViewHolder onCreateViewHolder");

        return new GongNewsAdapter.GongNewsViewHolder(view);

    }

    /**
     * OnBindViewHolder is called by the RecyclerView to display the data at the specified
     * position. In this method, we update the contents of the ViewHolder to display the weather
     * details for this particular position, using the "position" argument that is conveniently
     * passed into us.
     *
     * @param gongNewsAdapterViewHolder The ViewHolder which should be updated to represent the
     *                                  contents of the item at the given position in the data set.
     * @param position                  The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(GongNewsAdapter.GongNewsViewHolder gongNewsAdapterViewHolder,
                                 int position) {
        final int titleID;
        final String title;
        mCursor.moveToPosition(position);

        GlideApp.with(mContext)
                .load( mCursor.getString(GongInfoLookupContract.INDEX_SOURCEICONURL))
                .placeholder(R.drawable.ic_tmp_icon)
                .transform(new MultiTransformation(new BlurTransformation(7), new CropTransformation(180,135)))
                //.apply(new RequestOptions().transform(new BlurTransformation(50)))
                //.fitCenter()
                .into(gongNewsAdapterViewHolder.iv_SourceiconView);

        gongNewsAdapterViewHolder.tv_SourceTitleView.setText(mCursor.getString(GongInfoLookupContract.INDEX_NAME));

        gongNewsAdapterViewHolder.fl_entity_flayout.setOnClickListener(mcallGongNewsActivity);
        gongNewsAdapterViewHolder.fl_entity_flayout.setTag(R.string.VIEWTAG_TITLE, mCursor.getString(GongInfoLookupContract.INDEX_NAME));
        gongNewsAdapterViewHolder.fl_entity_flayout.setTag(R.string.VIEWTAG_TITLE_ID, mCursor.getInt(GongInfoLookupContract.INDEX_ID));


        LogUtil.debug(TAG, " GongNewsAdapter.GongNewsViewHolder onBindViewHolder 1 " + position);

    }


    /**
     * This method simply returns the number of items to display. It is used behind the scenes
     * to help layout our Views and for animations.
     *
     * @return The number of items available in our forecast
     */
    @Override
    public int getItemCount() {
        if (mCursor != null) {
            LogUtil.debug(TAG, " GongNewsAdapter getitemcount 1 =" + mCursor.getCount());
            return mCursor.getCount();
        } else {
            return 0;
        }
    }

    /**
     * Returns an integer code related to the type of View we want the ViewHolder to be at a given
     * position. This method is useful when we want to use different layouts for different items
     * depending on their position. In Sunshine, we take advantage of this method to provide a
     * different layout for the "today" layout. The "today" layout is only shown in portrait mode
     * with the first item in the list.
     *
     * @param position index within our RecyclerView and Cursor
     * @return the view type (today or future day)
     */
    @Override
    public int getItemViewType(int position) {
        //return -1;
        return 0;
    }

    /**
     * Swaps the cursor used by the ForecastAdapter for its weather data. This method is called by
     * MainActivity after a load has finished, as well as when the Loader responsible for loading
     * the weather data is reset. When this method is called, we assume we have a completely new
     * set of data, so we call notifyDataSetChanged to tell the RecyclerView to update.
     *
     * @param newCursor the new cursor to use as ForecastAdapter's data source
     */
    void swapCursor(Cursor newCursor) {
        LogUtil.debug(TAG, " GongNewsAdapter swapcursor  ");

        mCursor = newCursor;
        if (mCursor != null) {
            LogUtil.debug(TAG, "    ListIndNewsAdapter swapcursor  getcount=" + mCursor.getCount());
        }
        notifyDataSetChanged();
    }


    /**
     * A ViewHolder is a required part of the pattern for RecyclerViews. It mostly behaves as
     * a cache of the child views for a forecast item. It's also a convenient place to set an
     * OnClickListener, since it has access to the adapter and the views.
     */
    class GongNewsViewHolder extends RecyclerView.ViewHolder  {
        private final String TAG = GongNewsAdapter.GongNewsViewHolder.class.getSimpleName();

        //the whole view of item
        //final View articleindlistitem;

        //article_list_item_primary.xml
        final ImageView iv_SourceiconView;
        final TextView tv_SourceTitleView;
        final FrameLayout fl_entity_flayout;


        GongNewsViewHolder(View view) {
            super(view);


            iv_SourceiconView = (ImageView) view.findViewById(R.id.sourceicon);
            tv_SourceTitleView = (TextView) view.findViewById(R.id.sourcetitle);
            fl_entity_flayout = (FrameLayout) view.findViewById(R.id.entity_flayout);


            LogUtil.debug(TAG, " GongNewsViewHolder constructor 1");


        }


    }

}


