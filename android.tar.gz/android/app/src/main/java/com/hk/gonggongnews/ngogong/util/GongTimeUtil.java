package com.hk.gonggongnews.ngogong.util;



import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.text.format.DateUtils;

import com.hk.gonggongnews.ngogong.R;
import com.hk.gonggongnews.ngogong.data.GongPreference;
//10739579165
/**
 * Created by ismile on 10/22/2017.
 */

public class GongTimeUtil {
    public static final long DAY_IN_MILLIS = TimeUnit.DAYS.toMillis(1);
    public static final long HOUR_IN_MILLIS = TimeUnit.HOURS.toMillis(1);

    public static final long CHECK_NEW_CONTENT_IN_MILLIS = (long) HOUR_IN_MILLIS / 2;
    public static final long CHECK_NEW_CONTENT_IN_SECS = (long) CHECK_NEW_CONTENT_IN_MILLIS / 1000;
    public static final long CHECK_NEW_CONTENT_IN_DAYS = (long) DAY_IN_MILLIS / 1000;
    public static TimeZone hkTimeZone = TimeZone.getTimeZone("GMT+8");

    public static String getDisplayTimeStringFromData(long timedata) {
        //long hkgmtOffsetMillis = hkTimeZone.getOffset(timedata * 1000);
        //long hktimeSinceEpochLocalTimeMillis = (timedata * 1000) + hkgmtOffsetMillis;

        TimeZone hkTimeZone16 = TimeZone.getTimeZone("GMT+16");
        long hkgmtOffsetMillis16 = hkTimeZone16.getOffset(timedata * 1000);
        long hktimeSinceEpochLocalTimeMillis16 = (timedata * 1000) + hkgmtOffsetMillis16;

        SimpleDateFormat hkdateformat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm 香港 ");
        String result = hkdateformat.format(Long.valueOf(hktimeSinceEpochLocalTimeMillis16));

        return result;
    }

    public static String getDisplayTimeStringFromData(long timedata, Context context) {
        //long hkgmtOffsetMillis = hkTimeZone.getOffset(timedata * 1000);
        //long hktimeSinceEpochLocalTimeMillis = (timedata * 1000) + hkgmtOffsetMillis;

        TimeZone hkTimeZone16 = TimeZone.getTimeZone("GMT+16");
        long hkgmtOffsetMillis16 = hkTimeZone16.getOffset(timedata * 1000);
        long hktimeSinceEpochLocalTimeMillis16 = (timedata * 1000) + hkgmtOffsetMillis16;

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
        String  choiceOfLang = sp.getString(context.getString(R.string.gong_lang_pref), context.getString(R.string.choice_value_lang_eng));
        SimpleDateFormat hkdateformat;
        String result;
        if (choiceOfLang.compareTo(context.getString(R.string.choice_value_lang_eng)) == 0){
            hkdateformat = new SimpleDateFormat("yyyy-MM-dd HH:mm ");
            result = hkdateformat.format(Long.valueOf(hktimeSinceEpochLocalTimeMillis16)) + "HKT";
        } else {
            hkdateformat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm 香港 ");
            result = hkdateformat.format(Long.valueOf(hktimeSinceEpochLocalTimeMillis16));
        }

        return result;
    }

    public static long getHKOffsetTime(long timedata) {
        long hkgmtOffsetMillis = hkTimeZone.getOffset(timedata * 1000);
        long hktimeSinceEpochLocalTimeMillis = (timedata * 1000) + hkgmtOffsetMillis;

        return hktimeSinceEpochLocalTimeMillis;
    }

    public static boolean shouldCheckUpdateByTime(Context context, int key) {
        long utcNowMillis = System.currentTimeMillis();
        long hkgmtOffsetMillis = hkTimeZone.getOffset(utcNowMillis);
        long hktimeSinceEpochLocalTimeMillis = (utcNowMillis) + hkgmtOffsetMillis;
        long hktimeSinceEpochLocalTimeSecs = hktimeSinceEpochLocalTimeMillis / 1000;

        //key is the remote key
        //check if lastupdatetime is one day old or greater than CHECK_NEW_CONENT_IN_SECS
        //
        if ((GongPreference.getLastupdatetime(context,
                GongPreference.ID_KEY_MAP.get(key))
                > (GongPreference.getLastupdatetime(context,
                GongPreference.ID_KEY_MAP.get(GongPreference.ID_REMOTE_LOCAL_MAP.get(key)))
                + CHECK_NEW_CONTENT_IN_SECS)
        )
                || ((GongPreference.getLastupdatetime(context,
                GongPreference.ID_KEY_MAP.get(key)) + CHECK_NEW_CONTENT_IN_DAYS)
                > hktimeSinceEpochLocalTimeSecs)) {
            return true;
        } else {
            return false;
        }

    }



}
