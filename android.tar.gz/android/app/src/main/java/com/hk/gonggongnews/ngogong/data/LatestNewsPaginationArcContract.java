package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Created by ismile on 11/10/2017.
 */

public class LatestNewsPaginationArcContract {
    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String PATH_PAGINATION_ARCHIVE = "latestnewspaginationarchive";

    public static final String RAWQUERYORDERSTRING = " order by paginationarchive.timestampondocandid DESC ";
    public static final String RAWQUERYPAGINATIONWHERESTRING = " paginationarchive._id >= ? and paginationarchive._id <= ? ";
    public static final String RAWQUERYPAGINATIONWHEREFIRSTSUBSTRING = " paginationarchive.firstsubdomaintable_id == ?  ";
    public static final String RAWQUERYPAGINATIONSELECTIONSTRING =
            " select paginationarchive._id as pagination_id, "
                    + " paginationarchive.finalurl as paginationarchive_finalurl, "
                    + " paginationarchive.timestampondoc as paginationarchive_timestampondoc, "
                    + " paginationarchive.title as paginationarchive_title, "
                    + " paginationarchive.imageurl as paginationarchive_imageurl, "
                    + " paginationarchive.similiaritiescount as paginationarchive_similaritiescount, "
                    + " paginationarchive.entry as paginationarchive_entry, "
                    + " paginationarchive.firstsubdomaintable_id as paginationarchive_firstsubdomaintable_id, "
                    + " paginationarchive.timestampondocandid as paginationarchive_timestampondocandid, "
                    + " paginationarchive.article_id as paginationarchive_article_id, "
                    + " signal.bookmarkalready as signal_bookmarkalready, "
                    + " signal.readalready as signal_readalready, "
                    + " firstsubdomain.sourceiconurl as firstsubdomain_sourceiconurl "
                    + " from paginationarchive "
                    + " left join firstsubdomain on paginationarchive.firstsubdomaintable_id = firstsubdomain.firstsubdomaintable_id "
                    + " left join signal on paginationarchive.article_id = signal.article_id ";
    public static final String RAWQUERYPAGINATIONRANGESTRING = RAWQUERYPAGINATIONSELECTIONSTRING
            + " where " + RAWQUERYPAGINATIONWHERESTRING
            + RAWQUERYORDERSTRING;
    public static final String RAWQUERYPAGINATIONSTRING = RAWQUERYPAGINATIONSELECTIONSTRING
            + RAWQUERYORDERSTRING;


    public static final class PaginationArcEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_PAGINATION_ARCHIVE)
                .build();

        public static final String TABLE_NAME = "paginationarchive";

        public static final String COLUMN_TIMESTAMPONDOC_AND_ID = "timestampondocandid";
        public static final String COLUMN_ARTICLEID = "article_id";
        public static final String COLUMN_TIMESTAMPONDOC = "timestampondoc";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_FINALURL = "finalurl";
        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_IMAGEURL = "imageurl";
        public static final String COLUMN_SIMILARITIESCOUNT = "similiaritiescount";
        public static final String COLUMN_ENTRY = "entry";

        public static Uri buildPaginationUriWithTimestampondocAndId(String timestampondocandid) {
            return CONTENT_URI.buildUpon()
                    .appendPath(timestampondocandid)
                    .build();
        }

        public static String decodeGetTimestampondoc(String timestampondocandid) {
            String timestamp = timestampondocandid.split("Z")[0];
            return timestamp;
        }

        public static String decodeGetId(String timestampondocandid) {
            String id = timestampondocandid.split("Z")[1];
            return id;
        }
    }

}
