package com.hk.gonggongnews.ngogong;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.util.ArticleInfo;
import com.hk.gonggongnews.ngogong.util.GongTimeUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 10/6/2017.
 */

public class LatestNewsPaginationAdapter extends
        RecyclerView.Adapter<LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder> {

    private final String TAG = LatestNewsPaginationAdapter.class.getSimpleName();

    /* The context we use to utility methods, app resources and layout inflaters */
    private final Context mContext;

    private View.OnClickListener mcallDetailActivity;
    private View.OnClickListener mshareClickListener;
    private View.OnClickListener mbookmarkClickListener;
    private Map<Integer, Integer> mSignalMap;
    public final static int BOOKMARKALREADY_MASK = 0x0001;
    public final static int READALREADY_MASK = 0x0002;
    public final static int EXPANDALREADY_MASK = 0x0004;
    private static final int VIEWTAG_ARTICLEID = 1;
    private static final int VIEWTAG_FINALURL = 2;

    private boolean mInitupdateSignalMapFromCursor;
    private Cursor mCursor;
    private boolean mUsingSelectedArchivetoDisplay;

    /*
     * Below, we've defined an interface to handle clicks on items within this Adapter. In the
     * constructor of our ForecastAdapter, we receive an instance of a class that has implemented
     * said interface. We store that instance in this variable to call the onClick method whenever
     * an item is clicked in the list.
     */
    private LatestNewsPaginationAdapter.LatestNewsPaginationAdapterOnClickHandler mClickHandler;

    /**
     * The interface that receives onClick messages.
     */
    public interface LatestNewsPaginationAdapterOnClickHandler {
        void onClickLatestNewsPagination(long entryID, String finalurl);
        void onClickExpandNews(String jsonArticleList, String jsonBookmarkList);
        void onClickBookmarkArticleStoreOrRemove (long entryID, boolean save);
    }



    /**
     * Creates a ForecastAdapter.
     *
     * @param context      Used to talk to the UI and app resources
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */

    public LatestNewsPaginationAdapter(@NonNull Context context,
                                       LatestNewsPaginationAdapter.LatestNewsPaginationAdapterOnClickHandler clickHandler) {
        mContext = context;
        mClickHandler = clickHandler;
        mSignalMap = new HashMap<Integer, Integer>();
        mcallDetailActivity = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int articleID = (int) view.getTag(R.string.VIEWTAG_ARTICLEID);
                String finalurl = (String) view.getTag(R.string.VIEWTAG_FINALURL);
                int readalready_inmap = 0;
                int bitvalBookRead = 0;
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, articleID);
                if (mSignalMap.containsKey(articleID)) {
                    bitvalBookRead = mSignalMap.get(articleID);
                }
                readalready_inmap = bitvalBookRead | READALREADY_MASK;
                mSignalMap.put(articleID, readalready_inmap);
                contentValues.put(SignalContract.SignalEntry.COLUMN_READALREADY, 1);
                mContext.getContentResolver().insert(
                        uri,
                        contentValues);


                //set the background color
                ViewGroup twoupLevelLayout = ((ViewGroup) ((ViewGroup) view.getParent()).getParent());
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }

                        //should start detailactivity if available
                LogUtil.debug(TAG, "---------------------> starting detail activity articleid="
                        + articleID
                        + ",finalurl="
                        + finalurl);
                sendbackToHostActivity(articleID, finalurl);
            }
        };
        mbookmarkClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int bookmarkalready_inmap = 0;
                int bitvalBookRead = 0;
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;
                int articleID = (int) view.getTag(R.string.VIEWTAG_ARTICLEID);

                LogUtil.debug(TAG, " ib_bookmarkButton onclick 1");
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, articleID);

                if (view.isSelected() == false) {
                    view.setSelected(true);

                    if (mSignalMap.containsKey(articleID)) {
                        bitvalBookRead = mSignalMap.get(articleID);
                    }
                    bookmarkalready_inmap = bitvalBookRead | BOOKMARKALREADY_MASK;
                    mSignalMap.put(articleID, bookmarkalready_inmap);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 1);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 2 = bitvalBookRead"
                            + bitvalBookRead
                            + ", bookmarkalready_inmap="
                            + bookmarkalready_inmap);
                    mClickHandler.onClickBookmarkArticleStoreOrRemove(articleID, true);



                } else {
                    //set it off
                    view.setSelected(false);

                    if (mSignalMap.containsKey(articleID)) {
                        bitvalBookRead = mSignalMap.get(articleID);
                    }
                    bookmarkalready_inmap = bitvalBookRead & ~BOOKMARKALREADY_MASK;
                    mSignalMap.put(articleID, bookmarkalready_inmap);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 0);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 3 = bitvalBookRead"
                            + bitvalBookRead
                            + ", bookmarkalready_inmap="
                            + bookmarkalready_inmap);
                    mClickHandler.onClickBookmarkArticleStoreOrRemove(articleID, false);

                }
                mContext.getContentResolver().insert(
                        uri,
                        contentValues);
            }
        };


        mshareClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LogUtil.debug(TAG, " ib_sharebutton 1");
                String finalurl = (String) view.getTag(R.string.VIEWTAG_FINALURL);
                String title = (String) view.getTag(R.string.VIEWTAG_TITLE);

                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = title + "\n" + finalurl;
                String shareSub = title;
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                mContext.startActivity(Intent.createChooser(sharingIntent, "Share using"));
                LogUtil.debug(TAG, " ib_sharebutton 2");

            }
        };
        LogUtil.debug (TAG, " LatestNewsPaginationAdapter constructor ");
    }

    private void sendbackToHostActivity(int entryID , String finalurl){
        LogUtil.debug(TAG, "--> sendbacktohostactivity entryID="+ entryID +",finalurl="+finalurl);
        mClickHandler.onClickLatestNewsPagination(entryID,finalurl);
    }


    /**
     * This gets called when each new ViewHolder is created. This happens when the RecyclerView
     * is laid out. Enough ViewHolders will be created to fill the screen and allow for scrolling.
     *
     * @param viewGroup The ViewGroup that these ViewHolders are contained within.
     * @param viewType  If your RecyclerView has more than one type of item (like ours does) you
     *                  can use this viewType integer to provide a different layout. See
     *                  {@link android.support.v7.widget.RecyclerView.Adapter#getItemViewType(int)}
     *                  for more details.
     * @return A new ForecastAdapterViewHolder that holds the View for each list item
     */
    @Override
    public LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder
                    onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        int layoutId;
        View view;

        layoutId = R.layout.article_list_item;
        view = LayoutInflater.from(mContext).inflate(layoutId, viewGroup, false);

        view.setFocusable(true);
        LogUtil.debug(TAG, "LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder  onCreateViewHolder");

        return new LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder(view);

    }

    /**
     * OnBindViewHolder is called by the RecyclerView to display the data at the specified
     * position. In this method, we update the contents of the ViewHolder to display the weather
     * details for this particular position, using the "position" argument that is conveniently
     * passed into us.
     *
     * @param latestNewsPaginationAdapterViewHolder The ViewHolder which should be updated to represent the
     *                                  contents of the item at the given position in the data set.
     * @param position                  The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder latestNewsPaginationAdapterViewHolder,
                                 int position) {
        mCursor.moveToPosition(position);

        LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 1 " + position);

        final int articlePrimaryID = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_ARTICLE_ID);
        final String finalurl = mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FINALURL);




        //article_list_item_primary.xml
        //https://en.wikipedia.org/wiki/File:Finland_road_sign_416.svg
        //https://en.wikipedia.org/wiki/Road_signs_in_the_United_States#/media/File:United_States_sign_-_Slow_(old).svg
/*
        GlideApp.with(mContext)
                .load(mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL)
                        .compareTo("EMPTYSTRINGVALUE") ==0 ?
                        "https://upload.wikimedia.org/wikipedia/commons/7/7e/OS_X_10.11_Beta_Beach_Ball.jpg" :
                        mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL)
                )
                .placeholder(R.drawable.ic_tmp_icon)
                .fitCenter()
                .into(latestNewsPaginationAdapterViewHolder.itemthumbnailView);
*/
        if (mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL)
                .compareTo("EMPTYSTRINGVALUE") ==0) {
            latestNewsPaginationAdapterViewHolder.itemthumbnailView.setImageResource(R.drawable.ic_logo_hourglass_question);
        } else {
            GlideApp.with(mContext)
                    .load(mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL) )
                    .placeholder(R.drawable.ic_tmp_icon)
                    .fitCenter()
                    .into(latestNewsPaginationAdapterViewHolder.itemthumbnailView);
        }
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setOnClickListener(mcallDetailActivity);
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        latestNewsPaginationAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


        int pagination_firstsubdomainid = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FIRSTSUBDOMAINTABLE_ID);
        ArrayList<String> sourceIconURLChiName = SourceInfo.getInstance()
                .getSourceIconURLAndName(pagination_firstsubdomainid);

        GlideApp.with(mContext)
                .load(sourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                .placeholder(R.drawable.ic_tmp_icon)
                .fitCenter()
                .into(latestNewsPaginationAdapterViewHolder.newsourceiconView);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setOnClickListener(mcallDetailActivity);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        latestNewsPaginationAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


        LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 2 ");


        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setText(sourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setOnClickListener(mcallDetailActivity);
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        latestNewsPaginationAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);




        int bookmarkalready = 0 ;
        if (mCursor.isNull(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_BOOKMARKALREADY) != true) {
            bookmarkalready = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_BOOKMARKALREADY);
        }
        int readalready = 0 ;
        if (mCursor.isNull(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_READALREADY) != true) {
            readalready = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_READALREADY);
        }

        int bookmarkalready_inmap = 0;
        int readalready_inmap = 0;
        int bitvalBookRead = 0;

        if (mSignalMap.containsKey(articlePrimaryID) ){
            bitvalBookRead = mSignalMap.get(articlePrimaryID);
            bookmarkalready_inmap = bitvalBookRead & BOOKMARKALREADY_MASK;
            readalready_inmap = bitvalBookRead & READALREADY_MASK;
        } else {
            mSignalMap.put(articlePrimaryID, bookmarkalready | readalready);
        }

        if (   (bookmarkalready != 0)
                    ||(bookmarkalready_inmap != 0)){
            latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setSelected(true);
        } else {
            //  (bookmarkalready == 0) && (bookmarkalready_inmap == 0) or else
                latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setSelected(false);
        }
        if (   (readalready != 0)
                ||(readalready_inmap != 0)){
            latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setBackgroundResource(R.color.after_reading_color);
            latestNewsPaginationAdapterViewHolder.ib_shareButton.setBackgroundResource(R.color.after_reading_color);
            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setBackgroundResource(R.color.after_reading_color);
            ((ViewGroup)latestNewsPaginationAdapterViewHolder.ib_expandlessButton.getParent()).setBackgroundResource(R.color.after_reading_color);
        } else {
            //use default background
            //  (readalready == 0) && (readalready_inmap == 0) or else
            // latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setSelected(false);
            latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setBackgroundResource(0);
            latestNewsPaginationAdapterViewHolder.ib_shareButton.setBackgroundResource(0);
            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setBackgroundResource(0);
            ((ViewGroup)latestNewsPaginationAdapterViewHolder.ib_expandlessButton.getParent()).setBackgroundResource(0);
        }

        LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 3 ");

        latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setOnClickListener(mbookmarkClickListener);
        latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);

        /*
        latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int bookmarkalready_inmap = 0;
                int bitvalBookRead = 0;
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;

                LogUtil.debug(TAG, " ib_bookmarkButton onclick 1");
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, articlePrimaryID);

                if (view.isSelected() == false){
                    view.setSelected(true);

                    if (mSignalMap.containsKey(articlePrimaryID) ){
                        bitvalBookRead = mSignalMap.get(articlePrimaryID);
                    }
                    bookmarkalready_inmap = bitvalBookRead | BOOKMARKALREADY_MASK;
                    mSignalMap.put(articlePrimaryID, bookmarkalready_inmap);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 1);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 2 = bitvalBookRead"
                            + bitvalBookRead
                            +", bookmarkalready_inmap="
                            + bookmarkalready_inmap);


                } else {
                    //set it off
                    view.setSelected(false);

                    if (mSignalMap.containsKey(articlePrimaryID) ){
                        bitvalBookRead = mSignalMap.get(articlePrimaryID);
                    }
                    bookmarkalready_inmap = bitvalBookRead & ~BOOKMARKALREADY_MASK;
                    mSignalMap.put(articlePrimaryID, bookmarkalready_inmap);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 0);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 3 = bitvalBookRead"
                            + bitvalBookRead
                            +", bookmarkalready_inmap="
                            + bookmarkalready_inmap);
                }
                mContext.getContentResolver().insert(
                        uri,
                        contentValues);
            }
        });
        */

        final String primarytitle = mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TITLE);

        latestNewsPaginationAdapterViewHolder.ib_shareButton.setOnClickListener(mshareClickListener);
        latestNewsPaginationAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        latestNewsPaginationAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        latestNewsPaginationAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_TITLE, primarytitle);


        /*                                                                        }
        latestNewsPaginationAdapterViewHolder.ib_shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LogUtil.debug(TAG, " ib_sharebutton 1");

                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = primarytitle + "\n" + finalurl;
                String shareSub = primarytitle;
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                mContext.startActivity(Intent.createChooser(sharingIntent, "Share using"));
                LogUtil.debug(TAG, " ib_sharebutton 2");

            }
        });
        */

        LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 4 ");

        latestNewsPaginationAdapterViewHolder.primarytitleView.setText(primarytitle);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setOnClickListener(mcallDetailActivity);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        latestNewsPaginationAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);



        int timestampondoc = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TIMESTAMPONDOC);
        String timestampondocTranslatedString = GongTimeUtil.getDisplayTimeStringFromData((long)timestampondoc, mContext);
        latestNewsPaginationAdapterViewHolder.tv_dateView.setText(timestampondocTranslatedString);
        //latestNewsPaginationAdapterViewHolder.tv_dateView.setOnClickListener(mcallDetailActivity);
        latestNewsPaginationAdapterViewHolder.tv_dateView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        latestNewsPaginationAdapterViewHolder.tv_dateView.setTag(R.string.VIEWTAG_FINALURL, finalurl);


        int similiaritiescount = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_SIMILARITIESCOUNT);


        int expandalready_inmap = 0;
        int checkbitval = 0;

        if (mSignalMap.containsKey(articlePrimaryID) ){
            checkbitval = mSignalMap.get(articlePrimaryID);
            expandalready_inmap = checkbitval & EXPANDALREADY_MASK;
        }
        if (expandalready_inmap != 0){
//            ((ConstraintLayout) latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.getParent()).setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.ll_expandlistitem.setVisibility(View.VISIBLE);
            //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setActivated(true);
            //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setImageResource(R.drawable.ic_expand_less_black);
            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.animate().rotation(180).setDuration(300).start();

        } else {
//            ((ConstraintLayout) latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.getParent()).setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.ll_expandlistitem.setVisibility(View.GONE);
            //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setActivated(false);
            //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setImageResource(R.drawable.ic_expand_more_black);
            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.animate().rotation(0).setDuration(300).start();

        }

        LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 5 similiaritiescount= "+ similiaritiescount);
        if ( ( !mUsingSelectedArchivetoDisplay) && (similiaritiescount > 0) ){
            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    LinearLayout expandView = ( (LinearLayout) ((ConstraintLayout)view.getParent()).getParent())
                            .findViewById(R.id.expandlistitem);

                    if (expandView.getVisibility() == View.VISIBLE){
                        int expandalready_inmap = 0;
                        int checkbitval = 0;
                        if (mSignalMap.containsKey(articlePrimaryID) ){
                            checkbitval = mSignalMap.get(articlePrimaryID);
                        }
                        expandalready_inmap = checkbitval & ~EXPANDALREADY_MASK;
                        mSignalMap.put(articlePrimaryID, expandalready_inmap);

                        expandView.setVisibility(View.GONE);
                        view.animate().rotation(0).setDuration(300).start();
                        final View passInView = view;
                        view.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //((ImageButton)passInView).setImageResource(R.drawable.ic_expand_more_black);
                                //passInView.setActivated(false);
                            }
                        }, 350);
                    } else {
                        int expandalready_inmap = 0;
                        int checkbitval = 0;
                        if (mSignalMap.containsKey(articlePrimaryID) ){
                            checkbitval = mSignalMap.get(articlePrimaryID);
                        }
                        expandalready_inmap = checkbitval | EXPANDALREADY_MASK;
                        mSignalMap.put(articlePrimaryID, expandalready_inmap);

                        expandView.setVisibility(View.VISIBLE);
                        view.animate().rotation(180).setDuration(300).start();
                        final View passInView = view;
                        view.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //((ImageButton)passInView).setImageResource(R.drawable.ic_expand_more_black);
                                //((ImageButton)passInView).setImageResource(R.drawable.ic_bookmark_black);
                                //passInView.setActivated(true);
                            }
                        }, 350);
                    }
                }
            });


            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setVisibility(View.VISIBLE);
            if ( latestNewsPaginationAdapterViewHolder.ll_expandlistitem.getVisibility() == View.VISIBLE ){
                LogUtil.debug(TAG, "ll_expandlistitem --- > view.visible articleprimaryid=" + articlePrimaryID);
                //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setActivated(true);
                //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setImageResource(R.drawable.ic_expand_less_black);
                latestNewsPaginationAdapterViewHolder.ib_expandlessButton.animate().rotation(180).setDuration(300).start();

            } else if ( latestNewsPaginationAdapterViewHolder.ll_expandlistitem.getVisibility() == View.GONE ){
                LogUtil.debug(TAG, "ll_expandlistitem --- > view.gone articleprimaryid=" + articlePrimaryID);
                //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setActivated(false);
                //latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setImageResource(R.drawable.ic_expand_more_black);
                latestNewsPaginationAdapterViewHolder.ib_expandlessButton.animate().rotation(0).setDuration(300).start();
            }
            latestNewsPaginationAdapterViewHolder.v_dividerview1.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.v_dividerview3.setVisibility(View.VISIBLE);


            latestNewsPaginationAdapterViewHolder.ib_lessbuttonButton.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.ib_lessbuttonButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    LinearLayout expandView = ((LinearLayout) ((ConstraintLayout) view.getParent()).getParent())
                            .findViewById(R.id.expandlistitem);

                    expandView.setVisibility(View.GONE);
                    ImageButton imageButton = ((LinearLayout) ((LinearLayout) ((ConstraintLayout) view.getParent()).getParent()).getParent())
                            .findViewById(R.id.ib_expandless);
                    imageButton.animate().rotation(0).setDuration(300).start();

                    //imageButton.setImageResource(R.drawable.ic_expand_more_black);
                }
            });





            String entryJSONString = mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_ENTRY);
            LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 6 ");

            int count_similiaritiescount = 0;
            List<ArticleInfo> articlelists = new ArrayList<ArticleInfo>();
            List<ArticleInfo> resultList = new ArrayList<ArticleInfo>();
            try {
                JSONTokener tokener = new JSONTokener(entryJSONString);
                LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 7 ");

                while (tokener.more()) {
                    LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 8 ");

                    JSONObject entryobj = (JSONObject) tokener.nextValue();
                    String timenid = "";

                    Iterator<String> iterator = entryobj.keys();
                    if (entryobj.names().length() > 0) {
                        //for (String timenid : entryobj.keys()) {
                        while (iterator.hasNext()) {
                            // it should have only one?
                            timenid = iterator.next();
                            LogUtil.debug(TAG, " timenid = " + timenid);

                            int timestampondoc_timenid = Integer.valueOf(LatestNewsPaginationContract.
                                    PaginationEntry.decodeGetTimestampondoc(timenid));
                            int articleid_timenid = Integer.valueOf(LatestNewsPaginationContract.
                                    PaginationEntry.decodeGetId(timenid));

                            JSONObject entryobj_underneath = (JSONObject) entryobj.get(timenid);

                            int firstsubdomaintable_id = (int) entryobj_underneath.getLong(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID);
                            String title = entryobj_underneath.getString(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE);

                            String imageurl = entryobj_underneath.getString(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL);

                            String finalurl_underneath = entryobj_underneath.getString(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL);
                            LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 9 timestampondoc_timenid= " +
                                    " articleid_timenid=" + articleid_timenid + " firstsubdomaintable_id=" + firstsubdomaintable_id + " title=" + title +
                                    " imageurl=" + imageurl + " finalurl=" + finalurl);

                            articlelists.add(new ArticleInfo(firstsubdomaintable_id,
                                    title,
                                    imageurl,
                                    articleid_timenid,
                                    finalurl_underneath,
                                    timestampondoc_timenid));

                            count_similiaritiescount++;

                        }
                    }
                }
                LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 10 ");

                resultList = ArticleInfo.sortByPreferredDomain(articlelists,
                        GongPreference.getPreferredlist(mContext));

            } catch (JSONException e) {
                e.printStackTrace();
            }

            ArticleInfo artInfo = resultList.get(0);
            LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 11 ");

            latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.setText(artInfo.getTitle());
//            latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.setOnClickListener(mcallDetailActivity);
//            latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//            latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());


            ArrayList<String> oneSourceIconURLChiName = SourceInfo.getInstance()
                    .getSourceIconURLAndName(artInfo.getFirstsubdomaintable_id());

            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView.setVisibility(View.VISIBLE);
            GlideApp.with(mContext)
                    .load(oneSourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                    .placeholder(R.drawable.ic_tmp_icon)
                    .fitCenter()
                    .into(latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView);
            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView.setVisibility(View.VISIBLE);
//            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView.setOnClickListener(mcallDetailActivity);
//            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());

            LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 12 ");

            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandoneView.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandoneView.setText(
                    oneSourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));
//            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandoneView.setOnClickListener(mcallDetailActivity);
//            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandoneView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandoneView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());


            String timeString = GongTimeUtil.getDisplayTimeStringFromData((long) artInfo.getTimestampondoc(), mContext);
            latestNewsPaginationAdapterViewHolder.tv_dateexpandoneView.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.tv_dateexpandoneView.setText(timeString);
//            latestNewsPaginationAdapterViewHolder.tv_dateexpandoneView.setOnClickListener(mcallDetailActivity);
//            latestNewsPaginationAdapterViewHolder.tv_dateexpandoneView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//            latestNewsPaginationAdapterViewHolder.tv_dateexpandoneView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());

            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setOnClickListener(mcallDetailActivity);
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.article_list_item_one_expand_layout);
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark1);
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share1);
            latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID, R.id.article_list_item_one_sb_expand_layout);


            latestNewsPaginationAdapterViewHolder.ll_article_one_sb_expand.setVisibility(View.VISIBLE);
            latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton1.setOnClickListener(mbookmarkClickListener);
            latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton1.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());

            bookmarkalready_inmap = 0;
            readalready_inmap = 0;
            bitvalBookRead = 0;

            if (mInitupdateSignalMapFromCursor) {
                if (mSignalMap.containsKey(artInfo.getID())) {
                    bitvalBookRead = mSignalMap.get(artInfo.getID());
                    bookmarkalready_inmap = bitvalBookRead & BOOKMARKALREADY_MASK;
                    readalready_inmap = bitvalBookRead & READALREADY_MASK;
                }

                if (bookmarkalready_inmap == 0) {
                    latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton1.setSelected(false);
                } else {
                    latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton1.setSelected(true);
                }
                if (   readalready_inmap != 0) {
                    latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton1.setBackgroundResource(R.color.after_reading_color);
                    latestNewsPaginationAdapterViewHolder.ib_sharebutton1.setBackgroundResource(R.color.after_reading_color);
                    latestNewsPaginationAdapterViewHolder.ll_article_one_sb_expand.setBackgroundResource(R.color.after_reading_color);
                    latestNewsPaginationAdapterViewHolder.article_list_item_one_expand_layout.setBackgroundResource(R.color.after_reading_color);
                }

            }

            latestNewsPaginationAdapterViewHolder.ib_sharebutton1.setOnClickListener(mshareClickListener);
            latestNewsPaginationAdapterViewHolder.ib_sharebutton1.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
            latestNewsPaginationAdapterViewHolder.ib_sharebutton1.setTag(R.string.VIEWTAG_TITLE, artInfo.getTitle());


            if (similiaritiescount == 1) {
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setVisibility(View.GONE);
                latestNewsPaginationAdapterViewHolder.ll_article_two_sb_expand.setVisibility(View.GONE);
                latestNewsPaginationAdapterViewHolder.tv_expandtextView.setVisibility(View.GONE);

//                latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setVisibility(View.GONE);
//                latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.GONE);
//                latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setVisibility(View.GONE);
//                latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setVisibility(View.GONE);

//                latestNewsPaginationAdapterViewHolder.v_dividerview2.setVisibility(View.GONE);
                LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 13 ");

            } else {

                artInfo = resultList.get(1);

                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setVisibility(View.VISIBLE);
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setOnClickListener(mcallDetailActivity);
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.article_list_item_two_expand_layout);
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark2);
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share2);
                latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID, R.id.article_list_item_two_sb_expand_layout);

                latestNewsPaginationAdapterViewHolder.ll_article_two_sb_expand.setVisibility(View.VISIBLE);


                latestNewsPaginationAdapterViewHolder.v_dividerview2.setVisibility(View.VISIBLE);


                latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setVisibility(View.VISIBLE);
                latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setText(artInfo.getTitle());
//                latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setOnClickListener(mcallDetailActivity);
//                latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//                latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());

                LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 14 ");

                ArrayList<String> twoSourceIconURLChiName = SourceInfo.getInstance()
                        .getSourceIconURLAndName(artInfo.getFirstsubdomaintable_id());

                latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.VISIBLE);
                GlideApp.with(mContext)
                        .load(twoSourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                        .placeholder(R.drawable.ic_tmp_icon)
                        .fitCenter()
                        .into(latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView);
                latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.VISIBLE);
//                latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setOnClickListener(mcallDetailActivity);
//                latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//                latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());


                latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setVisibility(View.VISIBLE);
                latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setText(
                        twoSourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));
//                latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setOnClickListener(mcallDetailActivity);
//                latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//                latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());


                timeString = GongTimeUtil.getDisplayTimeStringFromData((long) artInfo.getTimestampondoc(), mContext);
                latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setVisibility(View.VISIBLE);
                latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setText(timeString);
//                latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setOnClickListener(mcallDetailActivity);
//                latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
//                latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());

                latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton2.setOnClickListener(mbookmarkClickListener);
                latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton2.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
                bookmarkalready_inmap = 0;
                readalready_inmap = 0;
                bitvalBookRead = 0;

                if (mInitupdateSignalMapFromCursor) {
                    if (mSignalMap.containsKey(artInfo.getID())) {
                        bitvalBookRead = mSignalMap.get(artInfo.getID());
                        bookmarkalready_inmap = bitvalBookRead & BOOKMARKALREADY_MASK;
                        readalready_inmap = bitvalBookRead & READALREADY_MASK;
                    }

                    if (bookmarkalready_inmap == 0) {
                        latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton2.setSelected(false);
                    } else {
                        latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton2.setSelected(true);
                    }
                    if (   readalready_inmap != 0) {
                        latestNewsPaginationAdapterViewHolder.ib_bookmarkbutton2.setBackgroundResource(R.color.after_reading_color);
                        latestNewsPaginationAdapterViewHolder.ib_sharebutton2.setBackgroundResource(R.color.after_reading_color);
                        latestNewsPaginationAdapterViewHolder.ll_article_two_sb_expand.setBackgroundResource(R.color.after_reading_color);
                        latestNewsPaginationAdapterViewHolder.article_list_item_two_expand_layout.setBackgroundResource(R.color.after_reading_color);
                    }

                }

                latestNewsPaginationAdapterViewHolder.ib_sharebutton2.setOnClickListener(mshareClickListener);
                latestNewsPaginationAdapterViewHolder.ib_sharebutton2.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
                latestNewsPaginationAdapterViewHolder.ib_sharebutton2.setTag(R.string.VIEWTAG_TITLE, artInfo.getTitle());



                if (similiaritiescount <= 2){
                    latestNewsPaginationAdapterViewHolder.tv_expandtextView.setVisibility(View.GONE);

                } else {
                    latestNewsPaginationAdapterViewHolder.tv_expandtextView.setVisibility(View.VISIBLE);
                    ArticleInfo currentArticleInfo = new ArticleInfo(
                            mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FIRSTSUBDOMAINTABLE_ID),
                            mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TITLE),
                            mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL),
                            mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_ARTICLE_ID),
                            mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FINALURL),
                            mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TIMESTAMPONDOC)
                    );
                    resultList.add(0, currentArticleInfo);

                    //create JSON string and tag it
                    JSONArray resultJSONArray = new JSONArray();
                    int [] bookmarkreadarray = new int[resultList.size()];
                    int index=0;

                    for (ArticleInfo article : resultList) {
                        try {

                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_ARTICLEID,
                                    article.getID());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                                    article.getFirstsubdomaintable_id());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE,
                                    article.getTitle());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL,
                                    article.getFinalurl());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL,
                                    article.getImageurl());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC,
                                    article.getTimestampondoc());
                            jsonObject.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY,
                                    (long) (mSignalMap.containsKey(article.getID()) ? mSignalMap.get(articlePrimaryID) : 0));

                            resultJSONArray.put(jsonObject);

                            bookmarkreadarray[index++] = article.getID();
                            LogUtil.debug(TAG, " currentarticleinfo.id = " + currentArticleInfo.getID() +",article.getID=" + article.getID());

                        } catch (Exception e) {
                            LogUtil.debug(TAG, "creating moredetailist ");
                        }
                    }
                    String resultStringresultJSONArray = resultJSONArray.toString();
                    latestNewsPaginationAdapterViewHolder.tv_expandtextView.
                            setTag(R.string.VIEWTAG_EXPANDTEXT_JSON_STRING, resultStringresultJSONArray);
                    latestNewsPaginationAdapterViewHolder.tv_expandtextView.
                            setTag(R.string.VIEWTAG_EXPANDTEXT_JSON_BOOKMARK_STRING, bookmarkreadarray);
                    latestNewsPaginationAdapterViewHolder.tv_expandtextView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String jsonArticleString = (String) view.getTag(R.string.VIEWTAG_EXPANDTEXT_JSON_STRING);
                            int [] signalmaparray = (int[]) view.getTag(R.string.VIEWTAG_EXPANDTEXT_JSON_BOOKMARK_STRING);
                            JSONArray bookmarkJSONArray = new JSONArray();

                            if (signalmaparray.length > 0) {
                                for (int x : signalmaparray) {
                                    try {
                                        if (   ( mSignalMap.containsKey(x) )
                                            &&(mSignalMap.get(x) != 0) ){
                                            JSONObject jsonObject = new JSONObject();
                                            jsonObject.put(String.valueOf(x), mSignalMap.get(x));
                                            bookmarkJSONArray.put(jsonObject);

                                        }
                                    } catch (Exception e) {
                                        LogUtil.debug(TAG, " onclick  tv_expandtextView ");
                                    }
                                }
                                LogUtil.debug(TAG, " onclick  tv_expandtextView jsonarticlestring=" + jsonArticleString
                                + ",       bookarmkjsonarray.tostring=" + bookmarkJSONArray.toString());
                                mClickHandler.onClickExpandNews(jsonArticleString, bookmarkJSONArray.toString());
                            } else {
                                LogUtil.debug(TAG, " onclick  tv_expandtextView ERROR bookmarkarray.length=" + signalmaparray.length);
                            }

                        }
                    });

                }

                LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 15 ");


            }

            LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 16 ");

        } else {

            latestNewsPaginationAdapterViewHolder.ib_expandlessButton.setVisibility(View.INVISIBLE);

            latestNewsPaginationAdapterViewHolder.tv_titleexpandoneView.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandoneView.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandoneView.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.tv_dateexpandoneView.setVisibility(View.GONE);

            latestNewsPaginationAdapterViewHolder.tv_titleexpandtwoView.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.tv_domainsourceexpandtwoView.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.tv_dateexpandtwoView.setVisibility(View.GONE);

            latestNewsPaginationAdapterViewHolder.ib_lessbuttonButton.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.tv_expandtextView.setVisibility(View.GONE);

            latestNewsPaginationAdapterViewHolder.v_dividerview1.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.v_dividerview2.setVisibility(View.GONE);
            latestNewsPaginationAdapterViewHolder.v_dividerview3.setVisibility(View.GONE);
            LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 17 ");

        }

        LogUtil.debug(TAG, " LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder onBindViewHolder 18 ");

    }


    /**
     * This method simply returns the number of items to display. It is used behind the scenes
     * to help layout our Views and for animations.
     *
     * @return The number of items available in our forecast
     */
    @Override
    public int getItemCount() {
        LogUtil.debug(TAG, " LatestNewsPaginationAdapter getitemcount 1 ");

        if (null == mCursor) return 0;
        LogUtil.debug(TAG, " LatestNewsPaginationAdapter getitemcount 2 getcount="+ mCursor.getCount());
        return mCursor.getCount();
    }

    /**
     * Returns an integer code related to the type of View we want the ViewHolder to be at a given
     * position. This method is useful when we want to use different layouts for different items
     * depending on their position. In Sunshine, we take advantage of this method to provide a
     * different layout for the "today" layout. The "today" layout is only shown in portrait mode
     * with the first item in the list.
     *
     * @param position index within our RecyclerView and Cursor
     * @return the view type (today or future day)
     */
    @Override
    public int getItemViewType(int position) {
        //return -1;
        return 0;
    }

    /**
     * Swaps the cursor used by the ForecastAdapter for its weather data. This method is called by
     * MainActivity after a load has finished, as well as when the Loader responsible for loading
     * the weather data is reset. When this method is called, we assume we have a completely new
     * set of data, so we call notifyDataSetChanged to tell the RecyclerView to update.
     *
     * @param newCursor the new cursor to use as ForecastAdapter's data source
     */
    void swapCursor(Cursor newCursor, boolean usingSelectedArchivetoDisplay ) {
        LogUtil.debug(TAG, " LatestNewsPaginationAdapter swapcursor  ");

        mUsingSelectedArchivetoDisplay = usingSelectedArchivetoDisplay;
        mCursor = newCursor;
        if (mCursor != null) {
            LogUtil.debug(TAG, " LatestNewsPaginationAdapter swapcursor  getcount=" + mCursor.getCount());
        }
        notifyDataSetChanged();
    }


    void updateSignalMapFromCursor(Cursor newCursor) {
        LogUtil.debug(TAG, " LatestNewsPaginationAdapter  updateSignalMapFromCursor  ");

        if (newCursor!= null) {
                LogUtil.debug(TAG, " LatestNewsPaginationAdapter  updateSignalMapFromCursor  getcount=" + newCursor.getCount());
                for (int index = 0; index < newCursor.getCount(); index++) {
                    newCursor.moveToPosition(index);
                    int articleID = newCursor.getInt(SignalContract.INDEX_ARTICLE_ID);
                    int bookmarkalreadyFromCursor = newCursor.getInt(SignalContract.INDEX_BOOKMARKALREADY);
                    int readalreadyFromCursor = newCursor.getInt(SignalContract.INDEX_READALREADY);
                    int bitvalBookRead = 0;
                    if (mSignalMap.containsKey(articleID)) {
                        bitvalBookRead = mSignalMap.get(articleID);
                    }
                    if (bookmarkalreadyFromCursor == 0) {
                        bitvalBookRead = bitvalBookRead & ~BOOKMARKALREADY_MASK;
                    } else {
                        bitvalBookRead = bitvalBookRead | BOOKMARKALREADY_MASK;
                    }
                    if (readalreadyFromCursor == 0) {
                        bitvalBookRead = bitvalBookRead & ~READALREADY_MASK;
                    } else {
                        bitvalBookRead = bitvalBookRead | READALREADY_MASK;

                    }
                    mSignalMap.put(articleID, bitvalBookRead);

                }

                mInitupdateSignalMapFromCursor=true;

        }
    }


    /**
     * A ViewHolder is a required part of the pattern for RecyclerViews. It mostly behaves as
     * a cache of the child views for a forecast item. It's also a convenient place to set an
     * OnClickListener, since it has access to the adapter and the views.
     */
    class LatestNewsPaginationAdapterViewHolder extends RecyclerView.ViewHolder  {
        private final String TAG = LatestNewsPaginationAdapter.LatestNewsPaginationAdapterViewHolder.class.getSimpleName();

        //the whole view of item
        //final View articleindlistitem;

        //article_list_item_primary.xml
        final ImageView itemthumbnailView;
        final ImageView newsourceiconView;
        final ImageButton ib_bookmarkButton;
        final ImageButton ib_expandlessButton;
        final ImageButton ib_shareButton;
        final TextView tv_domainsourceView;
        final TextView tv_dateView;
        final TextView primarytitleView;


        final LinearLayout ll_expandlistitem;
        //article_list_item_expand.xml
        final ConstraintLayout article_list_item_one_expand_layout;
        final TextView tv_titleexpandoneView;
        final ImageView iv_sourceiconexpandoneView;
        final TextView tv_domainsourceexpandoneView;
        final TextView tv_dateexpandoneView;
        final LinearLayout ll_article_one_sb_expand;
        final ImageButton ib_sharebutton1;
        final ImageButton ib_bookmarkbutton1;


        final ConstraintLayout article_list_item_two_expand_layout;
        final TextView tv_titleexpandtwoView;
        final ImageView iv_sourceiconexpandtwoView;
        final TextView tv_domainsourceexpandtwoView;
        final TextView tv_dateexpandtwoView;
        final LinearLayout ll_article_two_sb_expand;
        final ImageButton ib_sharebutton2;
        final ImageButton ib_bookmarkbutton2;


        final ConstraintLayout article_list_item_more_expand_layout;
        final ImageButton ib_lessbuttonButton;
        final TextView tv_expandtextView;
        final View v_dividerview1;
        final View v_dividerview2;
        final View v_dividerview3;



        LatestNewsPaginationAdapterViewHolder(View view) {
            super(view);


            itemthumbnailView = (ImageView) view.findViewById(R.id.itemthumbnail);
            newsourceiconView = (ImageView) view.findViewById(R.id.newsourceicon);
            ib_bookmarkButton = (ImageButton) view.findViewById(R.id.ib_bookmark);
            ib_expandlessButton = (ImageButton) view.findViewById(R.id.ib_expandless);
            ib_shareButton = (ImageButton) view.findViewById(R.id.ib_share);
            tv_domainsourceView = (TextView) view.findViewById(R.id.tv_domainsource);
            tv_dateView = (TextView) view.findViewById(R.id.tv_date);
            primarytitleView = (TextView) view.findViewById(R.id.primarytitle);

            ll_expandlistitem = (LinearLayout) view.findViewById(R.id.expandlistitem);
            article_list_item_one_expand_layout = (ConstraintLayout) view.findViewById(R.id.article_list_item_one_expand_layout);
            tv_titleexpandoneView = (TextView) view.findViewById(R.id.tv_titleexpandone);
            iv_sourceiconexpandoneView = (ImageView) view.findViewById(R.id.iv_sourceiconexpandone);
            tv_domainsourceexpandoneView = (TextView) view.findViewById(R.id.tv_domainsourceexpandone);
            tv_dateexpandoneView = (TextView) view.findViewById(R.id.tv_dateexpandone);
            ll_article_one_sb_expand = (LinearLayout) view.findViewById(R.id.article_list_item_one_sb_expand_layout);
            ib_bookmarkbutton1 = (ImageButton) view.findViewById(R.id.ib_bookmark1);
            ib_sharebutton1 = (ImageButton) view.findViewById(R.id.ib_share1);


            article_list_item_two_expand_layout = (ConstraintLayout) view.findViewById(R.id.article_list_item_two_expand_layout);
            tv_titleexpandtwoView = (TextView) view.findViewById(R.id.tv_titleexpandtwo);
            iv_sourceiconexpandtwoView = (ImageView) view.findViewById(R.id.iv_sourceiconexpandtwo);
            tv_domainsourceexpandtwoView = (TextView) view.findViewById(R.id.tv_domainsourceexpandtwo);
            tv_dateexpandtwoView = (TextView) view.findViewById(R.id.tv_dateexpandtwo);
            ll_article_two_sb_expand = (LinearLayout) view.findViewById(R.id.article_list_item_two_sb_expand_layout);
            ib_bookmarkbutton2 = (ImageButton) view.findViewById(R.id.ib_bookmark2);
            ib_sharebutton2 = (ImageButton) view.findViewById(R.id.ib_share2);


            article_list_item_more_expand_layout = (ConstraintLayout) view.findViewById(R.id.article_list_item_more_expand_layout);
            ib_lessbuttonButton = (ImageButton) view.findViewById(R.id.ib_lessbutton);
            tv_expandtextView = (TextView) view.findViewById(R.id.tv_expandtext);

            v_dividerview1 = (View) view.findViewById(R.id.dividerview1);
            v_dividerview2 = (View) view.findViewById(R.id.dividerview2);
            v_dividerview3 = (View) view.findViewById(R.id.dividerview3);

            LogUtil.debug(TAG, " LatestNewsPaginationAdapterViewHolder constructor 1");


        }


    }

}

