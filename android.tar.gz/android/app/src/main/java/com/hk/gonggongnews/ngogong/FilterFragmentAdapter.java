package com.hk.gonggongnews.ngogong;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.preference.PreferenceManager;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hk.gonggongnews.ngogong.data.SourceInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 11/15/2017.
 */

public class FilterFragmentAdapter extends  RecyclerView.Adapter<FilterFragmentAdapter.FilterRowViewHolder> {


    public interface ListChanged {
        public void  setCurrentPreferredSourceList(List<Integer> preferredList);
    }

    private final Context mContext;
    private Map<Integer, Integer> mFSDSelectedMap;
    private List<FSDCatgeoryInfo> mCurrentSourceToDisplay;

    private int mCurrentCategory;
    private final String TAG = FilterFragmentAdapter.class.getSimpleName();

    private FilterFragmentAdapter.ListChanged mFragmentListChanged;

    public FilterFragmentAdapter (Context context,
                                  FilterFragmentAdapter.ListChanged listchanged) {
        mContext = context;
        mFragmentListChanged = listchanged;
        mFSDSelectedMap = new HashMap<>();
        mCurrentSourceToDisplay = new ArrayList<>();


    }



    @Override
    public FilterRowViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        int layoutId;
        View view;

        layoutId = R.layout.list_item_filter_drawer;
        view = LayoutInflater.from(mContext).inflate(layoutId, parent, false);

        view.setFocusable(true);
        LogUtil.debug(TAG, "FilterRowViewHolder onCreateViewHolder");

        return new FilterRowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(FilterRowViewHolder holder, int position) {

        LogUtil.debug(TAG, " onBindViewHolder 1 position=" + position);
        GlideApp.with(mContext)
                .load(mCurrentSourceToDisplay.get(position).getIconURL())
                .placeholder(R.drawable.ic_tmp_icon)
                .fitCenter()
                .into(holder.iv_sourceiconfilter);
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(mContext);
        String  choiceOfLang = sp.getString(mContext.getString(R.string.gong_lang_pref), mContext.getString(R.string.choice_value_lang_eng));
        if (choiceOfLang.compareTo(mContext.getString(R.string.choice_value_lang_eng)) == 0){
            holder.tv_domainsourcefilter.setText(mCurrentSourceToDisplay.get(position).getEngName());
        } else {
            holder.tv_domainsourcefilter.setText(mCurrentSourceToDisplay.get(position).getChiName());
        }

        //holder.listItemRowLayout.setOnClickListener(v -> );

        holder.cb_filter_checkbox.setTag(R.string.VIEWTAG_FIRSTSUBDOMAIN_NUM, mCurrentSourceToDisplay.get(position).getFirstSubDomainID());
        holder.cb_filter_checkbox.setOnClickListener(v ->
        {
            boolean checked = ((CheckBox) v).isChecked();
            List<Integer> resultList = new ArrayList<>();
            if (checked) {
                mFSDSelectedMap.put((int) v.getTag(R.string.VIEWTAG_FIRSTSUBDOMAIN_NUM), 1);
            } else {
                mFSDSelectedMap.put((int) v.getTag(R.string.VIEWTAG_FIRSTSUBDOMAIN_NUM), 0);
            }
            for (Map.Entry<Integer, Integer> entry : mFSDSelectedMap.entrySet()){
                if (entry.getValue() == 1){
                    resultList.add(entry.getKey());
                }
            }
            mFragmentListChanged.setCurrentPreferredSourceList(resultList);

        });
        holder.cb_filter_checkbox.setChecked(
                mFSDSelectedMap.get(mCurrentSourceToDisplay.get(position).getFirstSubDomainID()) == 1
                        ? true : false);

    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        LogUtil.debug(TAG, "  getitemcount 1 ");

        if (null == mCurrentSourceToDisplay) return 0;
        LogUtil.debug(TAG, "  getitemcount 2 getcount="+ mCurrentSourceToDisplay.size());
        return mCurrentSourceToDisplay.size();
    }




    public void setCurrentCategory(int categoryNum, List<Integer> previousSelectedList) {
        LogUtil.debug(TAG, " setCurrentCategory 1 =" + categoryNum);
        mCurrentCategory = categoryNum;
        mCurrentSourceToDisplay = SourceInfo.getInstance().getFSDListWithCategory(categoryNum);
        mFSDSelectedMap.clear();
        LogUtil.debug(TAG, " setCurrentCategory mCurrentSourceToDisplay.size =" + mCurrentSourceToDisplay.size());

        for (FSDCatgeoryInfo entry : mCurrentSourceToDisplay) {
            LogUtil.debug(TAG, " setCurrentCategory entry.FSDID ="
                    + entry.getFirstSubDomainID()
                    + ", chiname=" + entry.getChiName());
            mFSDSelectedMap.put(entry.getFirstSubDomainID(), 0);
        }
        if (previousSelectedList != null) {
            for (int x : previousSelectedList) {
                mFSDSelectedMap.put(x, 1);
            }
        }

        notifyDataSetChanged();
    }

    public class FilterRowViewHolder extends RecyclerView.ViewHolder  {
        private final String TAG = FilterRowViewHolder.class.getSimpleName();

        final LinearLayout listItemRowLayout;
        final ImageView iv_sourceiconfilter;
        final TextView tv_domainsourcefilter;
        final CheckBox cb_filter_checkbox;




        FilterRowViewHolder(View view) {
            super(view);

            listItemRowLayout = (LinearLayout) view.findViewById(R.id.listItemRowLayout);
            iv_sourceiconfilter = (ImageView) view.findViewById(R.id.iv_sourceiconfilter);
            tv_domainsourcefilter = (TextView) view.findViewById(R.id.tv_domainsourcefilter) ;
            cb_filter_checkbox = (CheckBox) view.findViewById(R.id.filter_checkbox);

            LogUtil.debug(TAG, " FilterRowViewHolder constructor 1");


        }


    }

    public static class FSDCatgeoryInfo {
        private int mFirstSubDomain_id;
        private String mChiName;
        private String mEngName;
        private String mSourceIconURL;

        public FSDCatgeoryInfo(int fsd_id, String chiname, String engname, String url){
            mFirstSubDomain_id = fsd_id;
            mChiName = chiname;
            mEngName = engname;
            mSourceIconURL = url;
        }

        public int getFirstSubDomainID(){
            return mFirstSubDomain_id;
        }

        public String getChiName (){
            return mChiName;
        }
        public String getEngName (){
            return mEngName;
        }
        public String getIconURL () {
            return mSourceIconURL;
        }


    }

}
