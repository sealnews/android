package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.FragArticleTableContract.FragArticleEntry.CONTENT_URI;
import static com.hk.gonggongnews.ngogong.data.FragArticleTableContract.FragArticleEntry.CONTENT_URI_CATEGORY;
import static com.hk.gonggongnews.ngogong.data.FragArticleTableContract.FragArticleEntry.CONTENT_URI_FIRSTSUBDOMAIN;
import static com.hk.gonggongnews.ngogong.data.FragArticleTableContract.FragArticleEntry.CONTENT_URI_NAME;

/**
 * Created by ismile on 12/5/2017.
 */

public class FragArticleTableContract {
    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final int INDEX_RAWQUERY_NAME = 13;
    public static final int INDEX_RAWQUERY_CATEGORYTABLE_ID = 14;

    //public static final String RAWQUERY_ORDERSTRING = " order by fragarticle.timestampondocandid DESC , fragarticle.title DESC ";
    public static final String RAWQUERY_ORDERSTRING = " order by fragarticle.timestampondoc DESC, fragarticle.title DESC   ";
    public static final String RAWQUERY_FRAGARTICLE_WHEREIDSTRING = " fragarticle._id >= ? and fragarticle._id <= ? ";
    public static final String RAWQUERY_FRAGARTICLE_WHERENAMESTRING = " fragarticle.name = ? ";
    public static final String RAWQUERY_FRAGARTICLE_WHEREFIRSTSUBSTRING = " fragarticle.firstsubdomaintable_id == ?  ";
    public static final String RAWQUERY_FRAGARTICLE_WHERECATEGORYSTRING = " fragarticle.categorytable_id  = ?  ";
    public static final String RAWQUERY_FRAGARTICLE_SELECTIONSTRING =
            " select fragarticle._id as fragarticle_id, "
                    + " fragarticle.finalurl as fragarticle_finalurl, "
                    + " fragarticle.timestampondoc as fragarticle_timestampondoc, "
                    + " fragarticle.title as fragarticle_title, "
                    + " fragarticle.imageurl as fragarticle_imageurl, "
                    + " fragarticle.similiaritiescount as fragarticle_similaritiescount, "
                    + " fragarticle.entry as fragarticle_entry, "
                    + " fragarticle.firstsubdomaintable_id as fragarticle_firstsubdomaintable_id, "
                    + " fragarticle.timestampondocandid as fragarticle_timestampondocandid, "
                    + " fragarticle.article_id as fragarticle_article_id, "
                    + " signal.bookmarkalready as signal_bookmarkalready, "
                    + " signal.readalready as signal_readalready, "
                    + " firstsubdomain.sourceiconurl as firstsubdomain_sourceiconurl, "
                    + " fragarticle.name as fragarticle_name, "
                    + " fragarticle.categorytable_id as fragarticle_categorytable_id "
                    + " from fragarticle "
                    + " left join firstsubdomain on fragarticle.firstsubdomaintable_id = firstsubdomain.firstsubdomaintable_id "
                    + " left join signal on fragarticle.article_id = signal.article_id ";
    public static final String RAWQUERY_FRAGARTICLE_RANGESTRING = RAWQUERY_FRAGARTICLE_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLE_WHEREIDSTRING
            + RAWQUERY_ORDERSTRING;
    public static final String RAWQUERY_FRAGARTICLE_NAMESTRING = RAWQUERY_FRAGARTICLE_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLE_WHERENAMESTRING
            + RAWQUERY_ORDERSTRING;
    public static final String RAWQUERY_FRAGARTICLE_CATEGORYSTRING = RAWQUERY_FRAGARTICLE_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLE_WHERECATEGORYSTRING
            + RAWQUERY_ORDERSTRING;
    public static final String RAWQUERY_FRAGARTICLE_FIRSTSUBSTRING = RAWQUERY_FRAGARTICLE_SELECTIONSTRING
            + " where " + RAWQUERY_FRAGARTICLE_WHEREFIRSTSUBSTRING
            + RAWQUERY_ORDERSTRING;

    public static final String PATH_FRAGARTICLE = "fragarticle";
    public static final String PATH_NAME = "name";
    public static final String PATH_FIRSTSUBDOMAIN = "firstsubdomain";
    public static final String PATH_CATEGORY = "category";



    public static final class FragArticleEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLE)
                .build();

        public static final Uri CONTENT_URI_NAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLE)
                .appendPath(PATH_NAME)
                .build();

        public static final Uri CONTENT_URI_FIRSTSUBDOMAIN  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLE)
                .appendPath(PATH_FIRSTSUBDOMAIN)
                .build();

        public static final Uri CONTENT_URI_CATEGORY = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_FRAGARTICLE)
                .appendPath(PATH_CATEGORY)
                .build();


        public static final String TABLE_NAME = "fragarticle";

        public static final String COLUMN_TIMESTAMPONDOC_AND_ID = "timestampondocandid";
        public static final String COLUMN_ARTICLEID = "article_id";
        public static final String COLUMN_TIMESTAMPONDOC = "timestampondoc";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_FINALURL = "finalurl";
        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_IMAGEURL = "imageurl";
        public static final String COLUMN_SIMILARITIESCOUNT = "similiaritiescount";
        public static final String COLUMN_ENTRY = "entry";
        public static final String COLUMN_NAME= "name";
        public static final String COLUMN_CATEGORYTABLE_ID = "categorytable_id";

    }

    public static Uri buildPaginationUriWithTimestampondocAndId(String timestampondocandid) {
        return CONTENT_URI.buildUpon()
                .appendPath(timestampondocandid)
                .build();
    }

    public static String decodeGetTimestampondoc(String timestampondocandid) {
        String timestamp = timestampondocandid.split("Z")[0];
        return timestamp;
    }

    public static String decodeGetId(String timestampondocandid) {
        String id = timestampondocandid.split("Z")[1];
        return id;
    }


    public static Uri buildUriWithNamePathAndName ( String name) {
        return CONTENT_URI_NAME.buildUpon()
                .appendPath(name)
                .build();
    }

    public static Uri buildUriWithFSD ( int id) {
        return CONTENT_URI_FIRSTSUBDOMAIN.buildUpon()
                .appendPath(String.valueOf(id))
                .build();
    }

    public static Uri buildUriWithCategory ( int id) {
        return CONTENT_URI_CATEGORY.buildUpon()
                .appendPath(String.valueOf(id))
                .build();
    }




}
