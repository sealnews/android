package com.hk.gonggongnews.ngogong.sync;

/**
 * Created by ismile on 10/20/2017.
 */


import android.app.IntentService;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hk.gonggongnews.ngogong.data.FragLookupTableContract;
import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.util.FragInfo;

public class GongValueEventListener {

    private static final String TAG = GongValueEventListener.class.getSimpleName();

    public static ValueEventListener get_TableValueEventListener(final Context context,
                                                                 final int preferenceid
                                                                 ) {
        return get_TableValueEventListener(context, preferenceid, false);
    }

    public static ValueEventListener get_FragTableValueEventListener(final Context context,
                                                                     final String name) {
        String key;
        ValueEventListener tmpValueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                LogUtil.debug(TAG, "get_FragTableTimeValueEventListener onDataChange name=" + name);
                long lastupdatetime = (Long) ((Map<String, Object>) (dataSnapshot.getValue())).get("lastupdatetime");
                long noofentry = (Long) ((Map<String, Object>) dataSnapshot.getValue()).get("noofentry");
                LogUtil.debug(TAG, "get_FragTableTimeValueEventListener onDataChange name=" + name
                 + ", noofentry=" + noofentry);

                GongPreference.setLastUpdateNoOfEntry(context,
                        (int) noofentry,
                        FragInfo.getInstance().get_noofentrynameremote(name));


                String sheetID;
                String sheeturl;
                ContentValues singleentryvalue;
                List<ContentValues> listContentValues = new ArrayList<>();
                Map<String, Object> sheetentrymap = (Map<String, Object>) (((HashMap<String, Object>) dataSnapshot.getValue())
                        .get("entry"));
                for (Map.Entry<String, Object> indsheetdata : sheetentrymap.entrySet()) {
                    sheetID = indsheetdata.getKey();
                    sheeturl = (String) indsheetdata.getValue();
                    singleentryvalue = new ContentValues();
                    singleentryvalue.put(FragLookupTableContract.FragLookupEntry.COLUMN_NAME, name);
                    singleentryvalue.put(FragLookupTableContract.FragLookupEntry.COLUMN_CATEGORYTABLE_ID,
                            FragInfo.getInstance().get_category(name));
                    singleentryvalue.put(FragLookupTableContract.FragLookupEntry.COLUMN_NOOFENTRY, noofentry);
                    singleentryvalue.put(FragLookupTableContract.FragLookupEntry.COLUMN_LASTUPDATETIME, lastupdatetime);
                    singleentryvalue.put(FragLookupTableContract.FragLookupEntry.COLUMN_SHEETID, sheetID);
                    singleentryvalue.put(FragLookupTableContract.FragLookupEntry.COLUMN_SHEETID_URL, sheeturl);
                    listContentValues.add(singleentryvalue);
                }


                int index = 0;
                ContentValues[] entryContentvalues = new ContentValues[listContentValues.size()];
                for (ContentValues x : listContentValues) {
                    entryContentvalues[index] = listContentValues.get(index);
                    index++;
                }

                LogUtil.debug(TAG, " get_FragTableValueEventListener sizeof(listContentValues)=" + listContentValues.size());

                ContentResolver gongContentResolver = context.getContentResolver();

                                        /* Insert our new weather data into Sunshine's ContentProvider */
                int result = 0;
                result = gongContentResolver.bulkInsert(
                        FragLookupTableContract.buildUriWithNamePathAndName(name),
                        //FragLookupTableContract.FragLookupEntry.CONTENT_URI,
                        entryContentvalues);
                LogUtil.debug(TAG, "get_FragTableValueEventListener ondatachange  DONE INSERT result =" + result);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                LogUtil.debug(TAG, "get_FragTableValueEventListener setLastupdatetime oncancelled");
            }
        };
        if (tmpValueEventListener == null) {
            throw new RuntimeException("get_FragTableValueEventListener setLastupdatetime error null");
        }
        return tmpValueEventListener;

    }

    public static ValueEventListener get_TableValueEventListener(final Context context,
                                                                 final int preferenceid,
                                                                 final boolean copytolocal) {

        String key;
        ValueEventListener tmpValueEventListener;

        if (((preferenceid >= GongPreference.PREFERENCE_LASTUPDATETIME_START)
                && (preferenceid <= GongPreference.PREFERENCE_LASTUPDATETIME_END))
                ||
                ((preferenceid >= GongPreference.PREFERENCE_LASTUPDATETIME_LOCAL_START) &&
                (preferenceid <= GongPreference.PREFERENCE_LASTUPDATETIME_LOCAL_END))) {

            tmpValueEventListener = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    LogUtil.debug(TAG, "get_TableValueEventListener setLastupdatetime onDataChange preferenceid=" + preferenceid);
                    long lastupdatetime = ((Long) dataSnapshot.getValue());
                    LogUtil.debug(TAG, "get_TableValueEventListener setLastupdatetime onDataChange preferenceid="
                            + preferenceid + ",lastupdatetime=" + lastupdatetime );
                    GongPreference.setLastupdatetime(context,
                            lastupdatetime,
                            GongPreference.ID_KEY_MAP.get(preferenceid));
                    if (copytolocal == true){
                        GongPreference.setLastupdatetime(context,
                                lastupdatetime,
                                GongPreference.ID_KEY_MAP.get(GongPreference.ID_REMOTE_LOCAL_MAP.get(preferenceid))
                                );

                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    LogUtil.debug(TAG, "get_TableValueEventListener setLastupdatetime oncancelled");
                }
            };
            if (tmpValueEventListener == null) {
                throw new RuntimeException("get_TableValueEventListener setLastupdatetime error null");
            }
            return tmpValueEventListener;

        } else if (((preferenceid >= GongPreference.PREFERENCE_NOOFENTRY_START)
                && (preferenceid <= GongPreference.PREFERENCE_NOOFENTRY_END))
                ||
                ((preferenceid >= GongPreference.PREFERENCE_NOOFENTRY_LOCAL_START)
                && (preferenceid <= GongPreference.PREFERENCE_NOOFENTRY_LOCAL_END))) {

            tmpValueEventListener = new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    LogUtil.debug(TAG, "get_TableValueEventListener setNoOfEntry onDataChange preferenceid=" + preferenceid );
                    int noofentry = ((Long) dataSnapshot.getValue()).intValue();
                    LogUtil.debug(TAG, "get_TableValueEventListener setNoOfEntry onDataChange preferenceid=" + preferenceid
                       + ", noofentry=" + noofentry);
                    GongPreference.setNoOfEntry(context,
                            noofentry,
                            GongPreference.ID_KEY_MAP.get(preferenceid));
                    if (copytolocal == true) {
                        GongPreference.setNoOfEntry(context,
                                noofentry,
                                GongPreference.ID_KEY_MAP.get(GongPreference.ID_REMOTE_LOCAL_MAP.get(preferenceid))
                        );

                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                    LogUtil.debug(TAG, "get_TableValueEventListener setNoOfEntry oncancelled");
                }
            };
            if (tmpValueEventListener == null) {
                throw new RuntimeException("get_TableValueEventListener setNoOfEntry error null");
            }
            return tmpValueEventListener;

        } else {
            throw new RuntimeException("get_TableValueEventListener outofrange error null");
        }
    }


}
