package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI;
import static com.hk.gonggongnews.ngogong.data.GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI_NAME;

/**
 * Created by ismile on 11/23/2017.
 */

public class GongInfoLookupContract {


    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final int INDEX_TYPE = 0;
    public static final int INDEX_NAME = 1;
    public static final int INDEX_ID = 2;
    public static final int INDEX_SOURCEICONURL = 3;
    public static final int INDEX_NOOFENTRY = 4;
    public static final int INDEX_LASTUPDATETIME = 5;
    public static final int INDEX_SHEETID= 6;
    public static final int INDEX_SHEETID_URL= 7;
    public static final String[] PROJECTION = {
            GongInfoLookupEntry.COLUMN_TYPE,
            GongInfoLookupEntry.COLUMN_NAME,
            GongInfoLookupEntry.COLUMN_ID,
            GongInfoLookupEntry.COLUMN_SOURCEICONURL,
            GongInfoLookupEntry.COLUMN_NOOFENTRY,
            GongInfoLookupEntry.COLUMN_LASTUPDATETIME,
            GongInfoLookupEntry.COLUMN_SHEETID,
            GongInfoLookupEntry.COLUMN_SHEETID_URL
    };

    public static final String[] ALLNAME_PROJECTION = {
            GongInfoLookupEntry.COLUMN_TYPE,
            GongInfoLookupEntry.COLUMN_NAME,
            GongInfoLookupEntry.COLUMN_ID,
            GongInfoLookupEntry.COLUMN_SOURCEICONURL,
            GongInfoLookupEntry.COLUMN_NOOFENTRY,
            GongInfoLookupEntry.COLUMN_LASTUPDATETIME
    };

    public static final String SELECTION_NAME = " gonginfolookup.name = ? ";
    public static final String SELECTION_SHEET_ID = " gonginfolookup.sheetid == ? ";
    public static final String GROUP_BY_NAME = " gonginfolookup.name ";



    public static final String PATH_GONGINFOLOOKUP = "gonginfolookup";
    public static final String PATH_NAME = "name";
    public static final String PATH_INFONAME = "infoname";
    public static final String PATH_ALLNAME = "allname";

    public static final class GongInfoLookupEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_GONGINFOLOOKUP)
                .build();

        public static final Uri CONTENT_URI_NAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_GONGINFOLOOKUP)
                .appendPath(PATH_NAME)
                .build();

        public static final Uri CONTENT_URI_INFONAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_GONGINFOLOOKUP)
                .appendPath(PATH_INFONAME)
                .build();
        public static final Uri CONTENT_URI_ALLNAME  = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_GONGINFOLOOKUP)
                .appendPath(PATH_ALLNAME)
                .build();

        public static final String TABLE_NAME = "gonginfolookup";


        public static final String COLUMN_TYPE = "type";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_SOURCEICONURL  = "sourceiconurl";
        public static final String COLUMN_NOOFENTRY = "noofentry";
        public static final String COLUMN_LASTUPDATETIME = "lastupdatetime";
        public static final String COLUMN_SHEETID = "sheetid";
        public static final String COLUMN_SHEETID_URL = "sheetid_url";

    }

    public static String decodeKeyGetName (String combinekey){
        return combinekey.split("ZZ")[0].replaceAll("^0+(?!$)","");
    }

    public static int decodeKeyGetID (String combinekey){
        return Integer.valueOf(combinekey.split("ZZ")[1]);
    }

    public static long decodeGetLowerBound(String range) {
        String result  = range.split("ZZ")[0];
        return Long.valueOf(result);
    }

    public static long decodeGetHigherBound(String range) {
        String result = range.split("ZZ")[1];
        return Long.valueOf(result);
    }

    public static Uri buildArticleUriWithID(long id) {
        return CONTENT_URI.buildUpon()
                .appendPath(Long.toString(id))
                .build();
    }
    public static Uri buildUriWithNamePathAndName ( String name) {
        return CONTENT_URI_NAME.buildUpon()
                .appendPath(name)
                .build();
    }

    public static Uri buildArticleUriWithPATH (String type, String name) {
        return CONTENT_URI.buildUpon()
                .appendPath(PATH_NAME)
                .appendPath(type)
                .appendPath(name)
                .build();
    }

}
