package com.hk.gonggongnews.ngogong;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.util.ArticleInfo;
import com.hk.gonggongnews.ngogong.util.GongTimeUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 11/18/2017.
 */

public class BookmarkListAdapter extends
        RecyclerView.Adapter<BookmarkListAdapter.BookmarkIndNewsViewHolder> {

    private final String TAG = BookmarkListAdapter.class.getSimpleName();

    /* The context we use to utility methods, app resources and layout inflaters */
    private final Context mContext;

    private View.OnClickListener mBookmarkListActivity;
    private View.OnClickListener mshareClickListener;
    private Map<Integer, Integer> mSignalMap;
    private List<ArticleInfo> mArticleInfoList;

    //private final static int BOOKMARKALREADY_MASK = 0x0001;
    //private final static int READALREADY_MASK = 0x0002;
    private final static int EXPANDALREADY_MASK = 0x0004;
    private static final int VIEWTAG_ARTICLEID = 1;
    private static final int VIEWTAG_FINALURL = 2;

    private Cursor mCursor;


    private static final int PENDING_REMOVAL_TIMEOUT = 2000; // 3sec

    List<ArticleInfo> mArticlePendingRemoval;

    private Handler handler = new Handler(); // hanlder for running delayed runnables
    Map<ArticleInfo, Runnable> pendingRunnables = new HashMap<>(); // map of items to pending runnables, so we can cancel a removal if need be

    /*
     * Below, we've defined an interface to handle clicks on items within this Adapter. In the
     * constructor of our ForecastAdapter, we receive an instance of a class that has implemented
     * said interface. We store that instance in this variable to call the onClick method whenever
     * an item is clicked in the list.
     */
    private BookmarkListAdapter.BookmarkIndNewsAdapterOnClickHandler mClickHandler;

    /**
     * The interface that receives onClick messages.
     */
    public interface BookmarkIndNewsAdapterOnClickHandler {
        void onClickListIndNews(long entryID, String finalurl);

        void onClickBookmarkArticleStoreOrRemove(long entryID, boolean save);

    }


    /**
     * Creates a ForecastAdapter.
     *
     * @param context      Used to talk to the UI and app resources
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */

    public BookmarkListAdapter(@NonNull Context context,
                               BookmarkListAdapter.BookmarkIndNewsAdapterOnClickHandler clickHandler) {
        mContext = context;
        mClickHandler = clickHandler;
        mSignalMap = new HashMap<Integer, Integer>();
        mArticleInfoList = new ArrayList<>();
        mArticlePendingRemoval = new ArrayList<>();


        mBookmarkListActivity = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int articleID = (int) view.getTag(R.string.VIEWTAG_ARTICLEID);
                String finalurl = (String) view.getTag(R.string.VIEWTAG_FINALURL);
                int readalready_inmap = 0;
                int bitvalBookRead = 0;
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, articleID);
                if (mSignalMap.containsKey(articleID)) {
                    bitvalBookRead = mSignalMap.get(articleID);
                }
                readalready_inmap = bitvalBookRead | LatestNewsPaginationAdapter.READALREADY_MASK;
                mSignalMap.put(articleID, readalready_inmap);
                contentValues.put(SignalContract.SignalEntry.COLUMN_READALREADY, 1);
                mContext.getContentResolver().insert(
                        uri,
                        contentValues);


                //set the background color
                ViewGroup oneupLevelLayout = (ViewGroup) view.getParent();
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID) != null) {
                    LogUtil.debug(TAG, "VIEWTAG_BACKGROUND_LAYOUT_ID R.color.after_reading_color" );
                    oneupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID) != null) {
                    LogUtil.debug(TAG, "VIEWTAG_BACKGROUND_SHARE_ID R.color.after_reading_color" );
                    oneupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }

                //should start detailactivity if available
                LogUtil.debug(TAG, "---------------------> starting detail activity articleid="
                        + articleID
                        + ",finalurl="
                        + finalurl);
                sendbackToHostActivity(articleID, finalurl);
            }
        };


        mshareClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LogUtil.debug(TAG, " ib_sharebutton 1");
                String finalurl = (String) view.getTag(R.string.VIEWTAG_FINALURL);
                String title = (String) view.getTag(R.string.VIEWTAG_TITLE);

                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = title + "\n" + finalurl;
                String shareSub = title;
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                mContext.startActivity(Intent.createChooser(sharingIntent, "Share using"));
                LogUtil.debug(TAG, " ib_sharebutton 2");

            }
        };
        LogUtil.debug(TAG, " BookmarkListAdapter constructor ");
    }

    private void sendbackToHostActivity(int entryID, String finalurl) {
        LogUtil.debug(TAG, "--> sendbacktohostactivity entryID=" + entryID + ",finalurl=" + finalurl);
        mClickHandler.onClickListIndNews(entryID, finalurl);
    }


    /**
     * This gets called when each new ViewHolder is created. This happens when the RecyclerView
     * is laid out. Enough ViewHolders will be created to fill the screen and allow for scrolling.
     *
     * @param viewGroup The ViewGroup that these ViewHolders are contained within.
     * @param viewType  If your RecyclerView has more than one type of item (like ours does) you
     *                  can use this viewType integer to provide a different layout. See
     *                  {@link android.support.v7.widget.RecyclerView.Adapter#getItemViewType(int)}
     *                  for more details.
     * @return A new ForecastAdapterViewHolder that holds the View for each list item
     */

    @Override
    public BookmarkListAdapter.BookmarkIndNewsViewHolder
    onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        int layoutId;
        View view;

        layoutId = R.layout.bookmark_list_item;
        view = LayoutInflater.from(mContext).inflate(layoutId, viewGroup, false);

        view.setFocusable(true);
        LogUtil.debug(TAG, "BookmarkListAdapter onCreateViewHolder");

        return new BookmarkListAdapter.BookmarkIndNewsViewHolder(view);

    }


    /**
     * OnBindViewHolder is called by the RecyclerView to display the data at the specified
     * position. In this method, we update the contents of the ViewHolder to display the weather
     * details for this particular position, using the "position" argument that is conveniently
     * passed into us.
     *
     * @param bookmarkIndNewsAdapterViewHolder The ViewHolder which should be updated to represent the
     *                                         contents of the item at the given position in the data set.
     * @param position                         The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(BookmarkListAdapter.BookmarkIndNewsViewHolder bookmarkIndNewsAdapterViewHolder,
                                 int position) {

        final int articlePrimaryID = mArticleInfoList.get(position).getID();
        final ArticleInfo articleEntry = mArticleInfoList.get(position);
        final String finalurl = mArticleInfoList.get(position).getFinalurl();

        LogUtil.debug(TAG, " onBindViewHolder 1 ");

        if (mArticlePendingRemoval.contains(articleEntry)) {
            LogUtil.debug(TAG, " onBindViewHolder 2 ");
            bookmarkIndNewsAdapterViewHolder.itemView.setBackgroundColor(Color.BLACK);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.ib_bookmarkButton.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.ib_expandlessButton.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.ib_shareButton.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.tv_dateView.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setVisibility(View.GONE);
            bookmarkIndNewsAdapterViewHolder.b_undoButton.setVisibility(View.VISIBLE);
            ((ViewGroup) bookmarkIndNewsAdapterViewHolder.ib_shareButton.getParent()).setBackground(null);
            int bottombound = ((View) bookmarkIndNewsAdapterViewHolder.b_undoButton.getParent()).getHeight();
            LogUtil.debug(TAG, " onBindViewHolder getwidth=" + bottombound);

            if (bookmarkIndNewsAdapterViewHolder.leftToright) {
                LogUtil.debug(TAG, " onBindViewHolder undoButton lefttoright = true");
                //viewHolder.undoButton.setGravity(Gravity.START);
                bookmarkIndNewsAdapterViewHolder.b_undoButton.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START));
            } else {
                LogUtil.debug(TAG, " onBindViewHolder undoButton lefttoright = false");
                //viewHolder.undoButton.setGravity(Gravity.END);
                bookmarkIndNewsAdapterViewHolder.b_undoButton.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END));
            }
            bookmarkIndNewsAdapterViewHolder.b_undoButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // user wants to undo the removal, let's cancel the pending task
                    Runnable pendingRemovalRunnable = pendingRunnables.get(articleEntry);
                    pendingRunnables.remove(articleEntry);
                    if (pendingRemovalRunnable != null)
                        handler.removeCallbacks(pendingRemovalRunnable);
                    mArticlePendingRemoval.remove(articleEntry);
                    // this will rebind the row in "normal" state
                    notifyItemChanged(mArticleInfoList.indexOf(articleEntry));
                }
            });


        } else {
            LogUtil.debug(TAG, " onBindViewHolder 3 ");
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setVisibility(View.VISIBLE);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setVisibility(View.VISIBLE);
            bookmarkIndNewsAdapterViewHolder.ib_shareButton.setVisibility(View.VISIBLE);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setVisibility(View.VISIBLE);
            bookmarkIndNewsAdapterViewHolder.tv_dateView.setVisibility(View.VISIBLE);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setVisibility(View.VISIBLE);

            Drawable background = bookmarkIndNewsAdapterViewHolder.itemView.getBackground();
            int color=0;
            if (background instanceof ColorDrawable) {
                color = ((ColorDrawable) background).getColor();
                LogUtil.debug(TAG, " onBindViewHolder 3.1 color=" + color);
                bookmarkIndNewsAdapterViewHolder.itemView.setBackground(null);
                LogUtil.debug(TAG, " onBindViewHolder 3.2 color=" + color);

            }

            bookmarkIndNewsAdapterViewHolder.b_undoButton.setVisibility(View.GONE);

            if (mArticleInfoList.get(position).getImageurl()
                    .compareTo("EMPTYSTRINGVALUE") == 0) {
                bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setImageResource(R.drawable.ic_logo_hourglass_question);
            } else {
                GlideApp.with(mContext)
                        .load(mArticleInfoList.get(position).getImageurl())
                        .placeholder(R.drawable.ic_tmp_icon)
                        .fitCenter()
                        .into(bookmarkIndNewsAdapterViewHolder.itemthumbnailView);
            }
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setOnClickListener(mBookmarkListActivity);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
            bookmarkIndNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);

            int pagination_firstsubdomainid = mArticleInfoList.get(position).getFirstsubdomaintable_id();

            ArrayList<String> sourceIconURLChiName = SourceInfo.getInstance()
                    .getSourceIconURLAndName(pagination_firstsubdomainid);

            GlideApp.with(mContext)
                    .load(sourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                    .placeholder(R.drawable.ic_tmp_icon)
                    .fitCenter()
                    .into(bookmarkIndNewsAdapterViewHolder.newsourceiconView);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setOnClickListener(mBookmarkListActivity);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
            bookmarkIndNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


            LogUtil.debug(TAG, " onBindViewHolder 4 ");


            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setText(sourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setOnClickListener(mBookmarkListActivity);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
            bookmarkIndNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


            int bitfromjson = mArticleInfoList.get(position).getSignalBitmap();
            int bookmarkalready = bitfromjson & LatestNewsPaginationAdapter.BOOKMARKALREADY_MASK;
            int readalready = bitfromjson & LatestNewsPaginationAdapter.READALREADY_MASK;



            LogUtil.debug(TAG, " BookmarkListAdapter.BookmarkIndNewsViewHolder  1 articlePrimaryID="
                    + articlePrimaryID
                    + ", bitfromjson=" + bitfromjson
                    + ",bookmarkalready=" + bookmarkalready
                    + ",readalready=" + readalready );


            int readalready_inmap = 0;
            int bitvalBookRead = 0;

            if (mSignalMap.containsKey(articlePrimaryID)) {
                bitvalBookRead = mSignalMap.get(articlePrimaryID);
                readalready_inmap = bitvalBookRead & LatestNewsPaginationAdapter.READALREADY_MASK;
            } else {
                mSignalMap.put(articlePrimaryID, bitfromjson);
            }
            LogUtil.debug(TAG, " BookmarkListAdapter.BookmarkIndNewsViewHolder  2 articlePrimaryID="
                    + articlePrimaryID
                    + ",bitvalBookRead=" + bitvalBookRead
                    + ",readalready_inmap=" + readalready_inmap
                    + ",title=" + mArticleInfoList.get(position).getTitle());

            if ((readalready != 0)
                    || (readalready_inmap != 0)) {
                bookmarkIndNewsAdapterViewHolder.ib_shareButton.setBackgroundResource(R.color.after_reading_color);
                ((ViewGroup) bookmarkIndNewsAdapterViewHolder.ib_shareButton.getParent()).setBackgroundResource(R.color.after_reading_color);
            } else {
                //use default background
                //  (readalready == 0) && (readalready_inmap == 0) or else
                // latestNewsPaginationAdapterViewHolder.ib_bookmarkButton.setSelected(false);
                bookmarkIndNewsAdapterViewHolder.ib_shareButton.setBackgroundResource(0);
                ((ViewGroup) bookmarkIndNewsAdapterViewHolder.ib_shareButton.getParent()).setBackgroundResource(0);
            }


            bookmarkIndNewsAdapterViewHolder.ib_bookmarkButton.setVisibility(View.INVISIBLE);


            final String primarytitle = mArticleInfoList.get(position).getTitle();

            bookmarkIndNewsAdapterViewHolder.ib_shareButton.setOnClickListener(mshareClickListener);
            bookmarkIndNewsAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
            bookmarkIndNewsAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_FINALURL, finalurl);
            bookmarkIndNewsAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_TITLE, primarytitle);

            bookmarkIndNewsAdapterViewHolder.ib_expandlessButton.setVisibility(View.INVISIBLE);

            bookmarkIndNewsAdapterViewHolder.primarytitleView.setText(primarytitle);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setOnClickListener(mBookmarkListActivity);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
            bookmarkIndNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


            int timestampondoc = mArticleInfoList.get(position).getTimestampondoc();
            String timestampondocTranslatedString = GongTimeUtil.getDisplayTimeStringFromData((long) timestampondoc, mContext);
            bookmarkIndNewsAdapterViewHolder.tv_dateView.setText(timestampondocTranslatedString);
            bookmarkIndNewsAdapterViewHolder.tv_dateView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
            bookmarkIndNewsAdapterViewHolder.tv_dateView.setTag(R.string.VIEWTAG_FINALURL, finalurl);


            LogUtil.debug(TAG, " BookmarkListAdapter.BookmarkIndNewsViewHolder onBindViewHolder 5 " + position);
        }

    }

    public void pendingRemoval(int position) {
        final ArticleInfo item = mArticleInfoList.get(position);
        if (!mArticlePendingRemoval.contains(item)) {
            mArticlePendingRemoval.add(item);
            // this will redraw row in "undo" state
            notifyItemChanged(position);
            // let's create, store and post a runnable to remove the item
            Runnable pendingRemovalRunnable = new Runnable() {
                @Override
                public void run() {
                    remove(mArticleInfoList.indexOf(item));
                }
            };
            handler.postDelayed(pendingRemovalRunnable, PENDING_REMOVAL_TIMEOUT);
            pendingRunnables.put(item, pendingRemovalRunnable);
        }
    }


    public void remove(int position) {
        final ArticleInfo item = mArticleInfoList.get(position);

        mClickHandler.onClickBookmarkArticleStoreOrRemove(item.getID(), false);
        Uri uri = SignalContract.SignalEntry.CONTENT_URI;
        ContentValues contentValues = new ContentValues();
        contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, item.getID());
        mSignalMap.remove(item.getID());
        contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 0);
        mContext.getContentResolver().insert(
                uri,
                contentValues);

        if (mArticlePendingRemoval.contains(item)) {
            LogUtil.debug(TAG, " remove mArticlePendingRemoval =" +mArticlePendingRemoval.remove(item));
        }
        if (mArticleInfoList.contains(item)) {
            LogUtil.debug(TAG, " remove mArticleInfoList =" + mArticleInfoList.remove(position).getTitle());
            notifyItemRemoved(position);
        }
    }

    public boolean isPendingRemoval(int position) {
        final ArticleInfo item = mArticleInfoList.get(position);
        return mArticlePendingRemoval.contains(item);
    }


    /**
     * This method simply returns the number of items to display. It is used behind the scenes
     * to help layout our Views and for animations.
     *
     * @return The number of items available in our forecast
     */
    @Override
    public int getItemCount() {
        if (mArticleInfoList != null) {
            LogUtil.debug(TAG, " BookmarkListAdapter getitemcount 1 =" + mArticleInfoList.size());
            return mArticleInfoList.size();
        } else {
            return 0;
        }

    }

    /**
     * Returns an integer code related to the type of View we want the ViewHolder to be at a given
     * position. This method is useful when we want to use different layouts for different items
     * depending on their position. In Sunshine, we take advantage of this method to provide a
     * different layout for the "today" layout. The "today" layout is only shown in portrait mode
     * with the first item in the list.
     *
     * @param position index within our RecyclerView and Cursor
     * @return the view type (today or future day)
     */
    @Override
    public int getItemViewType(int position) {
        //return -1;
        return 0;
    }

    /**
     * Swaps the cursor used by the ForecastAdapter for its weather data. This method is called by
     * MainActivity after a load has finished, as well as when the Loader responsible for loading
     * the weather data is reset. When this method is called, we assume we have a completely new
     * set of data, so we call notifyDataSetChanged to tell the RecyclerView to update.
     *
     * @param newCursor the new cursor to use as ForecastAdapter's data source
     */
    void swapCursor(Cursor newCursor) {

        LogUtil.debug(TAG, " BookmarkListAdapter swapcursor  ");

        mCursor = newCursor;
        if (mCursor != null) {
            LogUtil.debug(TAG, " BookmarkListAdapter swapcursor  getcount=" + mCursor.getCount());
        }
        if ((newCursor != null) && (newCursor.getCount() > 0)) {
            mArticleInfoList.clear();
            for (int x = 0; x < newCursor.getCount(); x++) {
                newCursor.moveToPosition(x);
                int bitmask = newCursor.getInt(ArticleTableContract.INDEX_BOOKMARK_BOOKMARKALREADY) == 1 ?
                        LatestNewsPaginationAdapter.BOOKMARKALREADY_MASK : 0;
                bitmask |= newCursor.getInt(ArticleTableContract.INDEX_BOOKMARK_READALREADY) == 1 ?
                        LatestNewsPaginationAdapter.READALREADY_MASK : 0;

                ArticleInfo newEntry = new ArticleInfo(
                        newCursor.getInt(ArticleTableContract.INDEX_BOOKMARK_FIRSTSUBDOMAINTABLE_ID),
                        newCursor.getString(ArticleTableContract.INDEX_BOOKMARK_TITLE),
                        newCursor.getString(ArticleTableContract.INDEX_BOOKMARK_IMAGEURL),
                        newCursor.getInt(ArticleTableContract.INDEX_BOOKMARK_ARTICLETABLE_ID),
                        newCursor.getString(ArticleTableContract.INDEX_BOOKMARK_FINALURL),
                        newCursor.getInt(ArticleTableContract.INDEX_BOOKMARK_TIMESTAMPONDOC),
                        bitmask);
                mArticleInfoList.add(newEntry);
            }
        }
        notifyDataSetChanged();
    }


    void updateSignalMapFromCursor(Cursor newCursor) {
        LogUtil.debug(TAG, " BookmarkListAdapter  updateSignalMapFromCursor  ");

        if (newCursor != null) {
            LogUtil.debug(TAG, " BookmarkListAdapter  updateSignalMapFromCursor  getcount=" + newCursor.getCount());
            mSignalMap.clear();
            for (int index = 0; index < newCursor.getCount(); index++) {
                newCursor.moveToPosition(index);
                int articleID = newCursor.getInt(SignalContract.INDEX_ARTICLE_ID);
                int readalreadyFromCursor = newCursor.getInt(SignalContract.INDEX_READALREADY);
                int bitvalBookRead = 0;
                if (mSignalMap.containsKey(articleID)) {
                    bitvalBookRead = mSignalMap.get(articleID);
                }
                if (readalreadyFromCursor == 0) {
                    bitvalBookRead = bitvalBookRead & ~LatestNewsPaginationAdapter.READALREADY_MASK;
                } else {
                    bitvalBookRead = bitvalBookRead | LatestNewsPaginationAdapter.READALREADY_MASK;

                }
                mSignalMap.put(articleID, bitvalBookRead);
            }
            notifyDataSetChanged();
        }
    }


    /**
     * A ViewHolder is a required part of the pattern for RecyclerViews. It mostly behaves as
     * a cache of the child views for a forecast item. It's also a convenient place to set an
     * OnClickListener, since it has access to the adapter and the views.
     */
    class BookmarkIndNewsViewHolder extends RecyclerView.ViewHolder {
        private final String TAG = BookmarkListAdapter.BookmarkIndNewsViewHolder.class.getSimpleName();

        //the whole view of item
        //final View articleindlistitem;

        //article_list_item_primary.xml
        final ImageView itemthumbnailView;
        final ImageView newsourceiconView;
        final ImageButton ib_bookmarkButton;
        final ImageButton ib_expandlessButton;
        final ImageButton ib_shareButton;
        final TextView tv_domainsourceView;
        final TextView tv_dateView;
        final TextView primarytitleView;
        final Button b_undoButton;
        boolean leftToright=true;


        BookmarkIndNewsViewHolder(View view) {
            super(view);


            itemthumbnailView = (ImageView) view.findViewById(R.id.itemthumbnail);
            newsourceiconView = (ImageView) view.findViewById(R.id.newsourceicon);
            ib_bookmarkButton = (ImageButton) view.findViewById(R.id.ib_bookmark);
            ib_expandlessButton = (ImageButton) view.findViewById(R.id.ib_expandless);
            ib_shareButton = (ImageButton) view.findViewById(R.id.ib_share);
            tv_domainsourceView = (TextView) view.findViewById(R.id.tv_domainsource);
            tv_dateView = (TextView) view.findViewById(R.id.tv_date);
            primarytitleView = (TextView) view.findViewById(R.id.primarytitle);
            b_undoButton = (Button) view.findViewById(R.id.undo_button);


            LogUtil.debug(TAG, " BookmarkIndNewsViewHolder constructor 1");


        }


    }

}


