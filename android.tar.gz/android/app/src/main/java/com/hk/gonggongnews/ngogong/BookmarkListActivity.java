package com.hk.gonggongnews.ngogong;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;
import android.support.v7.widget.helper.ItemTouchHelper;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;
import com.hk.gonggongnews.ngogong.util.BottomNavigationViewHelper;

import java.util.LinkedHashMap;
import java.util.Map;


/**
 * Created by ismile on 11/17/2017.
 */

public class BookmarkListActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>,
        BookmarkListAdapter.BookmarkIndNewsAdapterOnClickHandler  {


    public static final String JSONARTICLELISTSTR = "jsonarticleliststr";
    public static final String JSONSIGNALBITSTR = "jsonsignalbitstr";

    private Map<String, String> mArticleLookupList;

    private final String TAG = BookmarkListActivity.class.getSimpleName();

    private static final int ID_ARTICLELOOKUP_LOADER = 301;
    private static final int ID_SIGNAL_LOADER = 302;
    private static final int ID_ARTICLEBOOKMARK_LOADER = 303;
    private BookmarkListAdapter mBookmarkListAdapter;

    private SlowdownRecyclerView mRecyclerView;
    private int mPosition = RecyclerView.NO_POSITION;
    private BottomNavigationView mBottomNavigationView;

    private ProgressBar mLoadingIndicator;

    private boolean mLoadingMore = false;
    //private SwipeRefreshLayout mSwipeRefreshLayout ;
    private boolean mRefreshingLayout = false;


    public static final String[] NEWSFRAGMENT_PROJECTION = {
            LatestNewsPaginationContract.PaginationEntry._ID,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_ENTRY,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC_AND_ID,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE,
    };
    public static final int INDEX_PAGINATION__ID = 0;
    public static final int INDEX_PAGINATION_ENTRY = 1;
    public static final int INDEX_PAGINATION_FINALURL = 2;
    public static final int INDEX_PAGINATION_IMAGEURL = 3;
    public static final int INDEX_PAGINATION_TIMESTAMPONDOC_AND_ID = 4;
    public static final int INDEX_TITLE = 5;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmark_news);

        SourceInfo.init(this, getSupportLoaderManager());
        Intent intent = getIntent();

        mArticleLookupList = new LinkedHashMap<String, String>();

        mBottomNavigationView = (BottomNavigationView) findViewById(R.id.bottom_mainnews_navigation);
        BottomNavigationViewHelper.selection(this, mBottomNavigationView, R.id.nav_bookmark);
        Menu menu = mBottomNavigationView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);


        mRecyclerView = (SlowdownRecyclerView) findViewById(R.id.recyclerview_slowdown);

        LinearLayoutManager layoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mBookmarkListAdapter = new BookmarkListAdapter(this,
                this);

        mRecyclerView.setAdapter(mBookmarkListAdapter);
        setUpItemTouchHelper();
        setUpAnimationDecoratorHelper();

        //mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);

        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setTitle(R.string.my_bookmarked);

        getSupportLoaderManager().initLoader(ID_ARTICLELOOKUP_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_SIGNAL_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_ARTICLEBOOKMARK_LOADER, null, this);
        //SourceInfo.init(getApplicationContext(), getSupportLoaderManager());


        Gongdispatch.findNotInInitialize(getApplicationContext());
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        LogUtil.debug(TAG, " bookmarklistactivity onrestart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        LogUtil.debug(TAG, " bookmarklistactivity onstop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LogUtil.debug(TAG, " bookmarklistactivity ondestroy");
    }

    /**
     * This is the standard support library way of implementing "swipe to delete" feature. You can do custom drawing in onChildDraw method
     * but whatever you draw will disappear once the swipe is over, and while the items are animating to their new position the recycler view
     * background will be visible. That is rarely an desired effect.
     */
    private void setUpItemTouchHelper() {

        ItemTouchHelper.SimpleCallback simpleItemTouchCallback =
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

                    // we want to cache these and not allocate anything repeatedly in the onChildDraw method
                    Drawable background;
                    Drawable xMark;
                    int xMarkMargin;
                    boolean initiated;

                    private void init() {
                        background = new ColorDrawable(Color.BLACK);
                        xMark = ContextCompat.getDrawable(BookmarkListActivity.this, R.drawable.ic_clear_delete_cross);
                        xMark.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
                        xMarkMargin = (int) BookmarkListActivity.this.getResources().getDimension(R.dimen.padding_normal);
                        initiated = true;
                    }

                    // not important, we don't want drag & drop
                    @Override
                    public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public int getSwipeDirs(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
                        int position = viewHolder.getAdapterPosition();
                        BookmarkListAdapter bookmarkListAdapter= (BookmarkListAdapter)recyclerView.getAdapter();
                        if ( bookmarkListAdapter.isPendingRemoval(position)) {
                            return 0;
                        }
                        return super.getSwipeDirs(recyclerView, viewHolder);
                    }

                    @Override
                    public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
                        int swipedPosition = viewHolder.getAdapterPosition();
                        BookmarkListAdapter adapter = (BookmarkListAdapter)mRecyclerView.getAdapter();
                            adapter.pendingRemoval(swipedPosition);
                    }

                    @Override
                    public void onChildDraw(Canvas c, RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder,
                                            float dX, float dY, int actionState, boolean isCurrentlyActive) {
                        View itemView = viewHolder.itemView;

                        // not sure why, but this method get's called for viewholder that are already swiped away
                        if (viewHolder.getAdapterPosition() == -1) {
                            // not interested in those
                            return;
                        }

                        if (!initiated) {
                            LogUtil.debug(TAG, "...................start onchilddraw init");
                            init();
                        }

                        // draw red background
                        BookmarkListAdapter.BookmarkIndNewsViewHolder bookmarkIndNewsViewHolder =
                                (BookmarkListAdapter.BookmarkIndNewsViewHolder)viewHolder;
                        LogUtil.debug(TAG, " simpleItemTouchCallback onChildDraw viewholder=" + bookmarkIndNewsViewHolder.primarytitleView.getText()
                                + ",getgetRight=" + itemView.getRight() + ",dX=" + dX + ",dY=" + dY + ",getTop=" + itemView.getTop() +
                                ", getBottom=" + itemView.getBottom());
                        if ((int) dX < 0 ) {
                            bookmarkIndNewsViewHolder.leftToright = false;
                            background.setBounds(itemView.getRight() + (int) dX, itemView.getTop(), itemView.getRight(), itemView.getBottom());
                            LogUtil.debug(TAG, "simpleItemTouchCallback lefttoright 1");
                        } else {
                            bookmarkIndNewsViewHolder.leftToright = true;
                            background.setBounds(itemView.getLeft(), itemView.getTop(), (int) dX, itemView.getBottom());
                            LogUtil.debug(TAG, "simpleItemTouchCallback lefttoright 2");
                        }
                        background.draw(c);

                        /*
                        // draw x mark
                        int itemHeight = itemView.getBottom() - itemView.getTop();
                        int intrinsicWidth = xMark.getIntrinsicWidth();
                        int intrinsicHeight = xMark.getIntrinsicWidth();

                        int xMarkLeft, xMarkRight =0;
                        if ((int) dX < 0 ) {
                            xMarkLeft = itemView.getRight() - xMarkMargin - intrinsicWidth;
                            xMarkRight = itemView.getRight() - xMarkMargin;
                        } else {
                            xMarkLeft = itemView.getLeft() + xMarkMargin ;
                            xMarkRight = itemView.getLeft() + xMarkMargin+  intrinsicWidth;
                        }
                        int xMarkTop = itemView.getTop() + (itemHeight - intrinsicHeight)/2;
                        int xMarkBottom = xMarkTop + intrinsicHeight;
                        xMark.setBounds(xMarkLeft, xMarkTop, xMarkRight, xMarkBottom);

                        xMark.draw(c);
                        */

                        super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
                    }

                };
        ItemTouchHelper mItemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        mItemTouchHelper.attachToRecyclerView(mRecyclerView);
    }

    /**
     * We're gonna setup another ItemDecorator that will draw the red background in the empty space while the items are animating to thier new positions
     * after an item is removed.
     */
    private void setUpAnimationDecoratorHelper() {
        mRecyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {

            // we want to cache this and not allocate anything repeatedly in the onDraw method
            Drawable background;
            boolean initiated;

            private void init() {
                background = new ColorDrawable(Color.BLACK);
                initiated = true;
            }

            @Override
            public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {

                if (!initiated) {
                    LogUtil.debug(TAG, "...................start ondraw init");
                    init();
                }

                // only if animation is in progress
                if (parent.getItemAnimator().isRunning()) {

                    // some items might be animating down and some items might be animating up to close the gap left by the removed item
                    // this is not exclusive, both movement can be happening at the same time
                    // to reproduce this leave just enough items so the first one and the last one would be just a little off screen
                    // then remove one from the middle

                    // find first child with translationY > 0
                    // and last one with translationY < 0
                    // we're after a rect that is not covered in recycler-view views at this point in time
                    View lastViewComingDown = null;
                    View firstViewComingUp = null;

                    // this is fixed
                    int left = 0;
                    int right = parent.getWidth();

                    // this we need to find out
                    int top = 0;
                    int bottom = 0;

                    // find relevant translating views
                    int childCount = parent.getLayoutManager().getChildCount();
                    LogUtil.debug(TAG, " setUpAnimationDecoratorHelper childcount=" +childCount + ",");
                    for (int i = 0; i < childCount; i++) {
                        View child = parent.getLayoutManager().getChildAt(i);

                        float ytestfloat = child.getTranslationY();
                        float xtestfloat = child.getTranslationX();


                        /*
                        LogUtil.debug(TAG, "  i=" + i + ", --- gettranslationy= " + ytestfloat+ ",gettranslationx=" + xtestfloat +",");
                        LogUtil.debug(TAG, "  i=" + i + ", --- getY= " + child.getY() + ",getX=" + child.getX() +",");
                        LogUtil.debug(TAG, "  i=" + i + ", --- getTop= " + child.getTop() + ",getBottom=" + child.getBottom() +",");
                        LogUtil.debug(TAG, "  i=" + i + ", --- getLeft= " + child.getLeft() + ",getRight=" + child.getRight() +",");
                        */


                        if (child.getTranslationY() < 0) {
                            if (lastViewComingDown == null) {
                                // view is coming down
                                LogUtil.debug(TAG, " setUpAnimationDecoratorHelper lastViewComingDown i=" + i + ",");
                                lastViewComingDown = child;
                            }
                        } else if (child.getTranslationY() > 0) {
                            // view is coming up
                            if (firstViewComingUp == null) {
                                LogUtil.debug(TAG, " setUpAnimationDecoratorHelper firstViewComingUp i=" + i + ",");
                                firstViewComingUp = child;
                            }
                        }
                    }

                    if (lastViewComingDown != null && firstViewComingUp != null) {
                        // views are coming down AND going up to fill the void
                        top = lastViewComingDown.getBottom() + (int) lastViewComingDown.getTranslationY();
                        bottom = firstViewComingUp.getTop() + (int) firstViewComingUp.getTranslationY();

                    } else if (lastViewComingDown != null) {
                        // views are going down to fill the void
                        top = lastViewComingDown.getBottom() + (int) lastViewComingDown.getTranslationY();
                        bottom = lastViewComingDown.getBottom();
                    } else if (firstViewComingUp != null) {
                        // views are coming up to fill the void
                        top = firstViewComingUp.getTop();
                        bottom = firstViewComingUp.getTop() + (int) firstViewComingUp.getTranslationY();
                    }

                    LogUtil.debug(TAG, " background.setbounds left="+ left + ",top=" + top + ",right=" +right + ",bottom=" + bottom);
                    background.setBounds(left, top, right, bottom);
                    background.draw(c);

                }
                super.onDraw(c, parent, state);
            }

        });
    }



    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        LogUtil.debug(TAG, "----> oncreateloader ");
        switch (id) {
            case ID_ARTICLELOOKUP_LOADER:
                Uri articlelookupQueryUri = ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI;
                String articlelookupsortOrder = ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                return new CursorLoader(this,
                        articlelookupQueryUri,
                        ArticleLookupTableContract.PROJECTION,
                        null,
                        null,
                        articlelookupsortOrder);

            case ID_ARTICLEBOOKMARK_LOADER:
                Uri articlebookmarkQueryUri = ArticleTableContract.ArticleEntry.CONTENT_BOOKMARK_URI;
                String bookmarksortOrder = ArticleTableContract.ArticleEntry.COLUMN_TIMESTAMPONDOC+ " DESC";
                LogUtil.debug(TAG, "----> oncreateloader 4");

                return new CursorLoader(this,
                        articlebookmarkQueryUri,
                        SignalContract.PROJECTION,
                        null,
                        null,
                        bookmarksortOrder);

            case ID_SIGNAL_LOADER:
            default:
                if (id != ID_SIGNAL_LOADER){
                    Log.w(TAG,"Loader Not Implemented: " + id);
                    //throw new RuntimeException("Loader Not Implemented: " + id);
                }
                Uri signalQueryUri = SignalContract.SignalEntry.CONTENT_URI;
                String signalsortOrder = SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 3");

                return new CursorLoader(this,
                        signalQueryUri,
                        SignalContract.PROJECTION,
                        null,
                        null,
                        signalsortOrder);

        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, "  onloadfinished 1 ");

        switch (loader.getId()) {
            case ID_ARTICLELOOKUP_LOADER:
                if ((data != null) && (data.getCount() > 0)) {
                    for (int index = 0; index < data.getCount(); index++) {
                        data.moveToPosition(index);
                        mArticleLookupList.put(
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID),
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, "  onloadinfished articlelookup_loader index="
                                + index
                                + ", sheetid="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, "  onloadinfished articlelookup_loader getcount=0");
                }
                LogUtil.debug(TAG, " ID_ARTICLELOOKUP_LOADER mArticleLookupList=" + mArticleLookupList.toString());

                break;
            case ID_SIGNAL_LOADER:
                mBookmarkListAdapter.updateSignalMapFromCursor(data);
                //getActivity().getSupportLoaderManager().destroyLoader(ID_SIGNAL_LOADER);
                LogUtil.debug(TAG, "  onloadfinished 2 loaderid=" + loader.getId());

                break;

            case ID_ARTICLEBOOKMARK_LOADER:
                mBookmarkListAdapter.swapCursor(data);
                //getActivity().getSupportLoaderManager().destroyLoader(ID_SIGNAL_LOADER);
                LogUtil.debug(TAG, "  onloadfinished 3 loaderid=" + loader.getId());

                break;

            default:
                LogUtil.debug(TAG, "  onloadfinished 4 loaderid=" + loader.getId());
                break;
        }
        data.close();

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        LogUtil.debug(TAG, "----> onloaderreset ");

    }

    @Override
    public void onClickListIndNews(long entryID, String finalurl) {


        for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

            if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                    && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                LogUtil.debug(TAG, "  --> onClickLatestNewsPagination 1 entryID=" + entryID);
                Intent intent = new Intent(this, DetailNewsActivity.class);
                intent.putExtra(DetailNewsActivity.SHEET_ID, mapentry.getValue());
                intent.putExtra(DetailNewsActivity.ARTICLE_ID, entryID);
                intent.putExtra(DetailNewsActivity.FINALURL, finalurl);
                intent.putExtra(DetailNewsActivity.ROWID, entryID -
                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1);
                startActivity(intent);
                LogUtil.debug(TAG, "  --> onClickLatestNewsPagination 2 entryID=" + entryID);

                break;
            }
        }
        LogUtil.debug(TAG, " --> onClickLatestNewsPagination 3 ");

    }

    @Override
    public void onClickBookmarkArticleStoreOrRemove(long entryID, boolean save) {
        if (save) {
            for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

                if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                        && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                    LogUtil.debug(TAG, " newsfragment --> onClickBookmarkArticleStoreOrRemove 1 entryID=" + entryID);
                    if (Gongdispatch.isOnline(this)) {
                        Gongdispatch.gsheetfetchOneEntry(this,
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);
                    } else {
                        Gongdispatch.gongdispatchOneEntry(this,
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);

                        Toast.makeText(this, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                    LogUtil.debug(TAG, " newsfragment --> onClickBookmarkArticleStoreOrRemove 2 entryID=" + entryID);
                    break;
                }
            }
            LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 3 ");
        } else {
            //remove
            Uri removeindIDURI = ArticleTableContract.buildArticleUriWithID(entryID);
            String selection = " " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " == ? ";

            int result = getContentResolver().delete(
                    removeindIDURI,
                    selection,
                    null);
            LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 4 result= " + result);

        }

    }

}

