package com.hk.gonggongnews.ngogong.util;
import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.preference.PreferenceManager;
import android.view.ContextThemeWrapper;

import com.hk.gonggongnews.ngogong.R;

import java.util.Locale;
public class LocaleHelper {

    public static Context onAttach(Context context, Application app) {
        String locale = getPersistedLocale(context);
        return setLocale(context, locale, app);
    }

    public static Context onAttach(Context context) {
        String locale = getPersistedLocale(context);
        return setLocale(context, locale);
    }

    public static String getPersistedLocale(Context context) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context);
        return preferences.getString("gong_lang_pref", "english");
    }

    /**
     * Set the app's locale to the one specified by the given String.
     *
     * @param context
     * @param localeSpec a locale specification as used for Android resources (NOTE: does not
     *                   support country and variant codes so far); the special string "system" sets
     *                   the locale to the locale specified in system settings
     * @return
     */
    public static Context setLocale(Context context, String localeSpec) {
        Locale locale;
        if (localeSpec.compareTo("english")==0){
            locale = Locale.ENGLISH;
        } else {
            locale = Locale.CHINESE;
        }

        Locale.setDefault(locale);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return updateResources(context, locale);
            //return overrideconfiguration(context, locale);
        } else {
            return updateResourcesLegacy(context, locale);
        }
    }

    public static Context setLocale(Context context, String localeSpec, Application app) {
        Locale locale;
        if (localeSpec.compareTo("english")==0){
            locale = Locale.ENGLISH;
        } else {
            locale = Locale.CHINESE;
        }

        Locale.setDefault(locale);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return updateResources(context, locale, app);
            //return overrideconfiguration(context, locale);
        } else {
            return updateResourcesLegacy(context, locale);
        }
    }


    private static Context overrideconfiguration(Context context, Locale locale) {
        Configuration configuration = new Configuration(context.getResources().getConfiguration());
        configuration.setLocale(locale);
        /*
        ContextThemeWrapper contextwrapper = new ContextThemeWrapper(context, 0);
        ContextThemeWrapper ctw = (ContextThemeWrapper) context;
        contextwrapper.applyOverrideConfiguration(configuration);
        ctw.applyOverrideConfiguration(configuration);
        return contextwrapper;
        */
        return context;

    }



    private static Context updateResources(Context context, Locale locale) {
        Configuration configuration = context.getResources().getConfiguration();
        configuration.setLocale(locale);
        configuration.setLayoutDirection(locale);

        return context.getApplicationContext().createConfigurationContext(configuration);
    }
    private static Context updateResources(Context context, Locale locale, Application app) {
        Configuration conf = app.getResources().getConfiguration();
        conf.setLocale(locale);
        app.getResources().updateConfiguration(conf, app.getResources().getDisplayMetrics());

        return context;
    }

    private static Context updateResourcesLegacy(Context context, Locale locale) {
        Resources resources = context.getResources();

        Configuration configuration = resources.getConfiguration();
        configuration.locale = locale;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            configuration.setLayoutDirection(locale);
        }

        resources.updateConfiguration(configuration, resources.getDisplayMetrics());

        return context;
    }
}
