package com.hk.gonggongnews.ngogong.sync;

import android.app.IntentService;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.AbstractWindowedCursor;
import android.database.Cursor;
import android.database.CursorWindow;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
/**
 * Created by ismile on 10/11/2017.
 */


public class FirebaseIntentService extends IntentService {


    public final static int TABLE_UPDATE_UNKNOWN = 0;
    public final static int TABLE_UPDATE_INITIAL = 1;
    public final static int TABLE_UPDATE_ARTICLELOOKUP = 3;
    public final static int TABLE_UPDATE_ARTICLE = 3;
    public final static int TABLE_UPDATE_CATEGORY = 4;
    public final static int TABLE_UPDATE_DOMAIN = 5;
    public final static int TABLE_UPDATE_FIRSTSUBDOMAIN = 6;
    public final static int TABLE_UPDATE_LATESTNEWSTABLE = 7;
    public final static int TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION = 8;
    public final static int TABLE_UPDATE_ARCHIVELATESTLOOKUP = 9;
    public final static int TABLE_UPDATE_ARCHIVELATESTPAGELOOKUP = 10;

    public final static String TABLE_UPDATE = "TABLEUPDATE";


    private final String TAG = FirebaseIntentService.class.getSimpleName();
    private FirebaseDatabase mFirebaseDatabase = null;
    private DatabaseReference mLatestNewsTableDatabaseReference;
    private static boolean mfirebasedatabasesetpersistenceenabledalready = false;
    private long mInitWriteTime;

    public final static String ARTICLELOOKUPTABLE = "articlelookuptable";
    public final static String ARTICLETABLE = "articletable";
    public final static String CATEGORYTABLE = "categorytable";
    public final static String DOMAINTABLE = "domaintable";
    public final static String FIRSTSUBDOMAINTABLE = "firstsubdomaintable";
    public final static String LATESTNEWSTABLE = "latestnewstable";
    public final static String LASTUPDATETIME = "lastupdatetime";
    public final static String NOOFENTRY = "noofentry";
    public final static String ENTRY = "entry";
    public final static String ARCHIVELATESTLOOKUP = "archivelatestnews";
    public final static String ARCHIVELATESTPAGELOOKUP = "pagearchivelatestnews";

    //childeventlistener
    private static ValueEventListener mArticleLookup_LastUpdateTime = null;
    private static ValueEventListener mArticleLookup_NoOfEntry = null;
    private static ValueEventListener mCategory_LastUpdateTime = null;
    private static ValueEventListener mCategory_NoOfEntry = null;
    private static ValueEventListener mDomain_LastUpdateTime = null;
    private static ValueEventListener mDomain_NoOfEntry = null;
    private static ValueEventListener mFirstSubdomain_LastUpdateTime = null;
    private static ValueEventListener mFirstSubdomain_NoOfEntry = null;
    private static ValueEventListener mLatestNewsPagination_LastUpdateTime = null;
    private static ValueEventListener mLatestNewsPagination_NoOfEntry = null;
    private static ValueEventListener mArchiveLatestLookup_LastUpdateTime = null;
    private static ValueEventListener mArchiveLatestLookup_NoOfEntry = null;
    private static ValueEventListener mArchiveLatestPageLookup_LastUpdateTime = null;
    private static ValueEventListener mArchiveLatestPageLookup_NoOfEntry = null;

    private static ValueEventListener mLatestNewsPagination_sectionentries = null;


    private void removeEventListner_ArticleLookupTable() {
        if (mArticleLookup_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(ARTICLELOOKUPTABLE)
                    .removeEventListener(mArticleLookup_LastUpdateTime);
        }
        if (mArticleLookup_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(ARTICLELOOKUPTABLE)
                    .removeEventListener(mArticleLookup_NoOfEntry);
        }
    }

    private void removeEventListner_ArchiveLatestLookup() {
        if (mArchiveLatestLookup_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTLOOKUP)
                    .removeEventListener(mArchiveLatestLookup_LastUpdateTime);
        }
        if (mArchiveLatestLookup_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTLOOKUP)
                    .removeEventListener(mArchiveLatestLookup_NoOfEntry);
        }
    }

    private void removeEventListner_ArchiveLatestPageLookup() {
        if (mArchiveLatestPageLookup_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTPAGELOOKUP)
                    .removeEventListener(mArchiveLatestLookup_LastUpdateTime);
        }
        if (mArchiveLatestLookup_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTLOOKUP)
                    .removeEventListener(mArchiveLatestLookup_NoOfEntry);
        }
    }

    private void removeEventListner_CategoryTable() {
        if (mCategory_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(CATEGORYTABLE)
                    .removeEventListener(mCategory_LastUpdateTime);
        }
        if (mCategory_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(CATEGORYTABLE)
                    .removeEventListener(mCategory_NoOfEntry);
        }

    }

    private void removeEventListner_DomainTable() {
        if (mDomain_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(DOMAINTABLE)
                    .removeEventListener(mDomain_LastUpdateTime);
        }
        if (mDomain_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(DOMAINTABLE)
                    .removeEventListener(mDomain_NoOfEntry);
        }

    }

    private void removeEventListner_FirstSubDomainTable() {
        if (mFirstSubdomain_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(FIRSTSUBDOMAINTABLE)
                    .removeEventListener(mFirstSubdomain_LastUpdateTime);
        }
        if (mFirstSubdomain_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(FIRSTSUBDOMAINTABLE)
                    .removeEventListener(mFirstSubdomain_NoOfEntry);
        }
    }

    private void removeEventListner_LatestNewsTable() {
        if (mLatestNewsPagination_LastUpdateTime != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .removeEventListener(mLatestNewsPagination_LastUpdateTime);
        }
        if (mLatestNewsPagination_NoOfEntry != null) {
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .removeEventListener(mLatestNewsPagination_NoOfEntry);
        }
    }



    private void removeEventListenerFromFirebase() {
        removeEventListner_ArticleLookupTable();
        removeEventListner_CategoryTable();
        removeEventListner_DomainTable();
        removeEventListner_FirstSubDomainTable();
        removeEventListner_LatestNewsTable();
        removeEventListner_ArchiveLatestLookup();
        removeEventListner_ArchiveLatestPageLookup();

    }

    private void setupEventListner_ArticleLookupTable() {
        if (mArticleLookup_LastUpdateTime == null) {

            mArticleLookup_LastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.ARTICLELOOKUP_LASTUPDATETIME_ID);
            FirebaseDatabase.getInstance().getReference()
                    .child(ARTICLELOOKUPTABLE)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mArticleLookup_LastUpdateTime);

        }
        if (mArticleLookup_NoOfEntry == null) {
            mArticleLookup_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.ARTICLELOOKUP_NOOFENTRY_ID);
            FirebaseDatabase.getInstance().getReference()
                    .child(ARTICLELOOKUPTABLE)
                    .child(NOOFENTRY)
                    .addValueEventListener(mArticleLookup_NoOfEntry);

        }

    }


    private void setupEventListner_ArchiveLatestLookup() {
        if (mArchiveLatestLookup_LastUpdateTime== null) {

            mArchiveLatestLookup_LastUpdateTime= GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.ARCHIVELATESTLOOKUP_LASTUPDATETIME_ID);
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTLOOKUP)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mArchiveLatestLookup_LastUpdateTime);

        }
        if (mArchiveLatestLookup_NoOfEntry == null) {
            mArchiveLatestLookup_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.ARCHIVELATESTLOOKUP_NOOFENTRY_ID);
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTLOOKUP)
                    .child(NOOFENTRY)
                    .addValueEventListener(mArchiveLatestLookup_NoOfEntry);

        }

    }


    private void setupEventListner_ArchiveLatestPageLookup() {
        if (mArchiveLatestPageLookup_LastUpdateTime== null) {

            mArchiveLatestPageLookup_LastUpdateTime= GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.ARCHIVELATESTPAGELOOKUP_LASTUPDATETIME_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTPAGELOOKUP)
                    .child(LASTUPDATETIME)
                    .addListenerForSingleValueEvent(mArchiveLatestPageLookup_LastUpdateTime);

        }
        if (mArchiveLatestPageLookup_NoOfEntry == null) {
            mArchiveLatestPageLookup_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.ARCHIVELATESTPAGELOOKUP_NOOFENTRY_ID,
                    true);
            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(ARCHIVELATESTPAGELOOKUP)
                    .child(NOOFENTRY)
                    .addListenerForSingleValueEvent(mArchiveLatestPageLookup_NoOfEntry);

        }

    }


    private void setupEventListner_CategoryTable() {
        if (mCategory_LastUpdateTime == null) {
            mCategory_LastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.CATEGORY_LASTUPDATETIME_ID);
            FirebaseDatabase.getInstance().getReference()
                    .child(CATEGORYTABLE)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mCategory_LastUpdateTime);

        }
        if (mCategory_NoOfEntry == null) {
            mCategory_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.CATEGORY_NOOFENTRY_ID);
            FirebaseDatabase.getInstance().getReference()
                    .child(CATEGORYTABLE)
                    .child(NOOFENTRY)
                    .addValueEventListener(mCategory_NoOfEntry);

        }

    }


    private void setupEventListner_DomainTable() {
        if (mDomain_LastUpdateTime == null) {
            mDomain_LastUpdateTime =  GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.DOMAIN_LASTUPDATETIME_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(DOMAINTABLE)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mDomain_LastUpdateTime);

        }
        if (mDomain_NoOfEntry == null) {
            mDomain_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.DOMAIN_NOOFENTRY_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(DOMAINTABLE)
                    .child(NOOFENTRY)
                    .addValueEventListener(mDomain_NoOfEntry);

        }

    }


    private void setupEventListner_FirstSubDomainTable() {
        if (mFirstSubdomain_LastUpdateTime == null) {
            mFirstSubdomain_LastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.FIRSTSUBDOMAIN_LASTUPDATETIME_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(FIRSTSUBDOMAINTABLE)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mFirstSubdomain_LastUpdateTime);

        }
        if (mFirstSubdomain_NoOfEntry == null) {
            mFirstSubdomain_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.FIRSTSUBDOMAIN_NOOFENTRY_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(FIRSTSUBDOMAINTABLE)
                    .child(NOOFENTRY)
                    .addValueEventListener(mFirstSubdomain_NoOfEntry);

        }

    }


    private void setupEventListner_LatestNewsTable() {
        if (mLatestNewsPagination_LastUpdateTime == null) {
            mLatestNewsPagination_LastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.LATESTNEWSPAGINATION_LASTUPDATETIME_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mLatestNewsPagination_LastUpdateTime);

        }
        if (mLatestNewsPagination_NoOfEntry == null) {
            mLatestNewsPagination_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.LATESTNEWSPAGINATION_NOOFENTRY_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(NOOFENTRY)
                    .addValueEventListener(mLatestNewsPagination_NoOfEntry);

        }

    }


    private void setupEventListner_LatestNewsTableArchivePagination() {
        if (mLatestNewsPagination_LastUpdateTime == null) {
            mLatestNewsPagination_LastUpdateTime = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.LATESTNEWSPAGINATION_LASTUPDATETIME_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(LASTUPDATETIME)
                    .addValueEventListener(mLatestNewsPagination_LastUpdateTime);

        }
        if (mLatestNewsPagination_NoOfEntry == null) {
            mLatestNewsPagination_NoOfEntry = GongValueEventListener.get_TableValueEventListener(
                    getApplicationContext(),
                    GongPreference.LATESTNEWSPAGINATION_NOOFENTRY_ID);

            FirebaseDatabase.getInstance().getReference()
                    .child(LATESTNEWSTABLE)
                    .child(NOOFENTRY)
                    .addValueEventListener(mLatestNewsPagination_NoOfEntry);

        }

    }



    private void setupEventListnerForFirebase() {
        setupEventListner_ArticleLookupTable();
        setupEventListner_CategoryTable();
        setupEventListner_DomainTable();
        setupEventListner_FirstSubDomainTable();
        setupEventListner_LatestNewsTable();
        setupEventListner_ArchiveLatestLookup();
        setupEventListner_ArchiveLatestPageLookup();
    }


    synchronized public static void setPersistenceenabledIfNot () {
        if (mfirebasedatabasesetpersistenceenabledalready == false){
            mfirebasedatabasesetpersistenceenabledalready = true;
            FirebaseDatabase.getInstance().setPersistenceEnabled(false);
        }

    }

    public static boolean getPersistenceenabled() {
        return mfirebasedatabasesetpersistenceenabledalready;
    }

    public FirebaseIntentService() {
        super("FirebaseIntentService");
        LogUtil.debug(TAG, "--> in FirebaseIntentService constructor");
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        setPersistenceenabledIfNot();
        mFirebaseDatabase.getReference().keepSynced(true);
        mInitWriteTime=System.currentTimeMillis();

        mFirebaseDatabase.getReference().child(String.valueOf(mInitWriteTime)).setValue(true, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                //it will fail because no permission on that node
                LogUtil.debug(TAG, " mInitWriteTime 1 onComplete " + databaseError.getDetails());
                LogUtil.debug(TAG, "mInitWriteTime 2 onComplete " + databaseReference.getKey());
                mFirebaseDatabase.getReference().child(String.valueOf(mInitWriteTime)).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        LogUtil.debug (TAG, " mInitWriteTime 3 onComplete onDataChange=" + dataSnapshot.getKey());
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        LogUtil.debug(TAG, " mInitWriteTime 4 onComplete onCancelled=" + databaseError.getDetails());

                    }
                });

                mFirebaseDatabase.getReference().child(String.valueOf(mInitWriteTime))
                        .removeValue((databaseError1, databaseReference1)
                                -> { LogUtil.debug(TAG, "mInitWriteTime 5 onComplete " + databaseError1.getDetails());});
            }
        });

        mLatestNewsTableDatabaseReference = mFirebaseDatabase.getReference().child("latestnewstable");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        LogUtil.debug(TAG, "--> in FirebaseIntentService onHandleIntent");
        String paginationsection = intent.getStringExtra("section");
        LogUtil.debug(TAG, "--> in FirebaseIntentService onHandleIntent paginationsection=" + paginationsection);
        int table_update = intent.getIntExtra(TABLE_UPDATE, TABLE_UPDATE_UNKNOWN);
        LogUtil.debug(TAG, "--> in FirebaseIntentService onHandleIntent table_update=" + table_update);

        /*
        Parcelable parcelable = intent.getParcelableExtra("cursorwindow");
        AbstractWindowedCursor abstractWindowedCursor = new AbstractWindowedCursor() {
            @Override
            public int getCount() {
                LogUtil.debug(TAG, "inside AbstractWindowedCursor ");
                return 2;
            }

            @Override
            public String[] getColumnNames() {

                return new String[] {"columnone", "columntwo","columnthree"};
            }
        };
        abstractWindowedCursor.setWindow((CursorWindow)parcelable);
        Cursor cursor = abstractWindowedCursor;
        cursor.moveToPosition(1);
        String columnzerotwo = cursor.getString(1);
        */

        //GSheetQuery mGSheetQuery;
        //mGSheetQuery = new GSheetQuery(this);
        //mGSheetQuery.test_getdatafromapi();

        switch (table_update) {
            case TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION: {
                DatabaseReference reference = mLatestNewsTableDatabaseReference.child("pagination").child(paginationsection);
                //reference.keepSynced(true);

                mLatestNewsPagination_sectionentries = new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        LogUtil.debug(TAG, "FirebaseIntentService ondatachange datasnapshot.getkey=" + dataSnapshot.getKey());
                        LogUtil.debug(TAG, "FirebaseIntentService ondatachange datasnapshot.getChildcount=" + dataSnapshot.getChildrenCount());
                        LogUtil.debug(TAG, "FirebaseIntentService ondatachange datasnapshot.getChildcount=" + dataSnapshot.getValue());
                        if (dataSnapshot.getChildrenCount() > 0) {
                            Map<String, Object> maindata = (Map<String, Object>) dataSnapshot.getValue();
                            ContentValues[] articleentryvalues;
                            ContentValues singlearticleentryvalue;
                            int noofentry = ((Long) ((HashMap<String, Object>) dataSnapshot.getValue()).get("noofentry")).intValue();
                            if (noofentry > 0) {
                                articleentryvalues = new ContentValues[noofentry];
                                Map<String, Object> entrymap = (Map<String, Object>) (((HashMap<String, Object>) dataSnapshot.getValue()).get("entry"));

                                int count = 0;
                                for (Map.Entry<String, Object> indrelatedata : entrymap.entrySet()) {
                                    LogUtil.debug(TAG, "--> key = " + indrelatedata.getKey());
                                    singlearticleentryvalue = new ContentValues();
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE,
                                            (String) ((Map<String, Object>) indrelatedata.getValue()).get("title"));
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL,
                                            (String) ((Map<String, Object>) indrelatedata.getValue()).get("finalurl"));
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL,
                                            (String) ((Map<String, Object>) indrelatedata.getValue()).get("imageurl"));
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC_AND_ID,
                                            (String) (indrelatedata.getKey()));
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                                            (Long) ((Map<String, Object>) indrelatedata.getValue()).get("firstsubdomaintable_id"));
                                    long article_id = Long.valueOf(LatestNewsPaginationContract.PaginationEntry
                                            .decodeGetId((String)(indrelatedata.getKey())));
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_ARTICLEID,
                                            article_id);
                                    long timestampondoc = Long.valueOf(LatestNewsPaginationContract.PaginationEntry
                                            .decodeGetTimestampondoc((String)(indrelatedata.getKey())));
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC,
                                            timestampondoc);

                                    long similaritiescount = (long) ((Map<String, Object>) indrelatedata.getValue()).get("similaritiescount");
                                    singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_SIMILARITIESCOUNT,
                                            similaritiescount);
                                    if (similaritiescount > 0) {
                                        JSONObject json = new JSONObject(
                                                (Map<String, Object>) ((Map<String, Object>) indrelatedata.getValue()).get("entry")
                                        );
                                        singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_ENTRY,
                                                json.toString());


                                    } else {
                                        singlearticleentryvalue.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_ENTRY,
                                                "EMPTYENTRY");
                                    }
                                    articleentryvalues[count++] = singlearticleentryvalue;
                                }
                                ContentResolver contentResolver = getApplicationContext().getContentResolver();

                                int result = 0;
                                String keyname = dataSnapshot.getKey();
                                if (keyname.split("to")[0].compareTo("1") == 0) {
                                    result = contentResolver.delete(
                                            LatestNewsPaginationContract.PaginationEntry.CONTENT_URI,
                                            null,
                                            null);
                                    LogUtil.debug(TAG, "FirebaseIntentService TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION ondatachange DONE DELETE result =" + result);
                                }
                                result = contentResolver.bulkInsert(
                                        LatestNewsPaginationContract.PaginationEntry.CONTENT_URI,
                                        articleentryvalues);

                                LogUtil.debug(TAG, "FirebaseIntentService TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION ondatachange DONE INSERT result =" + result);
                            }
                        }
                        reference.removeEventListener(mLatestNewsPagination_sectionentries);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        LogUtil.debug(TAG, "FirebaseIntentService oncancelled");
                    }

                };

                reference.addListenerForSingleValueEvent(mLatestNewsPagination_sectionentries);
                break;
            }
            case TABLE_UPDATE_INITIAL:
                setupEventListnerForFirebase();
                break;

            case TABLE_UPDATE_ARTICLELOOKUP:
                setupEventListner_ArticleLookupTable();
                break;

            case TABLE_UPDATE_CATEGORY:
                setupEventListner_CategoryTable();
                break;

            case TABLE_UPDATE_DOMAIN:
                setupEventListner_DomainTable();
                break;

            case TABLE_UPDATE_FIRSTSUBDOMAIN:
                setupEventListner_FirstSubDomainTable();
                break;

            case TABLE_UPDATE_LATESTNEWSTABLE:
                setupEventListner_LatestNewsTable();
                break;

            case TABLE_UPDATE_ARCHIVELATESTLOOKUP:
                setupEventListner_ArchiveLatestLookup();
                break;

            case TABLE_UPDATE_ARCHIVELATESTPAGELOOKUP:
                setupEventListner_ArchiveLatestPageLookup();
                break;



            default:
                break;
        }

    }



}

