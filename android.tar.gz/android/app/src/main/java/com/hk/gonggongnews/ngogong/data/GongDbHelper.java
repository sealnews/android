package com.hk.gonggongnews.ngogong.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by ismile on 10/11/2017.
 */


/**
 * Manages a local database for weather data.
 */
public class GongDbHelper extends SQLiteOpenHelper {

    /*
     * This is the name of our database. Database names should be descriptive and end with the
     * .db extension.
     */
    public static final String DATABASE_NAME = "ngogong.db";

    /*
     * If you change the database schema, you must increment the database version or the onUpgrade
     * method will not be called.
     *
     * The reason DATABASE_VERSION starts at 3 is because Sunshine has been used in conjunction
     * with the Android course for a while now. Believe it or not, older versions of Sunshine
     * still exist out in the wild. If we started this DATABASE_VERSION off at 1, upgrading older
     * versions of Sunshine could cause everything to break. Although that is certainly a rare
     * use-case, we wanted to watch out for it and warn you what could happen if you mistakenly
     * version your databases.
     */
    private static final int DATABASE_VERSION = 1;

    public GongDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time. This is where the creation of
     * tables and the initial population of the tables should happen.
     *
     * @param sqLiteDatabase The database.
     */
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {


        final String SQL_CREATE_PAGINATION_TABLE =

                "CREATE TABLE " + LatestNewsPaginationContract.PaginationEntry.TABLE_NAME + " (" +

                        LatestNewsPaginationContract.PaginationEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC + " INTEGER, " +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_ARTICLEID + " INTEGER, " +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_ENTRY       + " STRING, "                 +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL    + " STRING, "                 +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID    + " INTEGER , "                 +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL    + " STRING, "                 +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_SIMILARITIESCOUNT    + " INTEGER DEFAULT 0, "                 +
                        LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC_AND_ID    + " STRING, "                 +

                        LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE       + " STRING,  " +
                        " UNIQUE ( " + LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL +
                        " , " + LatestNewsPaginationContract.PaginationEntry.COLUMN_ARTICLEID + " ) ON CONFLICT REPLACE "
                        +" ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_PAGINATION_TABLE);

        final String SQL_CREATE_PAGINATION_ARCHIVE_TABLE =

                "CREATE TABLE " + LatestNewsPaginationArcContract.PaginationArcEntry.TABLE_NAME + " (" +

                        LatestNewsPaginationArcContract.PaginationArcEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_TIMESTAMPONDOC + " INTEGER, " +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_ARTICLEID + " INTEGER, " +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_ENTRY       + " STRING, "                 +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_FINALURL    + " STRING, "                 +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID    + " INTEGER , "                 +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_IMAGEURL    + " STRING, "                 +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_SIMILARITIESCOUNT    + " INTEGER DEFAULT 0, "                 +
                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_TIMESTAMPONDOC_AND_ID    + " STRING, "                 +

                        LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_TITLE       + " STRING ," +

                        " UNIQUE ( " + LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_FINALURL +
                        " , " + LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_ARTICLEID + " ) ON CONFLICT REPLACE "
                        + " ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_PAGINATION_ARCHIVE_TABLE);



        final String SQL_CREATE_CATEGORY_TABLE =

                "CREATE TABLE " + CategoryTableContract.CategoryEntry.TABLE_NAME + " (" +

                        CategoryTableContract.CategoryEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        CategoryTableContract.CategoryEntry.COLUMN_CATEGORYTABLE_ID    + " INTEGER NOT NULL, "                 +
                        CategoryTableContract.CategoryEntry.COLUMN_CHI_NAME+ " STRING, "                 +
                        CategoryTableContract.CategoryEntry.COLUMN_ENG_NAME+ " STRING ); " ;

        sqLiteDatabase.execSQL(SQL_CREATE_CATEGORY_TABLE);


        final String SQL_CREATE_DOMAIN_TABLE =

                "CREATE TABLE " + DomainTableContract.DomainEntry.TABLE_NAME + " (" +

                        DomainTableContract.DomainEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        DomainTableContract.DomainEntry.COLUMN_DOMAINTABLE_ID    + " INTEGER NOT NULL, "                 +
                        DomainTableContract.DomainEntry.COLUMN_BASEURL  + " STRING, "                 +
                        DomainTableContract.DomainEntry.COLUMN_CHI_NAME  + " STRING, "                 +
                        DomainTableContract.DomainEntry.COLUMN_ENG_NAME + " STRING ); " ;

        sqLiteDatabase.execSQL(SQL_CREATE_DOMAIN_TABLE);


        final String SQL_CREATE_FIRSTSUBDOMAIN_TABLE =

                "CREATE TABLE " + FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME + " (" +

                        FirstSubdomainTableContract.FirstSubdomainEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID + " INTEGER , "  +
                        FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_DOMAINTABLE_ID + " INTEGER, "                 +
                        FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_CATEGORYTABLE_ID + " INTEGER, " +
                        FirstSubdomainTableContract.FirstSubdomainEntry.COLUMN_SOURCEICONURL + " STRING );  ";

        sqLiteDatabase.execSQL(SQL_CREATE_FIRSTSUBDOMAIN_TABLE);

        final String SQL_CREATE_SIGNAL_TABLE =

                "CREATE TABLE " + SignalContract.SignalEntry.TABLE_NAME + " (" +

                        SignalContract.SignalEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " INTEGER , " +
                        SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY + " INTEGER DEFAULT 0, " +
                        SignalContract.SignalEntry.COLUMN_READALREADY + " INTEGER DEFAULT 0, " +
                        SignalContract.SignalEntry.COLUMN_TIMESTAMPONDOC + " INTEGER ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_SIGNAL_TABLE);

        final String SQL_CREATE_ARTICLELOOKUP_TABLE =

                "CREATE TABLE " + ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME + " (" +

                        ArticleLookupTableContract.ArticleLookupEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ArticleLookupTableContract.ArticleLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID + " INTEGER, " +
                        ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID + " STRING, "  +
                        ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID_URL + " STRING ); ";
        sqLiteDatabase.execSQL(SQL_CREATE_ARTICLELOOKUP_TABLE);


        final String SQL_CREATE_ARTICLE_TABLE =
                "CREATE TABLE " + ArticleTableContract.ArticleEntry.TABLE_NAME + " (" +

                        ArticleTableContract.ArticleEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " INTEGER, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID + " INTEGER, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_FINALURL  + " STRING, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_TIMESTAMPONDOC  + " INTEGER, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_TIMESTAMPONRETRIEVE + " INTEGER, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_TITLE + " STRING, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_CONTENT + " STRING, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_IMAGEURL + " STRING, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_SIMILARITIESLIST + " STRING, "  +
                        ArticleTableContract.ArticleEntry.COLUMN_SIMILARITIESCOUNT + " INTEGER , " +

                        " UNIQUE ( " + ArticleTableContract.ArticleEntry.COLUMN_FINALURL +
                        " , " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " ) ON CONFLICT REPLACE "
                        + " ); ";

         sqLiteDatabase.execSQL(SQL_CREATE_ARTICLE_TABLE);



        final String SQL_CREATE_ARCHIVELATESTLOOKUP_TABLE =

                "CREATE TABLE " + ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME + " (" +

                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID + " INTEGER, " +
                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID + " STRING, "  +
                        ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID_URL + " STRING ); ";
        sqLiteDatabase.execSQL(SQL_CREATE_ARCHIVELATESTLOOKUP_TABLE);


        final String SQL_CREATE_ARCHIVELATESTPAGELOOKUP_TABLE =

                "CREATE TABLE " + ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME + " (" +

                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID + " INTEGER, " +
                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID + " STRING, "  +
                        ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID_URL + " STRING ); ";
        sqLiteDatabase.execSQL(SQL_CREATE_ARCHIVELATESTPAGELOOKUP_TABLE);



        final String SQL_CREATE_GONGINFO_TABLE =

                "CREATE TABLE " + GongInfoContract.GongInfoEntry.TABLE_NAME + " (" +

                        GongInfoContract.GongInfoEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        GongInfoContract.GongInfoEntry.COLUMN_TIMESTAMPONDOC + " INTEGER, " +
                        GongInfoContract.GongInfoEntry.COLUMN_ARTICLEID + " INTEGER, " +
                        GongInfoContract.GongInfoEntry.COLUMN_ENTRY       + " STRING, "                 +
                        GongInfoContract.GongInfoEntry.COLUMN_FINALURL    + " STRING, "                 +
                        GongInfoContract.GongInfoEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID    + " INTEGER , "                 +
                        GongInfoContract.GongInfoEntry.COLUMN_IMAGEURL    + " STRING, "                 +
                        GongInfoContract.GongInfoEntry.COLUMN_SIMILARITIESCOUNT    + " INTEGER DEFAULT 0, "                 +
                        GongInfoContract.GongInfoEntry.COLUMN_TIMESTAMPONDOC_AND_ID    + " STRING, "                 +
                        GongInfoContract.GongInfoEntry.COLUMN_NAME + " STRING, "                 +

                        GongInfoContract.GongInfoEntry.COLUMN_TITLE       + " STRING , " +
                        " UNIQUE ( " + GongInfoContract.GongInfoEntry.COLUMN_NAME +
                        " , " + GongInfoContract.GongInfoEntry.COLUMN_ARTICLEID + " ) ON CONFLICT REPLACE "
                        +" ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_GONGINFO_TABLE);

        final String SQL_CREATE_GONGINFOLOOKUP_TABLE =

                "CREATE TABLE " + GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME + " (" +

                        GongInfoLookupContract.GongInfoLookupEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_TYPE + " STRING, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_NAME + " STRING, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_ID + " INTEGER, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SOURCEICONURL + " STRING, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_NOOFENTRY + " INTEGER, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_LASTUPDATETIME + " INTEGER, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SHEETID + " STRING, "  +
                        GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SHEETID_URL + " STRING ); ";
        sqLiteDatabase.execSQL(SQL_CREATE_GONGINFOLOOKUP_TABLE);


        final String SQL_CREATE_FRAGARTICLE_TABLE =

                "CREATE TABLE " + FragArticleTableContract.FragArticleEntry.TABLE_NAME + " (" +

                        FragArticleTableContract.FragArticleEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        FragArticleTableContract.FragArticleEntry.COLUMN_TIMESTAMPONDOC + " INTEGER, " +
                        FragArticleTableContract.FragArticleEntry.COLUMN_ARTICLEID + " INTEGER, " +
                        FragArticleTableContract.FragArticleEntry.COLUMN_ENTRY       + " STRING, "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_FINALURL    + " STRING, "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID    + " INTEGER , "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_IMAGEURL    + " STRING, "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_SIMILARITIESCOUNT    + " INTEGER DEFAULT 0, "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_TIMESTAMPONDOC_AND_ID    + " STRING, "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_NAME + " STRING, "                 +
                        FragArticleTableContract.FragArticleEntry.COLUMN_CATEGORYTABLE_ID    + " INTEGER , "                 +

                        FragArticleTableContract.FragArticleEntry.COLUMN_TITLE       + " STRING , " +
                        " UNIQUE ( " + FragArticleTableContract.FragArticleEntry.COLUMN_NAME +
                        " , " + FragArticleTableContract.FragArticleEntry.COLUMN_ARTICLEID + " ) ON CONFLICT REPLACE "
                        +" ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_FRAGARTICLE_TABLE);


        final String SQL_CREATE_FRAGARTICLEARC_TABLE =

                "CREATE TABLE " + FragArticleArcTableContract.FragArticleArcEntry.TABLE_NAME + " (" +

                        FragArticleArcTableContract.FragArticleArcEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_TIMESTAMPONDOC + " INTEGER, " +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_ARTICLEID + " INTEGER, " +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_ENTRY       + " STRING, "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_FINALURL    + " STRING, "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID    + " INTEGER , "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_IMAGEURL    + " STRING, "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_SIMILARITIESCOUNT    + " INTEGER DEFAULT 0, "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_TIMESTAMPONDOC_AND_ID    + " STRING, "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_NAME + " STRING, "                 +
                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_CATEGORYTABLE_ID    + " INTEGER , "                 +

                        FragArticleArcTableContract.FragArticleArcEntry.COLUMN_TITLE       + " STRING , " +
                        " UNIQUE ( " + FragArticleArcTableContract.FragArticleArcEntry.COLUMN_NAME +
                        " , " + FragArticleArcTableContract.FragArticleArcEntry.COLUMN_ARTICLEID + " ) ON CONFLICT REPLACE "
                        +" ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_FRAGARTICLEARC_TABLE);



        final String SQL_CREATE_FRAGLOOKUP_TABLE =

                "CREATE TABLE " + FragLookupTableContract.FragLookupEntry.TABLE_NAME + " (" +

                        FragLookupTableContract.FragLookupEntry._ID               + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        FragLookupTableContract.FragLookupEntry.COLUMN_NAME + " STRING, "  +
                        FragLookupTableContract.FragLookupEntry.COLUMN_CATEGORYTABLE_ID + " INTEGER, "  +
                        FragLookupTableContract.FragLookupEntry.COLUMN_NOOFENTRY + " INTEGER, "  +
                        FragLookupTableContract.FragLookupEntry.COLUMN_LASTUPDATETIME + " INTEGER, "  +
                        FragLookupTableContract.FragLookupEntry.COLUMN_SHEETID + " STRING, "  +
                        FragLookupTableContract.FragLookupEntry.COLUMN_SHEETID_URL + " STRING,  " +

                        " UNIQUE ( " + FragLookupTableContract.FragLookupEntry.COLUMN_SHEETID +
                        " , " + FragLookupTableContract.FragLookupEntry.COLUMN_NAME + " ) ON CONFLICT REPLACE "
                        + " ); ";

        sqLiteDatabase.execSQL(SQL_CREATE_FRAGLOOKUP_TABLE);




    }

    /**
     * This database is only a cache for online data, so its upgrade policy is simply to discard
     * the data and call through to onCreate to recreate the table. Note that this only fires if
     * you change the version number for your database (in our case, DATABASE_VERSION). It does NOT
     * depend on the version number for your application found in your app/build.gradle file. If
     * you want to update the schema without wiping data, commenting out the current body of this
     * method should be your top priority before modifying this method.
     *
     * @param sqLiteDatabase Database that is being upgraded
     * @param oldVersion     The old database version
     * @param newVersion     The new database version
     */
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + LatestNewsPaginationContract.PaginationEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + LatestNewsPaginationArcContract.PaginationArcEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + CategoryTableContract.CategoryEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + DomainTableContract.DomainEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + FirstSubdomainTableContract.FirstSubdomainEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ArticleLookupTableContract.ArticleLookupEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ArticleTableContract.ArticleEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SignalContract.SignalEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ArchiveLatestLookupContract.ArchiveLatestLookupEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + GongInfoContract.GongInfoEntry.TABLE_NAME);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + GongInfoLookupContract.GongInfoLookupEntry.TABLE_NAME);


        onCreate(sqLiteDatabase);
    }
}
