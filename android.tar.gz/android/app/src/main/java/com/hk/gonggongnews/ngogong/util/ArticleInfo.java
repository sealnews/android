package com.hk.gonggongnews.ngogong.util;

import android.support.annotation.NonNull;

import com.hk.gonggongnews.ngogong.data.SourceInfo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * Created by ismile on 10/26/2017.
 */

public class ArticleInfo {

    private int mFirstsubdomaintable_id;
    private String mTitle;
    private String mImageurl;
    private int mID;
    private String mFinalurl;
    private int mTimestampondoc;
    private int mSignalBitmap;

    public ArticleInfo ( int firstsub_id ,
                         String title,
                         String imageurl,
                         int id,
                         String finalurl,
                         int timestampondoc,
                         int signalBitmap
    ){
        mFirstsubdomaintable_id = firstsub_id;
        mTitle = title;
        mImageurl = imageurl;
        mID = id;
        mFinalurl = finalurl;
        mTimestampondoc = timestampondoc;
        mSignalBitmap=signalBitmap;

    }

    public ArticleInfo ( int firstsub_id ,
                         String title,
                         String imageurl,
                         int id,
                         String finalurl,
                         int timestampondoc
                         ){
        mFirstsubdomaintable_id = firstsub_id;
        mTitle = title;
        mImageurl = imageurl;
        mID = id;
        mFinalurl = finalurl;
        mTimestampondoc = timestampondoc;
        mSignalBitmap=0;

    }

    public int getDomainID (){
        return SourceInfo.getInstance().getDomainID(this.mFirstsubdomaintable_id);
    }

    public int getFirstsubdomaintable_id () {
        return mFirstsubdomaintable_id;
    }

    public String getTitle () {
        return mTitle;
    }

    public String getImageurl (){
        return mImageurl;
    }

    public int getID () {
        return mID;
    }

    public String getFinalurl () {
        return mFinalurl;
    }

    public int getTimestampondoc (){
        return mTimestampondoc;
    }

    public int getSignalBitmap (){
        return mSignalBitmap;
    }


    public static List<ArticleInfo> sortByPreferredDomain (List<ArticleInfo> articleInfoList , List<Integer> preferredlistorder ){
        List<ArticleInfo> aList = new ArrayList<ArticleInfo>();

        for (int x : preferredlistorder){
            for (ArticleInfo ind_aInfo : articleInfoList){
                if (ind_aInfo.getDomainID() == x){
                    aList.add(ind_aInfo);
                }
            }
        }

        return aList;
    }


}
