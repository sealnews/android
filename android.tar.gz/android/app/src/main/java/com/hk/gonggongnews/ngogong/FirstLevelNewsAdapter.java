package com.hk.gonggongnews.ngogong;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.util.ArticleInfo;
import com.hk.gonggongnews.ngogong.util.GongTimeUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

/**
 * Created by ismile on 11/28/2017.
 */

public class FirstLevelNewsAdapter  extends
        RecyclerView.Adapter<FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder> {

    private final String TAG = FirstLevelNewsAdapter.class.getSimpleName();

    /* The context we use to utility methods, app resources and layout inflaters */
    private final Context mContext;

    private View.OnClickListener mcallDetailActivity;
    private View.OnClickListener mshareClickListener;
    private View.OnClickListener mbookmarkClickListener;
    private Map<Integer, Integer> mSignalMap;
    public final static int BOOKMARKALREADY_MASK = 0x0001;
    public final static int READALREADY_MASK = 0x0002;
    public final static int EXPANDALREADY_MASK = 0x0004;

    private boolean mInitupdateSignalMapFromCursor;
    private Cursor mCursor;
    private boolean mUsingSelectedArchivetoDisplay;


    /*
     * Below, we've defined an interface to handle clicks on items within this Adapter. In the
     * constructor of our ForecastAdapter, we receive an instance of a class that has implemented
     * said interface. We store that instance in this variable to call the onClick method whenever
     * an item is clicked in the list.
     */
    private FirstLevelNewsAdapter.FirstLevelNewsAdapterOnClickHandler mClickHandler;

    /**
     * The interface that receives onClick messages.
     */
    public interface FirstLevelNewsAdapterOnClickHandler {
        void onClickDetailNews(long entryID, String finalurl);
        void onClickExpandNews(String jsonArticleList, String jsonSignalbit);
        void onClickBookmarkArticleStoreOrRemove (long entryID, boolean save);
    }



    /**
     * Creates a ForecastAdapter.
     *
     * @param context      Used to talk to the UI and app resources
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */

    public FirstLevelNewsAdapter(@NonNull Context context,
                                       FirstLevelNewsAdapter.FirstLevelNewsAdapterOnClickHandler clickHandler) {
        mContext = context;
        mClickHandler = clickHandler;
        mSignalMap = new HashMap<Integer, Integer>();






        mcallDetailActivity = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int articleID = (int) view.getTag(R.string.VIEWTAG_ARTICLEID);
                String finalurl = (String) view.getTag(R.string.VIEWTAG_FINALURL);
                int readalready_inmap = 0;
                int bitvalBookRead = 0;
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, articleID);
                if (mSignalMap.containsKey(articleID)) {
                    bitvalBookRead = mSignalMap.get(articleID);
                }
                readalready_inmap = bitvalBookRead | READALREADY_MASK;
                mSignalMap.put(articleID, readalready_inmap);
                contentValues.put(SignalContract.SignalEntry.COLUMN_READALREADY, 1);
                mContext.getContentResolver().insert(
                        uri,
                        contentValues);


                //set the background color
                ViewGroup twoupLevelLayout = ((ViewGroup) ((ViewGroup) view.getParent()).getParent());
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }
                if (view.getTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID) != null){
                    twoupLevelLayout.findViewById(
                            (int) view.getTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID))
                            .setBackgroundResource(R.color.after_reading_color);
                }

                //should start detailactivity if available
                LogUtil.debug(TAG, "---------------------> starting detail activity articleid="
                        + articleID
                        + ",finalurl="
                        + finalurl);
                mClickHandler.onClickDetailNews(articleID,finalurl);
            }
        };
        mbookmarkClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int bookmarkalready_inmap = 0;
                int bitvalBookRead = 0;
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;
                int articleID = (int) view.getTag(R.string.VIEWTAG_ARTICLEID);

                LogUtil.debug(TAG, " ib_bookmarkButton onclick 1");
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, articleID);

                if (view.isSelected() == false) {
                    view.setSelected(true);

                    if (mSignalMap.containsKey(articleID)) {
                        bitvalBookRead = mSignalMap.get(articleID);
                    }
                    bookmarkalready_inmap = bitvalBookRead | BOOKMARKALREADY_MASK;
                    mSignalMap.put(articleID, bookmarkalready_inmap);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 1);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 2 = bitvalBookRead"
                            + bitvalBookRead
                            + ", bookmarkalready_inmap="
                            + bookmarkalready_inmap);
                    mClickHandler.onClickBookmarkArticleStoreOrRemove(articleID, true);



                } else {
                    //set it off
                    view.setSelected(false);

                    if (mSignalMap.containsKey(articleID)) {
                        bitvalBookRead = mSignalMap.get(articleID);
                    }
                    bookmarkalready_inmap = bitvalBookRead & ~BOOKMARKALREADY_MASK;
                    mSignalMap.put(articleID, bookmarkalready_inmap);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 0);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 3 = bitvalBookRead"
                            + bitvalBookRead
                            + ", bookmarkalready_inmap="
                            + bookmarkalready_inmap);
                    mClickHandler.onClickBookmarkArticleStoreOrRemove(articleID, false);

                }
                mContext.getContentResolver().insert(
                        uri,
                        contentValues);
            }
        };


        mshareClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LogUtil.debug(TAG, " ib_sharebutton 1");
                String finalurl = (String) view.getTag(R.string.VIEWTAG_FINALURL);
                String title = (String) view.getTag(R.string.VIEWTAG_TITLE);

                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = title + "\n" + finalurl;
                String shareSub = title;
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                mContext.startActivity(Intent.createChooser(sharingIntent, "Share using"));
                LogUtil.debug(TAG, " ib_sharebutton 2");

            }
        };
        LogUtil.debug (TAG, " FirstLevelNewsAdapter constructor ");
    }



    /**
     * This gets called when each new ViewHolder is created. This happens when the RecyclerView
     * is laid out. Enough ViewHolders will be created to fill the screen and allow for scrolling.
     *
     * @param viewGroup The ViewGroup that these ViewHolders are contained within.
     * @param viewType  If your RecyclerView has more than one type of item (like ours does) you
     *                  can use this viewType integer to provide a different layout. See
     *                  {@link android.support.v7.widget.RecyclerView.Adapter#getItemViewType(int)}
     *                  for more details.
     * @return A new ForecastAdapterViewHolder that holds the View for each list item
     */
    @Override
    public FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder
    onCreateViewHolder(ViewGroup viewGroup, int viewType) {

        int layoutId;
        View view;

        layoutId = R.layout.article_list_item;
        view = LayoutInflater.from(mContext).inflate(layoutId, viewGroup, false);

        view.setFocusable(true);
        LogUtil.debug(TAG, "FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder  onCreateViewHolder");

        return new FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder(view);

    }

    /**
     * OnBindViewHolder is called by the RecyclerView to display the data at the specified
     * position. In this method, we update the contents of the ViewHolder to display the weather
     * details for this particular position, using the "position" argument that is conveniently
     * passed into us.
     *
     * @param FirstLevelNewsAdapterViewHolder The ViewHolder which should be updated to represent the
     *                                  contents of the item at the given position in the data set.
     * @param position                  The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder FirstLevelNewsAdapterViewHolder,
                                 int position) {
        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 1 " + position );
        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 1.1 cursor.uri=" + mCursor.getNotificationUri());
        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 1.2 cursor.count=" + mCursor.getCount());
        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 1.3 cursor=" + mCursor);

        mCursor.moveToPosition(position);


        final int articlePrimaryID = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_ARTICLE_ID);
        final String finalurl = mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FINALURL);




        if (mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL)
                .compareTo("EMPTYSTRINGVALUE") ==0) {
            FirstLevelNewsAdapterViewHolder.itemthumbnailView.setImageResource(R.drawable.ic_logo_hourglass_question);
        } else {
            GlideApp.with(mContext)
                    .load(mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL) )
                    .placeholder(R.drawable.ic_tmp_icon)
                    .fitCenter()
                    .into(FirstLevelNewsAdapterViewHolder.itemthumbnailView);
        }
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setOnClickListener(mcallDetailActivity);
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        FirstLevelNewsAdapterViewHolder.itemthumbnailView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


        int pagination_firstsubdomainid = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FIRSTSUBDOMAINTABLE_ID);
        ArrayList<String> sourceIconURLChiName = SourceInfo.getInstance()
                .getSourceIconURLAndName(pagination_firstsubdomainid);

        GlideApp.with(mContext)
                .load(sourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                .placeholder(R.drawable.ic_tmp_icon)
                .fitCenter()
                .into(FirstLevelNewsAdapterViewHolder.newsourceiconView);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setOnClickListener(mcallDetailActivity);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        FirstLevelNewsAdapterViewHolder.newsourceiconView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);


        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 2 ");


        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setText(sourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setOnClickListener(mcallDetailActivity);
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        FirstLevelNewsAdapterViewHolder.tv_domainsourceView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);




        int bookmarkalready = 0 ;
        if (mCursor.isNull(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_BOOKMARKALREADY) != true) {
            bookmarkalready = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_BOOKMARKALREADY);
        }
        int readalready = 0 ;
        if (mCursor.isNull(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_READALREADY) != true) {
            readalready = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_SIGNAL_READALREADY);
        }

        int bookmarkalready_inmap = 0;
        int readalready_inmap = 0;
        int bitvalBookRead = 0;

        if (mSignalMap.containsKey(articlePrimaryID) ){
            bitvalBookRead = mSignalMap.get(articlePrimaryID);
            bookmarkalready_inmap = bitvalBookRead & BOOKMARKALREADY_MASK;
            readalready_inmap = bitvalBookRead & READALREADY_MASK;
        } else {
            mSignalMap.put(articlePrimaryID, bookmarkalready | readalready);
        }

        if (   (bookmarkalready != 0)
                ||(bookmarkalready_inmap != 0)){
            FirstLevelNewsAdapterViewHolder.ib_bookmarkButton.setSelected(true);
        } else {
            FirstLevelNewsAdapterViewHolder.ib_bookmarkButton.setSelected(false);
        }
        if (   (readalready != 0)
                ||(readalready_inmap != 0)){
            FirstLevelNewsAdapterViewHolder.ib_bookmarkButton.setBackgroundResource(R.color.after_reading_color);
            FirstLevelNewsAdapterViewHolder.ib_shareButton.setBackgroundResource(R.color.after_reading_color);
            FirstLevelNewsAdapterViewHolder.ib_expandlessButton.setBackgroundResource(R.color.after_reading_color);
            ((ViewGroup)FirstLevelNewsAdapterViewHolder.ib_expandlessButton.getParent()).setBackgroundResource(R.color.after_reading_color);
        } else {
            ((ViewGroup)FirstLevelNewsAdapterViewHolder.ib_expandlessButton.getParent()).setBackgroundResource(0);
            //use default background
        }

        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 3 ");

        FirstLevelNewsAdapterViewHolder.ib_bookmarkButton.setOnClickListener(mbookmarkClickListener);
        FirstLevelNewsAdapterViewHolder.ib_bookmarkButton.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);


        final String primarytitle = mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TITLE);

        FirstLevelNewsAdapterViewHolder.ib_shareButton.setOnClickListener(mshareClickListener);
        FirstLevelNewsAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        FirstLevelNewsAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        FirstLevelNewsAdapterViewHolder.ib_shareButton.setTag(R.string.VIEWTAG_TITLE, primarytitle);


        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 4 ");

        FirstLevelNewsAdapterViewHolder.primarytitleView.setText(primarytitle);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setOnClickListener(mcallDetailActivity);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_FINALURL, finalurl);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.constraintlayout_item_primary);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share);
        FirstLevelNewsAdapterViewHolder.primarytitleView.setTag(R.string.VIEWTAG_BACKGROUND_EXPANDLESS_ID, R.id.ib_expandless);



        int timestampondoc = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TIMESTAMPONDOC);
        String timestampondocTranslatedString = GongTimeUtil.getDisplayTimeStringFromData((long)timestampondoc, mContext);
        FirstLevelNewsAdapterViewHolder.tv_dateView.setText(timestampondocTranslatedString);
        //FirstLevelNewsAdapterViewHolder.tv_dateView.setOnClickListener(mcallDetailActivity);
        FirstLevelNewsAdapterViewHolder.tv_dateView.setTag(R.string.VIEWTAG_ARTICLEID, articlePrimaryID);
        FirstLevelNewsAdapterViewHolder.tv_dateView.setTag(R.string.VIEWTAG_FINALURL, finalurl);


        int similiaritiescount = mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_SIMILARITIESCOUNT);


        int expandalready_inmap = 0;
        int checkbitval = 0;

        if (mSignalMap.containsKey(articlePrimaryID) ){
            checkbitval = mSignalMap.get(articlePrimaryID);
            expandalready_inmap = checkbitval & EXPANDALREADY_MASK;
        }
        if (expandalready_inmap != 0){
            FirstLevelNewsAdapterViewHolder.ll_expandlistitem.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.ib_expandlessButton.animate().rotation(180).setDuration(300).start();

        } else {
            FirstLevelNewsAdapterViewHolder.ll_expandlistitem.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.ib_expandlessButton.animate().rotation(0).setDuration(300).start();

        }

        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 5 similiaritiescount= "+ similiaritiescount);
        if ( ( !mUsingSelectedArchivetoDisplay) && (similiaritiescount > 0) ){
            FirstLevelNewsAdapterViewHolder.ib_expandlessButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    LinearLayout expandView = ( (LinearLayout) ((ConstraintLayout)view.getParent()).getParent())
                            .findViewById(R.id.expandlistitem);

                    if (expandView.getVisibility() == View.VISIBLE){
                        int expandalready_inmap = 0;
                        int checkbitval = 0;
                        if (mSignalMap.containsKey(articlePrimaryID) ){
                            checkbitval = mSignalMap.get(articlePrimaryID);
                        }
                        expandalready_inmap = checkbitval & ~EXPANDALREADY_MASK;
                        mSignalMap.put(articlePrimaryID, expandalready_inmap);

                        expandView.setVisibility(View.GONE);
                        view.animate().rotation(0).setDuration(300).start();
                        final View passInView = view;
                        view.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //((ImageButton)passInView).setImageResource(R.drawable.ic_expand_more_black);
                                //passInView.setActivated(false);
                            }
                        }, 350);
                    } else {
                        int expandalready_inmap = 0;
                        int checkbitval = 0;
                        if (mSignalMap.containsKey(articlePrimaryID) ){
                            checkbitval = mSignalMap.get(articlePrimaryID);
                        }
                        expandalready_inmap = checkbitval | EXPANDALREADY_MASK;
                        mSignalMap.put(articlePrimaryID, expandalready_inmap);

                        expandView.setVisibility(View.VISIBLE);
                        view.animate().rotation(180).setDuration(300).start();
                        final View passInView = view;
                        view.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                //((ImageButton)passInView).setImageResource(R.drawable.ic_expand_more_black);
                                //((ImageButton)passInView).setImageResource(R.drawable.ic_bookmark_black);
                                //passInView.setActivated(true);
                            }
                        }, 350);
                    }
                }
            });


            FirstLevelNewsAdapterViewHolder.ib_expandlessButton.setVisibility(View.VISIBLE);
            if ( FirstLevelNewsAdapterViewHolder.ll_expandlistitem.getVisibility() == View.VISIBLE ){
                LogUtil.debug(TAG, "ll_expandlistitem --- > view.visible articleprimaryid=" + articlePrimaryID);
                FirstLevelNewsAdapterViewHolder.ib_expandlessButton.animate().rotation(180).setDuration(300).start();

            } else if ( FirstLevelNewsAdapterViewHolder.ll_expandlistitem.getVisibility() == View.GONE ){
                LogUtil.debug(TAG, "ll_expandlistitem --- > view.gone articleprimaryid=" + articlePrimaryID);
                FirstLevelNewsAdapterViewHolder.ib_expandlessButton.animate().rotation(0).setDuration(300).start();
            }
            FirstLevelNewsAdapterViewHolder.v_dividerview1.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.v_dividerview3.setVisibility(View.VISIBLE);


            FirstLevelNewsAdapterViewHolder.ib_lessbuttonButton.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.ib_lessbuttonButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    LinearLayout expandView = ((LinearLayout) ((ConstraintLayout) view.getParent()).getParent())
                            .findViewById(R.id.expandlistitem);

                    expandView.setVisibility(View.GONE);
                    ImageButton imageButton = ((LinearLayout) ((LinearLayout) ((ConstraintLayout) view.getParent()).getParent()).getParent())
                            .findViewById(R.id.ib_expandless);
                    imageButton.animate().rotation(0).setDuration(300).start();

                    //imageButton.setImageResource(R.drawable.ic_expand_more_black);
                }
            });





            String entryJSONString = mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_ENTRY);
            LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 6 ");

            int count_similiaritiescount = 0;
            List<ArticleInfo> articlelists = new ArrayList<ArticleInfo>();
            List<ArticleInfo> resultList = new ArrayList<ArticleInfo>();
            try {
                JSONTokener tokener = new JSONTokener(entryJSONString);
                LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 7 ");

                while (tokener.more()) {
                    LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 8 ");

                    JSONObject entryobj = (JSONObject) tokener.nextValue();
                    String timenid = "";

                    Iterator<String> iterator = entryobj.keys();
                    if (entryobj.names().length() > 0) {
                        //for (String timenid : entryobj.keys()) {
                        while (iterator.hasNext()) {
                            // it should have only one?
                            timenid = iterator.next();
                            LogUtil.debug(TAG, " timenid = " + timenid);

                            int timestampondoc_timenid = Integer.valueOf(LatestNewsPaginationContract.
                                    PaginationEntry.decodeGetTimestampondoc(timenid));
                            int articleid_timenid = Integer.valueOf(LatestNewsPaginationContract.
                                    PaginationEntry.decodeGetId(timenid));

                            JSONObject entryobj_underneath = (JSONObject) entryobj.get(timenid);

                            int firstsubdomaintable_id = (int) entryobj_underneath.getLong(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID);
                            String title = entryobj_underneath.getString(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE);

                            String imageurl = entryobj_underneath.getString(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL);

                            String finalurl_underneath = entryobj_underneath.getString(
                                    LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL);
                            LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 9 timestampondoc_timenid= " +
                                    " articleid_timenid=" + articleid_timenid + " firstsubdomaintable_id=" + firstsubdomaintable_id + " title=" + title +
                                    " imageurl=" + imageurl + " finalurl=" + finalurl);

                            articlelists.add(new ArticleInfo(firstsubdomaintable_id,
                                    title,
                                    imageurl,
                                    articleid_timenid,
                                    finalurl_underneath,
                                    timestampondoc_timenid));

                            count_similiaritiescount++;

                        }
                    }
                }
                LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 10 ");

                resultList = ArticleInfo.sortByPreferredDomain(articlelists,
                        GongPreference.getPreferredlist(mContext));

            } catch (JSONException e) {
                e.printStackTrace();
            }

            ArticleInfo artInfo = resultList.get(0);
            LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 11 ");

            FirstLevelNewsAdapterViewHolder.tv_titleexpandoneView.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.tv_titleexpandoneView.setText(artInfo.getTitle());


            ArrayList<String> oneSourceIconURLChiName = SourceInfo.getInstance()
                    .getSourceIconURLAndName(artInfo.getFirstsubdomaintable_id());

            FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandoneView.setVisibility(View.VISIBLE);
            GlideApp.with(mContext)
                    .load(oneSourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                    .placeholder(R.drawable.ic_tmp_icon)
                    .fitCenter()
                    .into(FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandoneView);
            FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandoneView.setVisibility(View.VISIBLE);

            LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 12 ");

            FirstLevelNewsAdapterViewHolder.tv_domainsourceexpandoneView.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.tv_domainsourceexpandoneView.setText(
                    oneSourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));


            String timeString = GongTimeUtil.getDisplayTimeStringFromData((long) artInfo.getTimestampondoc(),mContext);
            FirstLevelNewsAdapterViewHolder.tv_dateexpandoneView.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.tv_dateexpandoneView.setText(timeString);


            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setOnClickListener(mcallDetailActivity);
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.article_list_item_one_expand_layout);
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark1);
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share1);
            FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID, R.id.article_list_item_one_sb_expand_layout);


            FirstLevelNewsAdapterViewHolder.ll_article_one_sb_expand.setVisibility(View.VISIBLE);
            FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton1.setOnClickListener(mbookmarkClickListener);
            FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton1.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());

            bookmarkalready_inmap = 0;
            readalready_inmap = 0;
            bitvalBookRead = 0;

            if (mInitupdateSignalMapFromCursor) {
                if (mSignalMap.containsKey(artInfo.getID())) {
                    bitvalBookRead = mSignalMap.get(artInfo.getID());
                    bookmarkalready_inmap = bitvalBookRead & BOOKMARKALREADY_MASK;
                    readalready_inmap = bitvalBookRead & READALREADY_MASK;
                }

                if (bookmarkalready_inmap == 0) {
                    FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton1.setSelected(false);
                } else {
                    FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton1.setSelected(true);
                }
                if (   readalready_inmap != 0) {
                    FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton1.setBackgroundResource(R.color.after_reading_color);
                    FirstLevelNewsAdapterViewHolder.ib_sharebutton1.setBackgroundResource(R.color.after_reading_color);
                    FirstLevelNewsAdapterViewHolder.ll_article_one_sb_expand.setBackgroundResource(R.color.after_reading_color);
                    FirstLevelNewsAdapterViewHolder.article_list_item_one_expand_layout.setBackgroundResource(R.color.after_reading_color);
                }

            }

            FirstLevelNewsAdapterViewHolder.ib_sharebutton1.setOnClickListener(mshareClickListener);
            FirstLevelNewsAdapterViewHolder.ib_sharebutton1.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
            FirstLevelNewsAdapterViewHolder.ib_sharebutton1.setTag(R.string.VIEWTAG_TITLE, artInfo.getTitle());


            if (similiaritiescount == 1) {
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setVisibility(View.GONE);
                FirstLevelNewsAdapterViewHolder.ll_article_two_sb_expand.setVisibility(View.GONE);
                FirstLevelNewsAdapterViewHolder.tv_expandtextView.setVisibility(View.GONE);

                LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 13 ");

            } else {

                artInfo = resultList.get(1);

                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setVisibility(View.VISIBLE);
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setOnClickListener(mcallDetailActivity);
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_LAYOUT_ID, R.id.article_list_item_two_expand_layout);
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_BOOKMARK_ID, R.id.ib_bookmark2);
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_SHARE_ID, R.id.ib_share2);
                FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setTag(R.string.VIEWTAG_BACKGROUND_EXPAND_XXX_SB_ID, R.id.article_list_item_two_sb_expand_layout);

                FirstLevelNewsAdapterViewHolder.ll_article_two_sb_expand.setVisibility(View.VISIBLE);


                FirstLevelNewsAdapterViewHolder.v_dividerview2.setVisibility(View.VISIBLE);


                FirstLevelNewsAdapterViewHolder.tv_titleexpandtwoView.setVisibility(View.VISIBLE);
                FirstLevelNewsAdapterViewHolder.tv_titleexpandtwoView.setText(artInfo.getTitle());

                LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 14 ");

                ArrayList<String> twoSourceIconURLChiName = SourceInfo.getInstance()
                        .getSourceIconURLAndName(artInfo.getFirstsubdomaintable_id());

                FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.VISIBLE);
                GlideApp.with(mContext)
                        .load(twoSourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                        .placeholder(R.drawable.ic_tmp_icon)
                        .fitCenter()
                        .into(FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandtwoView);
                FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.VISIBLE);


                FirstLevelNewsAdapterViewHolder.tv_domainsourceexpandtwoView.setVisibility(View.VISIBLE);
                FirstLevelNewsAdapterViewHolder.tv_domainsourceexpandtwoView.setText(
                        twoSourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));


                timeString = GongTimeUtil.getDisplayTimeStringFromData((long) artInfo.getTimestampondoc(), mContext);
                FirstLevelNewsAdapterViewHolder.tv_dateexpandtwoView.setVisibility(View.VISIBLE);
                FirstLevelNewsAdapterViewHolder.tv_dateexpandtwoView.setText(timeString);

                FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton2.setOnClickListener(mbookmarkClickListener);
                FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton2.setTag(R.string.VIEWTAG_ARTICLEID, artInfo.getID());
                bookmarkalready_inmap = 0;
                readalready_inmap = 0;
                bitvalBookRead = 0;

                if (mInitupdateSignalMapFromCursor) {
                    if (mSignalMap.containsKey(artInfo.getID())) {
                        bitvalBookRead = mSignalMap.get(artInfo.getID());
                        bookmarkalready_inmap = bitvalBookRead & BOOKMARKALREADY_MASK;
                        readalready_inmap = bitvalBookRead & READALREADY_MASK;
                    }

                    if (bookmarkalready_inmap == 0) {
                        FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton2.setSelected(false);
                    } else {
                        FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton2.setSelected(true);
                    }
                    if (   readalready_inmap != 0) {
                        FirstLevelNewsAdapterViewHolder.ib_bookmarkbutton2.setBackgroundResource(R.color.after_reading_color);
                        FirstLevelNewsAdapterViewHolder.ib_sharebutton2.setBackgroundResource(R.color.after_reading_color);
                        FirstLevelNewsAdapterViewHolder.ll_article_two_sb_expand.setBackgroundResource(R.color.after_reading_color);
                        FirstLevelNewsAdapterViewHolder.article_list_item_two_expand_layout.setBackgroundResource(R.color.after_reading_color);
                    }

                }

                FirstLevelNewsAdapterViewHolder.ib_sharebutton2.setOnClickListener(mshareClickListener);
                FirstLevelNewsAdapterViewHolder.ib_sharebutton2.setTag(R.string.VIEWTAG_FINALURL, artInfo.getFinalurl());
                FirstLevelNewsAdapterViewHolder.ib_sharebutton2.setTag(R.string.VIEWTAG_TITLE, artInfo.getTitle());



                if (similiaritiescount <= 2){
                    FirstLevelNewsAdapterViewHolder.tv_expandtextView.setVisibility(View.GONE);

                } else {
                    FirstLevelNewsAdapterViewHolder.tv_expandtextView.setVisibility(View.VISIBLE);
                    ArticleInfo currentArticleInfo = new ArticleInfo(
                            mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FIRSTSUBDOMAINTABLE_ID),
                            mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TITLE),
                            mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_IMAGEURL),
                            mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_ARTICLE_ID),
                            mCursor.getString(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_FINALURL),
                            mCursor.getInt(LatestNewsPaginationContract.INDEX_RAWQUERY_PAGINATION_TIMESTAMPONDOC)
                    );
                    resultList.add(0, currentArticleInfo);

                    //create JSON string and tag it
                    JSONArray resultJSONArray = new JSONArray();
                    int [] bookmarkreadarray = new int[resultList.size()];
                    int index=0;

                    for (ArticleInfo article : resultList) {
                        try {

                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_ARTICLEID,
                                    article.getID());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                                    article.getFirstsubdomaintable_id());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE,
                                    article.getTitle());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL,
                                    article.getFinalurl());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL,
                                    article.getImageurl());
                            jsonObject.put(LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC,
                                    article.getTimestampondoc());
                            jsonObject.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY,
                                    (long) (mSignalMap.containsKey(article.getID()) ? mSignalMap.get(articlePrimaryID) : 0));

                            resultJSONArray.put(jsonObject);

                            bookmarkreadarray[index++] = article.getID();
                            LogUtil.debug(TAG, " currentarticleinfo.id = " + currentArticleInfo.getID() +",article.getID=" + article.getID());

                        } catch (Exception e) {
                            LogUtil.debug(TAG, "creating moredetailist ");
                        }
                    }
                    String resultStringresultJSONArray = resultJSONArray.toString();
                    FirstLevelNewsAdapterViewHolder.tv_expandtextView.
                            setTag(R.string.VIEWTAG_EXPANDTEXT_JSON_STRING, resultStringresultJSONArray);
                    FirstLevelNewsAdapterViewHolder.tv_expandtextView.
                            setTag(R.string.VIEWTAG_EXPANDTEXT_JSON_BOOKMARK_STRING, bookmarkreadarray);
                    FirstLevelNewsAdapterViewHolder.tv_expandtextView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String jsonArticleString = (String) view.getTag(R.string.VIEWTAG_EXPANDTEXT_JSON_STRING);
                            int [] signalmaparray = (int[]) view.getTag(R.string.VIEWTAG_EXPANDTEXT_JSON_BOOKMARK_STRING);
                            JSONArray bookmarkJSONArray = new JSONArray();

                            if (signalmaparray.length > 0) {
                                for (int x : signalmaparray) {
                                    try {
                                        if (   ( mSignalMap.containsKey(x) )
                                                &&(mSignalMap.get(x) != 0) ){
                                            JSONObject jsonObject = new JSONObject();
                                            jsonObject.put(String.valueOf(x), mSignalMap.get(x));
                                            bookmarkJSONArray.put(jsonObject);

                                        }
                                    } catch (Exception e) {
                                        LogUtil.debug(TAG, " onclick  tv_expandtextView ");
                                    }
                                }
                                LogUtil.debug(TAG, " onclick  tv_expandtextView jsonarticlestring=" + jsonArticleString
                                        + ",       bookarmkjsonarray.tostring=" + bookmarkJSONArray.toString());
                                mClickHandler.onClickExpandNews(jsonArticleString, bookmarkJSONArray.toString());
                            } else {
                                LogUtil.debug(TAG, " onclick  tv_expandtextView ERROR bookmarkarray.length=" + signalmaparray.length);
                            }

                        }
                    });

                }

                LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 15 ");


            }

            LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 16 ");

        } else {

            FirstLevelNewsAdapterViewHolder.ib_expandlessButton.setVisibility(View.INVISIBLE);

            FirstLevelNewsAdapterViewHolder.tv_titleexpandoneView.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandoneView.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.tv_domainsourceexpandoneView.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.tv_dateexpandoneView.setVisibility(View.GONE);

            FirstLevelNewsAdapterViewHolder.tv_titleexpandtwoView.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.iv_sourceiconexpandtwoView.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.tv_domainsourceexpandtwoView.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.tv_dateexpandtwoView.setVisibility(View.GONE);

            FirstLevelNewsAdapterViewHolder.ib_lessbuttonButton.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.tv_expandtextView.setVisibility(View.GONE);

            FirstLevelNewsAdapterViewHolder.v_dividerview1.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.v_dividerview2.setVisibility(View.GONE);
            FirstLevelNewsAdapterViewHolder.v_dividerview3.setVisibility(View.GONE);
            LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 17 ");

        }

        LogUtil.debug(TAG, " FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder onBindViewHolder 18 ");

    }


    /**
     * This method simply returns the number of items to display. It is used behind the scenes
     * to help layout our Views and for animations.
     *
     * @return The number of items available in our forecast
     */
    @Override
    public int getItemCount() {
        LogUtil.debug(TAG, " FirstLevelNewsAdapter getitemcount 1 ");

        if (null == mCursor) return 0;
        LogUtil.debug(TAG, " FirstLevelNewsAdapter getitemcount 2 getcount="+ mCursor.getCount()
          + ", getnotificationuri=" + mCursor.getNotificationUri().toString());
        return mCursor.getCount();
    }

    /**
     * Returns an integer code related to the type of View we want the ViewHolder to be at a given
     * position. This method is useful when we want to use different layouts for different items
     * depending on their position. In Sunshine, we take advantage of this method to provide a
     * different layout for the "today" layout. The "today" layout is only shown in portrait mode
     * with the first item in the list.
     *
     * @param position index within our RecyclerView and Cursor
     * @return the view type (today or future day)
     */
    @Override
    public int getItemViewType(int position) {
        return -1;
        //return 0;
    }

    /**
     * Swaps the cursor used by the ForecastAdapter for its weather data. This method is called by
     * MainActivity after a load has finished, as well as when the Loader responsible for loading
     * the weather data is reset. When this method is called, we assume we have a completely new
     * set of data, so we call notifyDataSetChanged to tell the RecyclerView to update.
     *
     * @param newCursor the new cursor to use as ForecastAdapter's data source
     */
    void swapCursor(Cursor newCursor, boolean usingSelectedArchivetoDisplay ) {
        LogUtil.debug(TAG, " FirstLevelNewsAdapter swapcursor  ");

        mUsingSelectedArchivetoDisplay = usingSelectedArchivetoDisplay;
        mCursor = newCursor;
        if (mCursor != null) {
            LogUtil.debug(TAG, " FirstLevelNewsAdapter swapcursor  getcount=" + mCursor.getCount());
            LogUtil.debug(TAG, " FirstLevelNewsAdapter swapcursor  uri=" + mCursor.getNotificationUri());
        }
        notifyDataSetChanged();
    }


    void updateSignalMapFromCursor(Cursor newCursor) {
        LogUtil.debug(TAG, " FirstLevelNewsAdapter  updateSignalMapFromCursor  ");

        if (newCursor!= null) {
            LogUtil.debug(TAG, " FirstLevelNewsAdapter  updateSignalMapFromCursor  getcount=" + newCursor.getCount());
            for (int index = 0; index < newCursor.getCount(); index++) {
                newCursor.moveToPosition(index);
                int articleID = newCursor.getInt(SignalContract.INDEX_ARTICLE_ID);
                int bookmarkalreadyFromCursor = newCursor.getInt(SignalContract.INDEX_BOOKMARKALREADY);
                int readalreadyFromCursor = newCursor.getInt(SignalContract.INDEX_READALREADY);
                int bitvalBookRead = 0;
                if (mSignalMap.containsKey(articleID)) {
                    bitvalBookRead = mSignalMap.get(articleID);
                }
                if (bookmarkalreadyFromCursor == 0) {
                    bitvalBookRead = bitvalBookRead & ~BOOKMARKALREADY_MASK;
                } else {
                    bitvalBookRead = bitvalBookRead | BOOKMARKALREADY_MASK;
                }
                if (readalreadyFromCursor == 0) {
                    bitvalBookRead = bitvalBookRead & ~READALREADY_MASK;
                } else {
                    bitvalBookRead = bitvalBookRead | READALREADY_MASK;

                }
                mSignalMap.put(articleID, bitvalBookRead);

            }

            mInitupdateSignalMapFromCursor=true;

        }
    }


    /**
     * A ViewHolder is a required part of the pattern for RecyclerViews. It mostly behaves as
     * a cache of the child views for a forecast item. It's also a convenient place to set an
     * OnClickListener, since it has access to the adapter and the views.
     */
    class FirstLevelNewsAdapterViewHolder extends RecyclerView.ViewHolder  {
        private final String TAG = FirstLevelNewsAdapter.FirstLevelNewsAdapterViewHolder.class.getSimpleName();

        //the whole view of item
        //final View articleindlistitem;

        //article_list_item_primary.xml
        final ImageView itemthumbnailView;
        final ImageView newsourceiconView;
        final ImageButton ib_bookmarkButton;
        final ImageButton ib_expandlessButton;
        final ImageButton ib_shareButton;
        final TextView tv_domainsourceView;
        final TextView tv_dateView;
        final TextView primarytitleView;


        final LinearLayout ll_expandlistitem;
        //article_list_item_expand.xml
        final ConstraintLayout article_list_item_one_expand_layout;
        final TextView tv_titleexpandoneView;
        final ImageView iv_sourceiconexpandoneView;
        final TextView tv_domainsourceexpandoneView;
        final TextView tv_dateexpandoneView;
        final LinearLayout ll_article_one_sb_expand;
        final ImageButton ib_sharebutton1;
        final ImageButton ib_bookmarkbutton1;


        final ConstraintLayout article_list_item_two_expand_layout;
        final TextView tv_titleexpandtwoView;
        final ImageView iv_sourceiconexpandtwoView;
        final TextView tv_domainsourceexpandtwoView;
        final TextView tv_dateexpandtwoView;
        final LinearLayout ll_article_two_sb_expand;
        final ImageButton ib_sharebutton2;
        final ImageButton ib_bookmarkbutton2;


        final ConstraintLayout article_list_item_more_expand_layout;
        final ImageButton ib_lessbuttonButton;
        final TextView tv_expandtextView;
        final View v_dividerview1;
        final View v_dividerview2;
        final View v_dividerview3;



        FirstLevelNewsAdapterViewHolder(View view) {
            super(view);


            itemthumbnailView = (ImageView) view.findViewById(R.id.itemthumbnail);
            newsourceiconView = (ImageView) view.findViewById(R.id.newsourceicon);
            ib_bookmarkButton = (ImageButton) view.findViewById(R.id.ib_bookmark);
            ib_expandlessButton = (ImageButton) view.findViewById(R.id.ib_expandless);
            ib_shareButton = (ImageButton) view.findViewById(R.id.ib_share);
            tv_domainsourceView = (TextView) view.findViewById(R.id.tv_domainsource);
            tv_dateView = (TextView) view.findViewById(R.id.tv_date);
            primarytitleView = (TextView) view.findViewById(R.id.primarytitle);

            ll_expandlistitem = (LinearLayout) view.findViewById(R.id.expandlistitem);
            article_list_item_one_expand_layout = (ConstraintLayout) view.findViewById(R.id.article_list_item_one_expand_layout);
            tv_titleexpandoneView = (TextView) view.findViewById(R.id.tv_titleexpandone);
            iv_sourceiconexpandoneView = (ImageView) view.findViewById(R.id.iv_sourceiconexpandone);
            tv_domainsourceexpandoneView = (TextView) view.findViewById(R.id.tv_domainsourceexpandone);
            tv_dateexpandoneView = (TextView) view.findViewById(R.id.tv_dateexpandone);
            ll_article_one_sb_expand = (LinearLayout) view.findViewById(R.id.article_list_item_one_sb_expand_layout);
            ib_bookmarkbutton1 = (ImageButton) view.findViewById(R.id.ib_bookmark1);
            ib_sharebutton1 = (ImageButton) view.findViewById(R.id.ib_share1);


            article_list_item_two_expand_layout = (ConstraintLayout) view.findViewById(R.id.article_list_item_two_expand_layout);
            tv_titleexpandtwoView = (TextView) view.findViewById(R.id.tv_titleexpandtwo);
            iv_sourceiconexpandtwoView = (ImageView) view.findViewById(R.id.iv_sourceiconexpandtwo);
            tv_domainsourceexpandtwoView = (TextView) view.findViewById(R.id.tv_domainsourceexpandtwo);
            tv_dateexpandtwoView = (TextView) view.findViewById(R.id.tv_dateexpandtwo);
            ll_article_two_sb_expand = (LinearLayout) view.findViewById(R.id.article_list_item_two_sb_expand_layout);
            ib_bookmarkbutton2 = (ImageButton) view.findViewById(R.id.ib_bookmark2);
            ib_sharebutton2 = (ImageButton) view.findViewById(R.id.ib_share2);


            article_list_item_more_expand_layout = (ConstraintLayout) view.findViewById(R.id.article_list_item_more_expand_layout);
            ib_lessbuttonButton = (ImageButton) view.findViewById(R.id.ib_lessbutton);
            tv_expandtextView = (TextView) view.findViewById(R.id.tv_expandtext);

            v_dividerview1 = (View) view.findViewById(R.id.dividerview1);
            v_dividerview2 = (View) view.findViewById(R.id.dividerview2);
            v_dividerview3 = (View) view.findViewById(R.id.dividerview3);

            LogUtil.debug(TAG, " FirstLevelNewsAdapterViewHolder constructor 1");


        }


    }

}




