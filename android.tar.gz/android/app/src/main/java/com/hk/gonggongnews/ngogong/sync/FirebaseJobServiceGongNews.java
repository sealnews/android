package com.hk.gonggongnews.ngogong.sync;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import com.firebase.jobdispatcher.JobParameters;
import com.firebase.jobdispatcher.JobService;
import com.firebase.jobdispatcher.Trigger;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.GongInfoLookupContract;
import com.hk.gonggongnews.ngogong.data.GongPreference;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 11/25/2017.
 */

public class FirebaseJobServiceGongNews extends JobService {

    private final static String TAG = FirebaseJobServiceGongNews.class.getSimpleName();
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mLatestNewsTableDatabaseReference;
    private final static String ENTITYTABLE = "entitytable";
    private GongNewsAsyncTask mGongNewsAsyncTask;


    private static class GongNewsAsyncTask extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobServiceGongNews.GongNewsAsyncTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public GongNewsAsyncTask(JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " GongNewsAsyncTask constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobServiceGongNews.GongNewsAsyncTask.class.getSimpleName();

            LogUtil.debug(TAG, "doInBackground 1");
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                    .child(ENTITYTABLE);
            reference.keepSynced(true);

            reference.orderByKey()
                    .addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            LogUtil.debug(TAG, " GongNewsAsyncTask ondatachange 1");
                            Map<String, Object> entrymap = (Map<String, Object>)
                                    (dataSnapshot.getValue());

                            String sheetID;
                            String sheeturl;
                            ContentValues singleentryvalue;
                            List<ContentValues> listContentValues = new ArrayList<>();
                            for (Map.Entry<String, Object> inddata : entrymap.entrySet()) {
                                LogUtil.debug(TAG, "--> keyonDataChange = " + inddata.getKey());
                                String name = GongInfoLookupContract.decodeKeyGetName(inddata.getKey());
                                int id = GongInfoLookupContract.decodeKeyGetID(inddata.getKey());
                                String type = "gong";
                                String sourceiconurl = (String) ((Map<String, Object>) inddata.getValue()).get("sourceiconurl");
                                long noofentry = (Long) ((Map<String, Object>) inddata.getValue()).get("noofentry");
                                long lastupdatetime = (Long) ((Map<String, Object>) inddata.getValue()).get("lastupdatetime");

                                LogUtil.debug(TAG, "--> keyonDataChange = " + inddata.getKey()
                                           + ",name=" + name
                                           + ",id=" + id
                                           + ",noofentry=" + noofentry
                                           + ",lastupdatetime=" + lastupdatetime);
                                Map<String, Object> sheetentrymap = (Map<String, Object>) (((HashMap<String, Object>) inddata.getValue())
                                        .get("entry"));
                                for (Map.Entry<String, Object> indsheetdata : sheetentrymap.entrySet()) {
                                    sheetID = indsheetdata.getKey();
                                    sheeturl = (String) indsheetdata.getValue();
                                    singleentryvalue = new ContentValues();
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_NAME, name);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_ID, id);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_TYPE, type);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SOURCEICONURL, sourceiconurl);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_NOOFENTRY, noofentry);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_LASTUPDATETIME, lastupdatetime);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SHEETID, sheetID);
                                    singleentryvalue.put(GongInfoLookupContract.GongInfoLookupEntry.COLUMN_SHEETID_URL, sheeturl);
                                    listContentValues.add(singleentryvalue);
                                }
                            }
                            int index = 0;
                            ContentValues[] entryContentvalues = new ContentValues[listContentValues.size()];
                            for (ContentValues x : listContentValues) {
                                entryContentvalues[index] = listContentValues.get(index);
                                index++;
                            }

                            LogUtil.debug(TAG, " sizeof(listContentValues)=" + listContentValues.size());

                            ContentResolver gongContentResolver = mContextReference.get().getContentResolver();

                                        /* Insert our new weather data into Sunshine's ContentProvider */
                            int result = 0;
                            result = gongContentResolver.delete(
                                    GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI,
                                    null,
                                    null);
                            LogUtil.debug(TAG, "GongNewsAsyncTask ondatachange  done delete result=" + result);
                            result = gongContentResolver.bulkInsert(
                                    GongInfoLookupContract.GongInfoLookupEntry.CONTENT_URI_ALLNAME,
                                    entryContentvalues);
                            LogUtil.debug(TAG, "GongNewsAsyncTask ondatachange  DONE INSERT result =" + result);
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            LogUtil.debug(TAG, "GongNewsAsyncTask oncancelled ");
                        }
                    });

            LogUtil.debug(TAG, " GongNewsAsyncTask 4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }


    }


    @Override
    public boolean onStartJob(JobParameters job) {
        LogUtil.debug(TAG, "onStartJob 1 ");
        mGongNewsAsyncTask = new GongNewsAsyncTask(job, getApplicationContext(), this);
        mGongNewsAsyncTask.execute();
        LogUtil.debug(TAG, "onStartJob 2 ");
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        mGongNewsAsyncTask.cancel(true);
        return false;
    }
}
