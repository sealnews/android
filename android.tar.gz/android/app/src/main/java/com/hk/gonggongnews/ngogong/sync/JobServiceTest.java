package com.hk.gonggongnews.ngogong.sync;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

import com.hk.gonggongnews.ngogong.util.LogUtil;

/**
 * Created by ismile on 2/20/2018.
 */

public class JobServiceTest extends JobService{
    private static final String TAG = JobServiceTest.class.getSimpleName();
    @Override
    public boolean onStartJob(JobParameters params) {
        LogUtil.debug(TAG, "------------------------finally onstart");
        return false;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        LogUtil.debug(TAG, "------------------------finally onstop");
        return false;
    }
}
