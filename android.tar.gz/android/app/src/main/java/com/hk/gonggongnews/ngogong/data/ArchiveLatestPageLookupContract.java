package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.CONTENT_URI;

/**
 * Created by ismile on 11/12/2017.
 */

public class ArchiveLatestPageLookupContract {


    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final int INDEX_ARTICLELOOKUPTABLE_ID = 0;
    public static final int INDEX_SHEETID= 1;
    public static final int INDEX_SHEETID_URL= 2;
    public static final String[] PROJECTION = {
            ArchiveLatestPageLookupEntry.COLUMN_ARTICLELOOKUPTABLE_ID,
            ArchiveLatestPageLookupEntry.COLUMN_SHEETID,
            ArchiveLatestPageLookupEntry.COLUMN_SHEETID_URL
    };

    public static final String PATH_ARCHIVELATESTPAGELOOKUP = "archivelatestpagelookup";

    public static final class ArchiveLatestPageLookupEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_ARCHIVELATESTPAGELOOKUP)
                .build();

        public static final String TABLE_NAME = "archivelatestpagelookup";


        public static final String COLUMN_ARTICLELOOKUPTABLE_ID = "articlelookup_id";
        public static final String COLUMN_SHEETID = "sheetid";
        public static final String COLUMN_SHEETID_URL = "sheetid_url";

    }

    public static long decodeGetLowerBound(String range) {
        String result  = range.split("ZZ")[0];
        return Long.valueOf(result);
    }

    public static long decodeGetHigherBound(String range) {
        String result = range.split("ZZ")[1];
        return Long.valueOf(result);
    }

    public static Uri buildArticleUriWithID(long id) {
        return CONTENT_URI.buildUpon()
                .appendPath(Long.toString(id))
                .build();
    }


}
