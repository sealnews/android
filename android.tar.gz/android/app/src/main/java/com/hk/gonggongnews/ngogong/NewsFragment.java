package com.hk.gonggongnews.ngogong;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;

import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;


import com.google.common.primitives.Ints;
import com.hk.gonggongnews.ngogong.data.ArchiveLatestLookupContract;
import com.hk.gonggongnews.ngogong.data.ArchiveLatestPageLookupContract;
import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationArcContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.sync.FirebaseIntentService;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;

import static android.support.v7.widget.RecyclerView.SCROLL_STATE_DRAGGING;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_IDLE;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_SETTLING;

/**
 * Created by ismile on 9/21/2017.
 */

public class NewsFragment extends Fragment implements
        LoaderManager.LoaderCallbacks<Cursor>,
        LatestNewsPaginationAdapter.LatestNewsPaginationAdapterOnClickHandler,
        NewsFragmentPagerAdapter.TalkToIndividualFragment {


    private Map<String, String> mArticleLookupList;
    private Map<String, String> mArchiveLatestLookupList;
    private Map<String, String> mArchiveLatestPageLookupList;

    private final String TAG = NewsFragment.class.getSimpleName();

    private static final int ID_PAGINATION_LOADER = 45;
    private static final int ID_ARTICLELOOKUP_LOADER = 46;
    private static final int ID_SIGNAL_LOADER = 47;
    private static final int ID_PAGINATION_ALLARCHIVE_LOADER = 48;
    private static final int ID_ARCHIVELATESTLOOKUP_LOADER = 49;
    private static final int ID_ARCHIVELATESTPAGELOOKUP_LOADER = 50;
    private static final int NUMBER_OF_ENTRY_TO_RETRIEVE = 1000;
    private LatestNewsPaginationAdapter mLatestNewsPaginationAdapter;

    private SlowdownRecyclerView mRecyclerView;
    private int mPosition = RecyclerView.NO_POSITION;

    private ProgressBar mLoadingIndicator;

    private boolean mLoadingMore = false;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private boolean mRefreshingLayout = false;
    private boolean mUsingAllArchive = false;
    private boolean mUsingPageArchive = false;
    private int mUsingAllArchivePageNumber = 0;
    private int mUsingPageArchivePageNumber = 0;
    public final static String PREFERREDLISTINTARRAY = "preferredlistarray";
    private MainNewsActivity mMainNewsActivity;


    private SnapHelper mSnapHelper;
    private RecyclerView.OnScrollListener mRecyclerViewOnScrollListener;


    public static final String[] NEWSFRAGMENT_PROJECTION = {
            LatestNewsPaginationContract.PaginationEntry._ID,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_ENTRY,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC_AND_ID,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE,
    };
    public static final int INDEX_PAGINATION__ID = 0;
    public static final int INDEX_PAGINATION_ENTRY = 1;
    public static final int INDEX_PAGINATION_FINALURL = 2;
    public static final int INDEX_PAGINATION_IMAGEURL = 3;
    public static final int INDEX_PAGINATION_TIMESTAMPONDOC_AND_ID = 4;
    public static final int INDEX_TITLE = 5;

    private NewsFragment mCurrentFragment;

    public NewsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.article_list, container, false);


        mCurrentFragment = this;
        mArticleLookupList = new LinkedHashMap<String, String>();
        mArchiveLatestLookupList = new LinkedHashMap<String, String>();
        mArchiveLatestPageLookupList = new LinkedHashMap<String, String>();
        LogUtil.debug(TAG, "oncreateview 1 ");

        mRecyclerView = (SlowdownRecyclerView) rootView.findViewById(R.id.recyclerview_slowdown);
        mLoadingIndicator = (ProgressBar) rootView.findViewById(R.id.pb_loading_indicator);


        LinearLayoutManager layoutManager =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mLatestNewsPaginationAdapter = new LatestNewsPaginationAdapter(this.getActivity(), this);
        mRecyclerView.setAdapter(mLatestNewsPaginationAdapter);

        LogUtil.debug(TAG, "oncreateview 2 ");

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                LogUtil.debug(TAG, "-->  onScrollStateChanged 1 idle=" + SCROLL_STATE_IDLE + ",settling=" + SCROLL_STATE_SETTLING + ",dragging=" +
                        SCROLL_STATE_DRAGGING + ",newState=" + newState);
                int visibleItemCount = recyclerView.getLayoutManager().getChildCount();
                int totalItemCount = recyclerView.getLayoutManager().getItemCount();
                int findFirstVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findFirstVisibleItemPosition();
                int findFirstCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findFirstCompletelyVisibleItemPosition();
                int findLastVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findLastVisibleItemPosition();
                int findLastCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findLastCompletelyVisibleItemPosition();

                LogUtil.debug(TAG, "----> onscrollstatechanged 2 visibleItemCount=" + visibleItemCount +
                        ",totalItemCount=" + totalItemCount +
                        ",findFirstVisibleItemPosition=" + findFirstVisibleItemPosition +
                        ",findFirstCompletelyVisibleItemPosition=" + findFirstCompletelyVisibleItemPosition +
                        ",findLastVisibleItemPosition=" + findLastVisibleItemPosition +
                        ",findLastCompletelyVisibleItemPosition=" + findLastCompletelyVisibleItemPosition
                );
                if ((mLoadingMore == false)
                        && (newState == SCROLL_STATE_DRAGGING)
                        && (((float) findLastVisibleItemPosition / totalItemCount) > 0.4)
                        ) {
                    if (isOnline()) {
                        if (mUsingAllArchive) {
                            LogUtil.debug(TAG, " onscrollstatechanged 3 ");
                            int currentNoOfEntryRemote = GongPreference.getArchiveLatestlookupNoOfEntry(getActivity());
                            retrieveSheet(currentNoOfEntryRemote, mArchiveLatestLookupList,
                                    mUsingAllArchivePageNumber, 0,
                                    LatestNewsPaginationArcContract.PaginationArcEntry.CONTENT_URI,
                                    "H");
                            mUsingAllArchivePageNumber++;
                            LogUtil.debug(TAG, " onscrollstatechanged 4 mUsingAllArchivePageNumber=" + mUsingAllArchivePageNumber);
                        } else {
                            if (mLatestNewsPaginationAdapter.getItemCount() < 120) {
                                //get from firebase
                                Intent firebaseintentservice = new Intent(getActivity(), FirebaseIntentService.class);
                                String sectionID = String.valueOf(totalItemCount + 1) + "to" + String.valueOf(totalItemCount + 20);
                                firebaseintentservice.putExtra("section", sectionID);
                                LogUtil.debug(TAG, " onscrollstatechanged 5  loadingmore is going  to sectionID=" + sectionID);
                                firebaseintentservice.putExtra(FirebaseIntentService.TABLE_UPDATE,
                                        FirebaseIntentService.TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION);
                                getActivity().startService(firebaseintentservice);
                                mLoadingMore = true;
                            } else {
                                //get from drive
                                LogUtil.debug(TAG, " onscrollstatechanged 6 ");

                                mUsingPageArchive = true;
                                int currentNoOfEntryRemote = GongPreference.getArchiveLatestPagelookupNoOfEntry(getActivity());
                                Gongdispatch.retrieveSheet(currentNoOfEntryRemote, mArchiveLatestPageLookupList,
                                        mUsingPageArchivePageNumber, 120,
                                        LatestNewsPaginationContract.PaginationEntry.CONTENT_URI,
                                        "J", NUMBER_OF_ENTRY_TO_RETRIEVE, mMainNewsActivity );

                                //retrieveSheet(currentNoOfEntryRemote, mArchiveLatestPageLookupList,
                                //        mUsingPageArchivePageNumber, 120,
                                //        LatestNewsPaginationContract.PaginationEntry.CONTENT_URI,
                                //        "J");
                                mUsingPageArchivePageNumber++;
                                LogUtil.debug(TAG, " onscrollstatechanged 7 mUsingPageArchivePageNumber=" + mUsingPageArchivePageNumber);


                            }
                        }
                    } else {
                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }
                }

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

            }
        });


        LogUtil.debug(TAG, "oncreateview 3 ");


        mSwipeRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.swiperefresh);
//        mSwipeRefreshLayout = (SwipeRefreshLayout) ( container.getParent());
        mSwipeRefreshLayout.setDistanceToTriggerSync(32);
        mSwipeRefreshLayout.setNestedScrollingEnabled(true);
        mSwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        LogUtil.debug(TAG, "onRefresh called from SwipeRefreshLayout 1 ");
                        if (isOnline()) {
                            LogUtil.debug(TAG, "onRefresh called from SwipeRefreshLayout 2");
                            Intent firebaseintentservice = new Intent(getActivity(), FirebaseIntentService.class);
                            firebaseintentservice.putExtra("section", "1to20");
                            firebaseintentservice.putExtra(FirebaseIntentService.TABLE_UPDATE,
                                    FirebaseIntentService.TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION);

                            mUsingAllArchive = false;
                            mUsingAllArchivePageNumber = 0;

                            getActivity().startService(firebaseintentservice);
                            ((FilterFragment.CallBackMainActivity) mMainNewsActivity).clearCurrentPreferredSourceListAfterSwipe();

                            mRefreshingLayout = true;
                            int currentNoOfEntry = GongPreference.getArchiveLatestPagelookupNoOfEntry(getActivity());
                            GongPreference.setArchiveLatestPagelookupNoOfEntryLocal(getActivity(),
                                    currentNoOfEntry);

                        } else {
                            LogUtil.debug(TAG, "onRefresh called from SwipeRefreshLayout 3");
                            Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                            mSwipeRefreshLayout.setRefreshing(false);
                        }
                    }
                }
        );
        LogUtil.debug(TAG, "oncreateview 4 ");

        getActivity().getSupportLoaderManager().initLoader(ID_PAGINATION_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_ARTICLELOOKUP_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_SIGNAL_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_ARCHIVELATESTLOOKUP_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_ARCHIVELATESTPAGELOOKUP_LOADER, null, this);

        LogUtil.debug(TAG, "oncreateview 5 ");

        int currentNoOfEntry = GongPreference.getArchiveLatestPagelookupNoOfEntry(getActivity());
        GongPreference.setArchiveLatestPagelookupNoOfEntryLocal(getActivity(),
                currentNoOfEntry);

        //Gongdispatch.initialize(getActivity());
        LogUtil.debug(TAG, "oncreateview 6 ");

        mUsingAllArchivePageNumber = 0;
        mUsingPageArchivePageNumber = 0;

        return rootView;


        //TextView textView = new TextView(getActivity());
        //textView.setText(R.string.hello_blank_fragment);
        //return textView;
    }


    @Override
    public void onStop() {
        super.onStop();
        // When the activity is stopped, release the media player resources because we won't
        // be playing any more sounds.
    }

    private void showLoading() {
        /* Then, hide the weather data */
        LogUtil.debug(TAG, " showloading ");
        mRecyclerView.setVisibility(View.INVISIBLE);
        /* Finally, show the loading indicator */
        mLoadingIndicator.setVisibility(View.VISIBLE);
    }

    private void showDataView() {
        /* First, hide the loading indicator */
        LogUtil.debug(TAG, " showdatashow ");
        mLoadingIndicator.setVisibility(View.INVISIBLE);
        /* Finally, make sure the weather data is visible */
        mRecyclerView.setVisibility(View.VISIBLE);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        LogUtil.debug(TAG, "----> oncreateloader ");
        switch (id) {

            case ID_PAGINATION_LOADER:
                /* URI for all rows of weather data in our weather table */
                Uri paginationQueryUri = LatestNewsPaginationContract.PaginationEntry.CONTENT_URI;
                String paginationsortOrder = LatestNewsPaginationContract.PaginationEntry._ID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 1");

                return new CursorLoader(getActivity(),
                        paginationQueryUri,
                        null,
                        null,
                        null,
                        paginationsortOrder);
            case ID_ARTICLELOOKUP_LOADER:
                Uri articlelookupQueryUri = ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI;
                String articlelookupsortOrder = ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                return new CursorLoader(getActivity(),
                        articlelookupQueryUri,
                        ArticleLookupTableContract.PROJECTION,
                        null,
                        null,
                        articlelookupsortOrder);


            case ID_PAGINATION_ALLARCHIVE_LOADER:
                /* URI for all rows of weather data in our weather table */
                Uri paginationAllArchiveQueryUri = LatestNewsPaginationArcContract.PaginationArcEntry.CONTENT_URI;
                String paginationAllArchivesortOrder = LatestNewsPaginationArcContract.PaginationArcEntry._ID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 4");

                StringBuilder selectionBuilder = new StringBuilder();
                String[] selectionArgs;
                if (args != null) {
                    int[] arrayOfFSD = args.getIntArray(PREFERREDLISTINTARRAY);
                    if ( ( arrayOfFSD == null ) || (arrayOfFSD.length == 0) ) {
                        selectionArgs = null;
                    }  else {
                        selectionArgs = new String[arrayOfFSD.length];
                        for (int y = 0; y < arrayOfFSD.length; y++) {
                            LogUtil.debug(TAG, "----> oncreateloader 4.1 = " + arrayOfFSD[y]);
                        }
                        for (int index = 0; index < arrayOfFSD.length; index++) {
                            selectionArgs[index] = String.valueOf(arrayOfFSD[index]);
                            selectionBuilder.append(LatestNewsPaginationArcContract.RAWQUERYPAGINATIONWHEREFIRSTSUBSTRING);
                            if ((index + 1) < arrayOfFSD.length) {
                                selectionBuilder.append(" or ");
                            }

                        }
                        LogUtil.debug(TAG, "----> oncreateloader 4.2 = " + selectionBuilder);
                        for (int y = 0; y < selectionArgs.length; y++) {
                            LogUtil.debug(TAG, ", selectionargs=" + selectionArgs[y]);
                        }
                    }
                } else{
                    selectionArgs = new String[1];
                    selectionArgs[0] = String.valueOf(10);
                    selectionBuilder.append(LatestNewsPaginationArcContract.RAWQUERYPAGINATIONWHEREFIRSTSUBSTRING);
                }

                return new CursorLoader(getActivity(),
                        paginationAllArchiveQueryUri,
                        null,
                        selectionBuilder.toString(),
                        selectionArgs,
                        paginationAllArchivesortOrder);


            case ID_ARCHIVELATESTLOOKUP_LOADER:
                Uri archivelatestlookupQueryUri = ArchiveLatestLookupContract.ArchiveLatestLookupEntry.CONTENT_URI;
                String archivelatestlookupsortOrder = ArchiveLatestLookupContract.ArchiveLatestLookupEntry.COLUMN_SHEETID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 5");

                return new CursorLoader(getActivity(),
                        archivelatestlookupQueryUri,
                        ArchiveLatestLookupContract.PROJECTION,
                        null,
                        null,
                        archivelatestlookupsortOrder);


            case ID_ARCHIVELATESTPAGELOOKUP_LOADER:
                Uri archivelatestpagelookupQueryUri = ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.CONTENT_URI;
                String archivelatestpagelookupsortOrder = ArchiveLatestPageLookupContract.ArchiveLatestPageLookupEntry.COLUMN_SHEETID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 6");

                return new CursorLoader(getActivity(),
                        archivelatestpagelookupQueryUri,
                        ArchiveLatestPageLookupContract.PROJECTION,
                        null,
                        null,
                        archivelatestpagelookupsortOrder);

            case ID_SIGNAL_LOADER:
            default:
                if (id != ID_SIGNAL_LOADER){
                    Log.w(TAG, "Loader Not Implemented: " + id);
                }
                Uri signalQueryUri = SignalContract.SignalEntry.CONTENT_URI;
                String signalsortOrder = SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 3");

                return new CursorLoader(getActivity(),
                        signalQueryUri,
                        SignalContract.PROJECTION,
                        null,
                        null,
                        signalsortOrder);

                //throw new RuntimeException("Loader Not Implemented: " + id);
        }


    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, " newsfragment onloadfinished 1 ");

        switch (loader.getId()) {
            case ID_PAGINATION_LOADER:
            case ID_PAGINATION_ALLARCHIVE_LOADER:
                //check whether sourceinfo is ready
                if (!SourceInfo.allReady()){
                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            //getActivity().getSupportLoaderManager().restartLoader(ID_PAGINATION_LOADER, null, mCurrentFragment);
                            LogUtil.debug(TAG, " newsfragment onloadfinished sourceinfo not ready");
                            getLoaderManager().restartLoader(ID_PAGINATION_LOADER, null, mCurrentFragment);
                            mRefreshingLayout = true;
                        }
                    }, 1500);
                    LogUtil.debug(TAG, "id_pagination_loader sourceinfo is not ready");
                    break;
                }
                LogUtil.debug(TAG, " newsfragment onloadfinished 1.1 ");

                if ((loader.getId() == ID_PAGINATION_ALLARCHIVE_LOADER) && (data.getCount() == 0)) {
                    //go get data
                    if (Gongdispatch.isOnline(getActivity())) {
                        showLoading();
                        mRefreshingLayout = true;
                        LogUtil.debug(TAG, " newsfragment onloadfinished 1.2 ");
                        int currentNoOfEntryRemote = GongPreference.getArchiveLatestlookupNoOfEntry(getActivity());
                        retrieveSheet(currentNoOfEntryRemote, mArchiveLatestLookupList,
                                mUsingAllArchivePageNumber, 0,
                                LatestNewsPaginationArcContract.PaginationArcEntry.CONTENT_URI,
                                "H");
                        mUsingAllArchivePageNumber++;
                    } else {
                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                    LogUtil.debug(TAG, " newsfragment onloadfinished 1.3 mUsingAllArchivePageNumber=" + mUsingAllArchivePageNumber);

                } else {
                    if (mRefreshingLayout == true) {
                        mRefreshingLayout = false;
                        mSwipeRefreshLayout.setRefreshing(false);
                        //mSwipeRefreshLayout.setEnabled(true);
                        LogUtil.debug(TAG, " newsfragment onloadfinished 2 ");
                        mRecyclerView.smoothScrollToPosition(0);

                    }
                    LogUtil.debug(TAG, " newsfragment onloadfinished 3 musingallarchive=" + mUsingAllArchive);
                    mLatestNewsPaginationAdapter.swapCursor(data, mUsingAllArchive);
                    mLoadingMore = false;
                    LogUtil.debug(TAG, " newsfragment onloadfinished 4 ");
                    if (mPosition == RecyclerView.NO_POSITION) mPosition = 0;
                    //mRecyclerView.smoothScrollToPosition(mPosition);
                    LogUtil.debug(TAG, " newsfragment onloadfinished 5 data.getcount=" + data.getCount());
                    if (data.getCount() != 0) showDataView();
                }
                break;
            case ID_ARTICLELOOKUP_LOADER:
                if ((data != null) && (data.getCount() > 0)) {
                    for (int index = 0; index < data.getCount(); index++) {
                        data.moveToPosition(index);
                        mArticleLookupList.put(
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID),
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, " newsfragment onloadinfished articlelookup_loader index="
                                + index
                                + ", sheetid="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, " newsfragment onloadinfished articlelookup_loader getcount=0");
                }
                LogUtil.debug(TAG, " ID_ARTICLELOOKUP_LOADER mArticleLookupList=" + mArticleLookupList.toString());

                break;
            case ID_SIGNAL_LOADER:
                mLatestNewsPaginationAdapter.updateSignalMapFromCursor(data);
                //getActivity().getSupportLoaderManager().destroyLoader(ID_SIGNAL_LOADER);
                LogUtil.debug(TAG, " newsfragment onloadfinished 9 loaderid=" + loader.getId());


                break;

            case ID_ARCHIVELATESTLOOKUP_LOADER:
                if ((data != null) && (data.getCount() > 0)) {
                    for (int index = 0; index < data.getCount(); index++) {
                        data.moveToPosition(index);
                        mArchiveLatestLookupList.put(
                                data.getString(ArchiveLatestLookupContract.INDEX_SHEETID),
                                data.getString(ArchiveLatestLookupContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, " newsfragment onloadinfished ID_ARCHIVELATESTLOOKUP_LOADER index="
                                + index
                                + ", sheetid="
                                + data.getString(ArchiveLatestLookupContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArchiveLatestLookupContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, " newsfragment onloadinfished ID_ARCHIVELATESTLOOKUP_LOADER getcount=0");
                }
                LogUtil.debug(TAG, " ID_ARCHIVELATESTLOOKUP_LOADER mArchiveLatestLookupList=" + mArchiveLatestLookupList.toString());

                break;

            case ID_ARCHIVELATESTPAGELOOKUP_LOADER:
                if ((data != null) && (data.getCount() > 0)) {
                    for (int index = 0; index < data.getCount(); index++) {
                        data.moveToPosition(index);
                        mArchiveLatestPageLookupList.put(
                                data.getString(ArchiveLatestPageLookupContract.INDEX_SHEETID),
                                data.getString(ArchiveLatestPageLookupContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, " newsfragment onloadinfished ID_ARCHIVELATESTPAGELOOKUP_LOADER index="
                                + index
                                + ", sheetid="
                                + data.getString(ArchiveLatestPageLookupContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArchiveLatestPageLookupContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, " newsfragment onloadinfished ID_ARCHIVELATESTPAGELOOKUP_LOADER getcount=0");
                }
                LogUtil.debug(TAG, " ID_ARCHIVELATESTPAGELOOKUP_LOADER mArchiveLatestPageLookupList=" + mArchiveLatestPageLookupList.toString());

                break;


            default:
                LogUtil.debug(TAG, " newsfragment onloadfinished 10 loaderid=" + loader.getId());
                break;
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        LogUtil.debug(TAG, "----> onloaderreset loader.getid=" + loader.getId());

        mLatestNewsPaginationAdapter.swapCursor(null, mUsingAllArchive);
    }

    @Override
    public void onClickLatestNewsPagination(long entryID, String finalurl) {
        //Intent weatherDetailIntent = new Intent(MainActivity.this, DetailActivity.class);
        //Uri uriForDateClicked = WeatherContract.WeatherEntry.buildWeatherUriWithDate(date);
        //weatherDetailIntent.setData(uriForDateClicked);
        //startActivity(weatherDetailIntent);

        for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

            if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                    && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                LogUtil.debug(TAG, " newsfragment --> onClickLatestNewsPagination 1 entryID=" + entryID);
                //if (Gongdispatch.isOnline(mMainNewsActivity)) {
                //    Gongdispatch.gsheetfetchOneEntry(mMainNewsActivity, mapentry.getValue(), entryID -
                //            (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1, entryID);
                //}

                Intent intent = new Intent(getActivity(), DetailNewsActivity.class);
                intent.putExtra(DetailNewsActivity.SHEET_ID, mapentry.getValue());
                intent.putExtra(DetailNewsActivity.ARTICLE_ID, entryID);
                intent.putExtra(DetailNewsActivity.FINALURL, finalurl);
                intent.putExtra(DetailNewsActivity.ROWID, entryID -
                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1);
                startActivity(intent);
                LogUtil.debug(TAG, " newsfragment --> onClickLatestNewsPagination 2 entryID=" + entryID);

                break;
            }
        }
        LogUtil.debug(TAG, "newsfragment --> onClickLatestNewsPagination 3 ");
    }

    @Override
    public void onClickExpandNews(String jsonArticleList, String jsonSignalbit) {
        Intent intent = new Intent(getActivity(), ExpandNewsActivity.class);
        intent.putExtra(ExpandNewsActivity.JSONARTICLELISTSTR, jsonArticleList);
        intent.putExtra(ExpandNewsActivity.JSONSIGNALBITSTR, jsonSignalbit);
        startActivity(intent);
        LogUtil.debug(TAG, "newsfragment --> onClickExpandNews 1 ");

    }

    @Override
    public void onClickBookmarkArticleStoreOrRemove(long entryID, boolean save) {

        if (save) {
            for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

                if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                        && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                    LogUtil.debug(TAG, " newsfragment --> onClickBookmarkArticleStoreOrRemove 1 entryID=" + entryID);
                    if (Gongdispatch.isOnline(getActivity())) {
                        Gongdispatch.gsheetfetchOneEntry(getActivity(),
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);
                    } else {
                        Gongdispatch.gongdispatchOneEntry(getActivity(),
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);

                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                    LogUtil.debug(TAG, " newsfragment --> onClickBookmarkArticleStoreOrRemove 2 entryID=" + entryID);
                    break;
                }
            }
            LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 3 ");
        } else {
            //remove
            Uri removeindIDURI = ArticleTableContract.buildArticleUriWithID(entryID);
            String selection = " " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " == ? ";

            int result = getActivity().getContentResolver().delete(
                    removeindIDURI,
                    selection,
                    null);
            LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 4 result= " + result);

        }
    }

    public boolean isOnline() {
        ConnectivityManager connMgr = (ConnectivityManager)
                getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }


    public void showAllDomain() {
        mUsingAllArchive = false;
        mUsingAllArchivePageNumber = 0;
        getActivity().getSupportLoaderManager().restartLoader(ID_PAGINATION_LOADER, null, this);
    }


    public void retrieveSheet(int currentNoOfEntryRemote, Map<String, String> maplookupList,
                              int pagenumber, int offset, Uri uri, String endcolumnName) {
        int highOffsetFromLastFetch = currentNoOfEntryRemote - pagenumber
                * NUMBER_OF_ENTRY_TO_RETRIEVE - offset;
        int lowOffsetFromLastFetch = highOffsetFromLastFetch - NUMBER_OF_ENTRY_TO_RETRIEVE + 1;
        String lowOffsetSheetID = "";
        int lowOffsetHighEnd = 0;
        String highOffsetSheetID = "";
        int highOffsetLowEnd = 0;

        for (Map.Entry<String, String> mapentry : maplookupList.entrySet()) {
            if ((ArchiveLatestLookupContract.decodeGetLowerBound(mapentry.getKey()) <= lowOffsetFromLastFetch)
                    && (lowOffsetFromLastFetch <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {
                lowOffsetSheetID = mapentry.getValue();
                lowOffsetHighEnd = (int) ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey());
            }
            if ((ArchiveLatestLookupContract.decodeGetLowerBound(mapentry.getKey()) <= highOffsetFromLastFetch)
                    && (highOffsetFromLastFetch <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))
                    ) {
                highOffsetSheetID = mapentry.getValue();
                highOffsetLowEnd = (int) ArchiveLatestLookupContract.decodeGetLowerBound(mapentry.getKey());
            }
            if ((ArchiveLatestLookupContract.decodeGetLowerBound(mapentry.getKey()) <= highOffsetFromLastFetch)
                    && (highOffsetFromLastFetch <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))
                    && (ArchiveLatestLookupContract.decodeGetLowerBound(mapentry.getKey()) <= lowOffsetFromLastFetch)
                    && (lowOffsetFromLastFetch <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))

                    ) {
                //only one request
                LogUtil.debug(TAG, " newsfragment --> retrieveSheet gsheet 1 " +
                        " start from " + "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) +
                        " end with " + endcolumnName + String.valueOf(
                        (highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) == 0 ?
                                Gongdispatch.ENTRYPERSHEET :
                                highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET));

                Gongdispatch.gsheetfetchOneBlock(getActivity(),
                        mapentry.getValue(),
                        "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                        endcolumnName + String.valueOf((highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) == 0 ?
                                Gongdispatch.ENTRYPERSHEET :
                                highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                        null, null, uri);
                LogUtil.debug(TAG, " newsfragment --> retrieveSheet gsheet 2 ");
                mLoadingMore = true;

                break;
            }
        }
        if (lowOffsetSheetID.compareTo(highOffsetSheetID) != 0) {
            //need send request
            LogUtil.debug(TAG, " newsfragment --> retrieveSheet gsheet 3 " +
                    " start from " + "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET) +
                    " end with " + endcolumnName + String.valueOf(lowOffsetHighEnd));
            Gongdispatch.gsheetfetchOneBlock(getActivity(), lowOffsetSheetID,
                    "A" + String.valueOf(lowOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                    endcolumnName + String.valueOf(lowOffsetHighEnd),
                    null, null, uri);
            LogUtil.debug(TAG, " newsfragment --> retrieveSheet gsheet 3 " +
                    " start from " + "A" + String.valueOf(highOffsetLowEnd) +
                    " end with " + endcolumnName + String.valueOf(highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET));
            Gongdispatch.gsheetfetchOneBlock(getActivity(), highOffsetSheetID,
                    "A" + String.valueOf(highOffsetLowEnd),
                    endcolumnName + String.valueOf(highOffsetFromLastFetch % Gongdispatch.ENTRYPERSHEET),
                    null, null, uri);
            LogUtil.debug(TAG, " newsfragment --> retrieveSheet gsheet 4 ");
            mLoadingMore = true;

        }
    }

    @Override
    public int checkHowManyNewItem() {
        //int currentLocalNoOfEntry = GongPreference.getLatestNewsPaginationNoOfEntryLocal(getActivity());
        //int currentRemoteNoOfEntry = GongPreference.getLatestNewsPaginationNoOfEntry(getActivity());
        int currentLocalNoOfEntry = GongPreference.getArchiveLatestPagelookupNoOfEntryLocal(getActivity());
        int currentRemoteNoOfEntry = GongPreference.getArchiveLatestPagelookupNoOfEntry(getActivity());
        LogUtil.debug(TAG, " currentLocalNoOfEntry=" + currentLocalNoOfEntry + ",currentRemoteNoOfEntry=" + currentRemoteNoOfEntry);
        if (currentRemoteNoOfEntry - currentLocalNoOfEntry > 0) {
            return currentRemoteNoOfEntry - currentLocalNoOfEntry;
        } else {
            return 0;
        }
    }

    @Override
    public void initPreferredFirstSubDomain(int[] arrayOfFSD) {
        mUsingAllArchive = true;
        mUsingAllArchivePageNumber = 0;

        ContentResolver contentResolver = getActivity().getContentResolver();

        int result = contentResolver.delete(
                LatestNewsPaginationArcContract.PaginationArcEntry.CONTENT_URI,
                null,
                null);
        LogUtil.debug(TAG, "initPreferredFirstSubDomain DELETE result =" + result);


        Bundle passBundle = new Bundle();
        passBundle.putIntArray(PREFERREDLISTINTARRAY, arrayOfFSD);
        LogUtil.debug(TAG, "initPreferredFirstSubDomain 1 arrayoffsd = " + arrayOfFSD.toString());
        getActivity().getSupportLoaderManager().restartLoader(ID_PAGINATION_ALLARCHIVE_LOADER, passBundle, this);
        LogUtil.debug(TAG, "initPreferredFirstSubDomain 2 arrayoffsd = " + arrayOfFSD.toString());


    }

    @Override
    public void clearPreferredFirstSubDomain() {
        LogUtil.debug(TAG, " clearPreferredFirstSubDomain 1");
        mUsingAllArchive = false;
        mUsingAllArchivePageNumber = 0;
        getActivity().getSupportLoaderManager().restartLoader(ID_PAGINATION_LOADER, null, this);
        LogUtil.debug(TAG, " clearPreferredFirstSubDomain 2");


    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);


        if (context instanceof Activity) {
            mMainNewsActivity = (MainNewsActivity) context;
            LogUtil.debug(TAG, " onAttach 1");
        }

    }


    @Override
    public void swiperefreshNow() {
        LogUtil.debug(TAG, "swiperefreshNow called 1");
        if (Gongdispatch.isOnline(getActivity())) {

            Intent firebaseintentservice = new Intent(getActivity(), FirebaseIntentService.class);
            firebaseintentservice.putExtra("section", "1to20");
            firebaseintentservice.putExtra(FirebaseIntentService.TABLE_UPDATE,
                    FirebaseIntentService.TABLE_UPDATE_LATESTNEWSTABLE_PAGINATION);

            mUsingAllArchive = false;
            mUsingAllArchivePageNumber = 0;

            getActivity().startService(firebaseintentservice);
            ((FilterFragment.CallBackMainActivity) mMainNewsActivity).clearCurrentPreferredSourceListAfterSwipe();

            mRefreshingLayout = true;
            mSwipeRefreshLayout.setRefreshing(true);
            int currentNoOfEntry = GongPreference.getArchiveLatestPagelookupNoOfEntry(getActivity());
            GongPreference.setArchiveLatestPagelookupNoOfEntryLocal(getActivity(),
                    currentNoOfEntry);

        } else {
            Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
        }
        LogUtil.debug(TAG, "swiperefreshNow called 2");
    }

}
