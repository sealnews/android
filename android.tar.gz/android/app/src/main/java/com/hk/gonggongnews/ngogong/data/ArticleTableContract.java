package com.hk.gonggongnews.ngogong.data;

import android.net.Uri;
import android.provider.BaseColumns;

import static com.hk.gonggongnews.ngogong.data.ArticleTableContract.ArticleEntry.CONTENT_URI;

/**
 * Created by ismile on 10/16/2017.
 */

public class ArticleTableContract {
    public static final String CONTENT_AUTHORITY = "com.hk.gonggongnews.ngogong";

    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static final String SELECTION_ARTICLE_ID = " article.articletable_id == ? ";
    public static final String RAWQUERYORDERSTRING = " order by article.timestampondoc DESC ";
    public static final String RAWQUERYBOOKMARKARTICLESELECTIONSTRING =
            " select "
                    + " article.articletable_id as article_articletable_id, "
                    + " article.firstsubdomaintable_id as article_firstsubdomaintable_id, "
                    + " article.finalurl as article_finalurl, "
                    + " article.timestampondoc as article_timestampondoc, "
                    + " article.title as article_title, "
                    + " article.imageurl as article_imageurl, "
                    + " signal.bookmarkalready as signal_bookmarkalready, "
                    + " signal.readalready as signal_readalready, "
                    + " firstsubdomain.sourceiconurl as firstsubdomain_sourceiconurl "
                    + " from article "
                    + " left join firstsubdomain on article.firstsubdomaintable_id = firstsubdomain.firstsubdomaintable_id "
                    + " left join signal on article.articletable_id = signal.article_id ";
    public static final String RAWQUERYBOOKMARKSTRING = RAWQUERYBOOKMARKARTICLESELECTIONSTRING
            + " where signal.bookmarkalready == 1 "
            + RAWQUERYORDERSTRING;
    public static final int INDEX_BOOKMARK_ARTICLETABLE_ID = 0;
    public static final int INDEX_BOOKMARK_FIRSTSUBDOMAINTABLE_ID = 1;
    public static final int INDEX_BOOKMARK_FINALURL = 2;
    public static final int INDEX_BOOKMARK_TIMESTAMPONDOC = 3;
    public static final int INDEX_BOOKMARK_TITLE = 4;
    public static final int INDEX_BOOKMARK_IMAGEURL = 5;
    public static final int INDEX_BOOKMARK_BOOKMARKALREADY= 6;
    public static final int INDEX_BOOKMARK_READALREADY= 7;
    public static final int INDEX_BOOKMARK_SOURCEICONURL= 8;




    public static final int INDEX_ARTICLETABLE_ID = 0;
    public static final int INDEX_FIRSTSUBDOMAINTABLE_ID = 1;
    public static final int INDEX_FINALURL = 2;
    public static final int INDEX_TIMESTAMPONDOC = 3;
    public static final int INDEX_TITLE = 4;
    public static final int INDEX_CONTENT = 5;
    public static final int INDEX_IMAGEURL = 6;
    public static final int INDEX_SIMILARITIESLIST = 7;
    public static final int INDEX_SIMILARITIESCOUNT = 8;

    public static final String[] PROJECTION = {
            ArticleEntry.COLUMN_ARTICLETABLE_ID,
            ArticleEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
            ArticleEntry.COLUMN_FINALURL,
            ArticleEntry.COLUMN_TIMESTAMPONDOC,
            ArticleEntry.COLUMN_TITLE,
            ArticleEntry.COLUMN_CONTENT,
            ArticleEntry.COLUMN_IMAGEURL,
            ArticleEntry.COLUMN_SIMILARITIESLIST,
            ArticleEntry.COLUMN_SIMILARITIESCOUNT
    };

    public static final String PATH_ARTICLE= "article";
    public static final String PATH_BOOKMARK= "bookmark";
    public static final String PATH_ARTICLE_BOOKMARK = "article/bookmark";

    public static final class ArticleEntry implements BaseColumns {

        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_ARTICLE)
                .build();

        public static final Uri CONTENT_BOOKMARK_URI = BASE_CONTENT_URI.buildUpon()
                .appendPath(PATH_ARTICLE)
                .appendPath(PATH_BOOKMARK)
                .build();

        public static final String TABLE_NAME = "article";


        public static final String COLUMN_ARTICLETABLE_ID = "articletable_id";
        public static final String COLUMN_FIRSTSUBDOMAINTABLE_ID = "firstsubdomaintable_id";
        public static final String COLUMN_FINALURL = "finalurl";
        public static final String COLUMN_TIMESTAMPONDOC = "timestampondoc";
        public static final String COLUMN_TIMESTAMPONRETRIEVE = "timestamponretrieve";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_CONTENT= "content";
        public static final String COLUMN_IMAGEURL= "imageurl";
        public static final String COLUMN_SIMILARITIESLIST = "similaritieslist";
        public static final String COLUMN_SIMILARITIESCOUNT = "similaritiescount";



    }
    public static Uri buildArticleUriWithID(long id) {
        return CONTENT_URI.buildUpon()
                .appendPath(Long.toString(id))
                .build();
    }


}
