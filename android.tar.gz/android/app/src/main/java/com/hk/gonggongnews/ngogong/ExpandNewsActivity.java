package com.hk.gonggongnews.ngogong;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SnapHelper;

import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.Log;
import android.view.MenuItem;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by ismile on 11/1/2017.
 */

public class ExpandNewsActivity extends AppCompatActivity implements
        LoaderManager.LoaderCallbacks<Cursor>,
        ListIndNewsAdapter.ListIndNewsAdapterOnClickHandler{


    public static final String JSONARTICLELISTSTR = "jsonarticleliststr";
    public static final String JSONSIGNALBITSTR = "jsonsignalbitstr";

    private Map<String, String> mArticleLookupList;

    private final String TAG = ExpandNewsActivity.class.getSimpleName();

    private static final int ID_ARTICLELOOKUP_LOADER = 201;
    private static final int ID_SIGNAL_LOADER = 202;
    private ListIndNewsAdapter mListIndNewsAdapter;

    private SlowdownRecyclerView mRecyclerView;
    private int mPosition = RecyclerView.NO_POSITION;

    private ProgressBar mLoadingIndicator;

    private boolean mLoadingMore = false;
    //private SwipeRefreshLayout mSwipeRefreshLayout ;
    private boolean mRefreshingLayout=false ;


    public static final String[] NEWSFRAGMENT_PROJECTION = {
            LatestNewsPaginationContract.PaginationEntry._ID,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_ENTRY,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_FINALURL,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_IMAGEURL,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_TIMESTAMPONDOC_AND_ID,
            LatestNewsPaginationContract.PaginationEntry.COLUMN_TITLE,
    };
    public static final int INDEX_PAGINATION__ID= 0;
    public static final int INDEX_PAGINATION_ENTRY= 1;
    public static final int INDEX_PAGINATION_FINALURL= 2;
    public static final int INDEX_PAGINATION_IMAGEURL= 3;
    public static final int INDEX_PAGINATION_TIMESTAMPONDOC_AND_ID= 4;
    public static final int INDEX_TITLE= 5;

    private String mJSONArticleliststr;
    private String mJSONSignalbitstr;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expand_news);
        SourceInfo.init(this, getSupportLoaderManager());

        Intent intent = getIntent();
        mJSONArticleliststr = intent.getStringExtra(JSONARTICLELISTSTR);
        mJSONSignalbitstr = intent.getStringExtra(JSONSIGNALBITSTR);

        mArticleLookupList = new LinkedHashMap<String, String>();

        mRecyclerView = (SlowdownRecyclerView) findViewById(R.id.recyclerview_slowdown);

        LinearLayoutManager layoutManager =
                new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mListIndNewsAdapter = new ListIndNewsAdapter(this,
                this, mJSONArticleliststr, mJSONSignalbitstr);
        mRecyclerView.setAdapter(mListIndNewsAdapter);

        //mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.more_detail);


        //getSupportActionBar().setDisplayShowTitleEnabled(false);
        //getSupportActionBar().setDisplayShowCustomEnabled(true);
        //getSupportActionBar().setCustomView(R.layout.action_bar_title);



        getSupportLoaderManager().initLoader(ID_ARTICLELOOKUP_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_SIGNAL_LOADER, null, this);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        LogUtil.debug(TAG, " onoptionsitemselected 1 " + item.toString());
        switch (item.getItemId()) {
            case android.R.id.home:
                // API 5+ solution
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        LogUtil.debug(TAG, "----> oncreateloader ");
        switch (id) {
            case ID_ARTICLELOOKUP_LOADER:
                Uri articlelookupQueryUri = ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI;
                String articlelookupsortOrder = ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                return new CursorLoader(this,
                        articlelookupQueryUri,
                        ArticleLookupTableContract.PROJECTION,
                        null,
                        null,
                        articlelookupsortOrder);

            case ID_SIGNAL_LOADER:
            default:
                if (id != ID_SIGNAL_LOADER){
                    Log.w(TAG, "Loader Not Implemented: " + id);
                }
                Uri signalQueryUri = SignalContract.SignalEntry.CONTENT_URI;
                String signalsortOrder = SignalContract.SignalEntry.COLUMN_ARTICLE_ID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 3");

                return new CursorLoader(this,
                        signalQueryUri,
                        SignalContract.PROJECTION,
                        null,
                        null,
                        signalsortOrder);



            //default:
            //    throw new RuntimeException("Loader Not Implemented: " + id);
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, "  onloadfinished 1 ");

        switch (loader.getId()) {
            case ID_ARTICLELOOKUP_LOADER:
                if ( (data != null) && (data.getCount() > 0) ){
                    for (int index=0 ; index < data.getCount(); index++){
                        data.moveToPosition(index);
                        mArticleLookupList.put(
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID),
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, "  onloadinfished articlelookup_loader index="
                                + index
                                + ", sheetid="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, "  onloadinfished articlelookup_loader getcount=0");
                }
                LogUtil.debug (TAG, " ID_ARTICLELOOKUP_LOADER mArticleLookupList=" + mArticleLookupList.toString());

                break;
            case ID_SIGNAL_LOADER :
                mListIndNewsAdapter.updateSignalMapFromCursor(data);
                //getActivity().getSupportLoaderManager().destroyLoader(ID_SIGNAL_LOADER);
                LogUtil.debug(TAG, "  onloadfinished 9 loaderid=" + loader.getId());

                break;

            default:
                LogUtil.debug(TAG, "  onloadfinished 10 loaderid=" + loader.getId());
                break;
        }
        data.close();

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        LogUtil.debug(TAG, "----> onloaderreset ");

    }

    @Override
    public void onClickListIndNews(long entryID, String finalurl) {


        for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()){

            if (    (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                    &&  ( entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()) ) ){

                LogUtil.debug( TAG, "  --> onClickLatestNewsPagination 1 entryID=" + entryID);
                Intent intent = new Intent(this, DetailNewsActivity.class);
                intent.putExtra(DetailNewsActivity.SHEET_ID, mapentry.getValue());
                intent.putExtra(DetailNewsActivity.ARTICLE_ID, entryID);
                intent.putExtra(DetailNewsActivity.FINALURL, finalurl);
                intent.putExtra(DetailNewsActivity.ROWID, entryID -
                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1);
                startActivity(intent);
                LogUtil.debug( TAG, "  --> onClickLatestNewsPagination 2 entryID=" + entryID);

                break;
            }
        }
        LogUtil.debug(TAG, " --> onClickLatestNewsPagination 3 ");

    }

    @Override
    public void onClickBookmarkArticleStoreOrRemove(long entryID, boolean save) {
        if (save) {
            for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

                if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                        && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                    LogUtil.debug(TAG, " newsfragment --> onClickBookmarkArticleStoreOrRemove 1 entryID=" + entryID);
                    if (Gongdispatch.isOnline(this)) {
                        Gongdispatch.gsheetfetchOneEntry(this,
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);
                    } else {
                        Gongdispatch.gongdispatchOneEntry(this,
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);
                        Toast.makeText(this, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                    LogUtil.debug(TAG, " newsfragment --> onClickBookmarkArticleStoreOrRemove 2 entryID=" + entryID);
                    break;
                }
            }
            LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 3 ");
        }else {
            //remove
            Uri removeindIDURI = ArticleTableContract.buildArticleUriWithID(entryID);
            String selection = " " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " == ? ";

            int result  = getContentResolver().delete(
                    removeindIDURI,
                    selection,
                    null);
            LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 4 result= " + result);

        }

    }

}
