package com.hk.gonggongnews.ngogong;

/**
 * Created by ismile on 11/5/2017.
 */
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.util.Log;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.database.FirebaseDatabase;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import java.util.Hashtable;
import java.util.Locale;

//tapjoy
//import com.tapjoy.TJConnectListener;
//import com.tapjoy.Tapjoy;
//public class SplashFirstActivity extends AppCompatActivity implements TJConnectListener {
public class SplashFirstActivity extends AppCompatActivity  {

    private final String TAG = SplashFirstActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseAnalytics.getInstance(getApplicationContext())
                .setCurrentScreen(this, "Splash screen", null);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "splash_screen" );
        FirebaseAnalytics.getInstance(getApplicationContext()).logEvent("first_start", bundle);
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(false);
        } catch (com.google.firebase.database.DatabaseException e){
            //because there is no way to check what is the persistenceenabled value so....
            Log.w(TAG, " splashfirstactivity error setpersistenceEnable message=" + e.getMessage());
        }

        LogUtil.debug(TAG, " current_version=" + BuildConfig.VERSION_CODE);

        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String  choiceOfLang = sp.getString(getString(R.string.gong_lang_pref), getString(R.string.choice_value_lang_eng));
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();

        //tapjoy
        //TapjoyGpsHelper: Found advertising ID: 06a7c5df-e0f9-4b96-b40e-f4632abbccda
        //Hashtable<String, Object> connect = new Hashtable<>();
        //Tapjoy.connect(this.getApplicationContext(), "BkDMRJavSLCYRSDQErjvQAECCmKUw19tqMJFdyrkYCEKnpO1soqy0WmPx2bv", null, this);
        //Tapjoy.setDebugEnabled(true);


        String lang = "en_US";
        if (choiceOfLang.compareTo(getString(R.string.choice_value_lang_eng)) == 0){
            //default true zh-rhk
            lang="en_US";
            conf.locale = Locale.ENGLISH;

        } else {
            //english
            lang = "zh_HK";
            conf.locale = Locale.CHINESE;
        }
        Locale myLocale = new Locale(lang);

        //conf.setLocale(myLocale);
        res.getConfiguration();
        res.updateConfiguration(conf, dm);

        int current_appversion = sp.getInt(getString(R.string.current_appversion), 0);
        LogUtil.debug(TAG, " current_version=" + BuildConfig.VERSION_CODE
                + ",current_appversion=" + current_appversion);

        Intent intent;
        if (BuildConfig.VERSION_CODE >= current_appversion) {
            intent = new Intent(this, MainNewsActivity.class);
        } else {
            intent = new Intent(this, GetUpgradeActivity.class);
        }

        startActivity(intent);
        finish();
    }

    //@Override
    //public void onConnectSuccess() {
    //    LogUtil.debug(TAG, " tapjoy onConnectSuccess");
    //}

    //@Override
    //public void onConnectFailure() {
    //    LogUtil.debug(TAG, " tapjoy onConnectFailure");
    //}
}
