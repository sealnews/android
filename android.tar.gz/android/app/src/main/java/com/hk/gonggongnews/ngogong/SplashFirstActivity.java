package com.hk.gonggongnews.ngogong;

/**
 * Created by ismile on 11/5/2017.
 */
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import java.util.Locale;

public class SplashFirstActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseAnalytics.getInstance(this)
                .setCurrentScreen(this, "Splash screen", null);
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "splash_screen" );
        FirebaseAnalytics.getInstance(this).logEvent("first_start", bundle);


        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        String  choiceOfLang = sp.getString(getString(R.string.gong_lang_pref), getString(R.string.choice_value_lang_eng));
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();

        String lang = "en_US";
        if (choiceOfLang.compareTo(getString(R.string.choice_value_lang_eng)) == 0){
            //default true zh-rhk
            lang="en_US";
            conf.locale = Locale.ENGLISH;

        } else {
            //english
            lang = "zh_HK";
            conf.locale = Locale.CHINESE;
        }
        Locale myLocale = new Locale(lang);

        //conf.setLocale(myLocale);
        res.getConfiguration();
        res.updateConfiguration(conf, dm);



        Intent intent = new Intent(this, MainNewsActivity.class);
        startActivity(intent);
        finish();
    }
}
