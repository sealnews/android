package com.hk.gonggongnews.ngogong.sync;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.util.Log;

import com.hk.gonggongnews.ngogong.util.LogUtil;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
import com.google.api.client.googleapis.extensions.android.gms.auth.GooglePlayServicesAvailabilityIOException;
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException;

import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpRequestInitializer;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.ExponentialBackOff;

import com.google.api.services.sheets.v4.SheetsScopes;

import com.google.api.services.sheets.v4.model.*;


import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetRequest;
import com.google.api.services.sheets.v4.model.BatchUpdateSpreadsheetResponse;
import com.google.api.services.sheets.v4.model.Request;


import com.hk.gonggongnews.ngogong.data.ArchiveLatestLookupContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.FragArticleArcTableContract;
import com.hk.gonggongnews.ngogong.data.GongInfoContract;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationArcContract;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pub.devrel.easypermissions.AfterPermissionGranted;
import pub.devrel.easypermissions.EasyPermissions;

/**
 * Created by ismile on 10/31/2017.
 */

public class GSheetQuery {
    private static com.google.api.services.sheets.v4.Sheets mService = null;

    private final String TAG = GSheetQuery.class.getSimpleName();
    // 20180110.2231 private final String SHEETKEYAPI = "AIzaSyCtbHWcC5q1eWX2Ozj7mCiGZSP9uCjKOVA";
    // ques c
    private final String SHEETKEYAPI = "AIzaSyBtEUd5lFe5-rHijpPM_gEfl6p2eOaRgJk";
    private static GSheetQuery mInstance;



    public static void init() {
        mInstance = new GSheetQuery();
    }

    public static GSheetQuery getInstance() {
        if (mInstance == null) {
            mInstance = new GSheetQuery ();
            return mInstance;
        } else {
            return mInstance;
        }
    }

    private GSheetQuery() {
        HttpTransport transport = AndroidHttp.newCompatibleTransport();
        JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
        mService = new com.google.api.services.sheets.v4.Sheets.Builder(
                transport, jsonFactory, new HttpRequestInitializer() {
            @Override
            public void initialize(HttpRequest request) throws IOException {

            }
        }).setApplicationName("ngogong app")
                .build();
    }

    public List<ContentValues> getDataFromApiWithOneID(String spreadsheetId,
                                                       long rowID) {

        try {
            //String spreadsheetId = "1zJNCn_Wp7QrHhy2JtKgIFYayksJJ-hK6YgpYD9opdXk";
            LogUtil.debug(TAG, " getDataFromApiWithOneID 1 ");
            String range = "Sheet1!A" + String.valueOf(rowID) + ":J" + String.valueOf(rowID);
            List<ContentValues> results = new ArrayList<ContentValues>();
            ValueRange response = mService.spreadsheets().values()
                    .get(spreadsheetId, range)
                    .set("key", SHEETKEYAPI)
                    .execute();
            LogUtil.debug(TAG, " getDataFromApiWithOneID 1.1 ");
            List<List<Object>> values = response.getValues();
            if (values != null) {
                for (List row : values) {
                    ContentValues contentValue = new ContentValues();
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID,
                            Integer.valueOf((String) row.get(0)));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                            Integer.valueOf((String) row.get(1)));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_FINALURL,
                            (String) row.get(2));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_TIMESTAMPONDOC,
                            Long.valueOf((String) row.get(3)));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_TIMESTAMPONRETRIEVE,
                            Long.valueOf((String) row.get(4)));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_TITLE,
                            (String) row.get(5));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_CONTENT,
                            (String) row.get(6));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_IMAGEURL,
                            (String) row.get(7));

                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_SIMILARITIESLIST,
                            (String) row.get(8));
                    contentValue.put(ArticleTableContract.ArticleEntry.COLUMN_SIMILARITIESCOUNT,
                            Integer.valueOf((String) row.get(9)));
                    results.add(contentValue);
                }
            }
            /*
            if (values != null) {
                results.add("Name, Major");
                for (List row : values) {
                    results.add(row.get(0) + ", " + row.get(4));
                }
            }
            return results;
            */
            LogUtil.debug(TAG, " getDataFromApiWithOneID 2 ");

            return results;
        } catch (Exception e) {
            Log.e(TAG, "gsheetquery exception rowid=" + rowID + ",sheetid=" + spreadsheetId + "  errormessage=" + e.getMessage());
            return null;
        }
    }

    public List<ContentValues> getDataFromApiWithOneBlock(String spreadsheetId,
                                                          String startColumn,
                                                          String endColumn) {
        return getDataFromApiWithOneBlockName(spreadsheetId,startColumn,endColumn,null);
    }
    public List<ContentValues> getDataFromApiWithOneBlockName(String spreadsheetId,
                                                              String startColumn,
                                                              String endColumn,
                                                              String name
                                                              ) {
        return getDataFromApiWithOneBlockNameCat(spreadsheetId,startColumn,endColumn,null,0);

    }

        public List<ContentValues> getDataFromApiWithOneBlockNameCat(String spreadsheetId,
                                                          String startColumn,
                                                          String endColumn,
                                                          String name,
                                                          int categoryid) {
        String range = "Sheet1!" + startColumn + ":" + endColumn;
        String retrieveurl = "nothing";
        String retrievetemplate = "nothing";
        try {
            //String spreadsheetId = "1zJNCn_Wp7QrHhy2JtKgIFYayksJJ-hK6YgpYD9opdXk";
            range = "Sheet1!" + startColumn + ":" + endColumn;
            List<ContentValues> results = new ArrayList<ContentValues>();

            retrieveurl = mService.spreadsheets().values().get(spreadsheetId, range).set("key", SHEETKEYAPI).buildHttpRequest().getUrl().build();
            retrievetemplate = mService.spreadsheets().values().get(spreadsheetId,range).getUriTemplate();
            //retrieveurl2 = this.mService.spreadsheets().values().get(spreadsheetId,range).setSpreadsheetId(spreadsheetId).setRange(range).set("key", SHEETKEYAPI).buildHttpRequest().getUrl().build();
            //HttpRequest httpRequest = this.mService.spreadsheets().values().get(spreadsheetId, range).set("key", SHEETKEYAPI).buildHttpRequest();
            //Sheets.Spreadsheets.Values.Get testget=this.mService.spreadsheets().values().get(spreadsheetId, range).set("key", SHEETKEYAPI);


            ValueRange response = mService.spreadsheets().values()
                    .get(spreadsheetId, range)
                    .set("key", SHEETKEYAPI)
                    .execute();
            List<List<Object>> values = response.getValues();
            if (values != null) {
                for (List row : values) {
                    ContentValues contentValue = new ContentValues();
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_ARTICLEID,
                            Integer.valueOf((String) row.get(0)));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_FIRSTSUBDOMAINTABLE_ID,
                            Integer.valueOf((String) row.get(1)));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_FINALURL,
                            (String) row.get(2));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_IMAGEURL,
                            (String) row.get(3));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_SIMILARITIESCOUNT,
                            Long.valueOf((String) row.get(4)));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_TIMESTAMPONDOC,
                            Long.valueOf((String) row.get(5)));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_TITLE,
                            (String) row.get(6));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_ENTRY,
                            (String) row.get(7));
                    contentValue.put(LatestNewsPaginationArcContract.PaginationArcEntry.COLUMN_TIMESTAMPONDOC_AND_ID,
                            ("0000000000" + (String) row.get(5)).substring(((String) row.get(5)).length())
                            + "Z"
                            + ("0000000000" + (String) row.get(0)).substring(((String) row.get(0)).length()) );
                    if (name!=null){
                        contentValue.put(GongInfoContract.GongInfoEntry.COLUMN_NAME,
                                name);

                    }
                    if (categoryid != 0){
                        contentValue.put(FragArticleArcTableContract.FragArticleArcEntry.COLUMN_CATEGORYTABLE_ID,
                                categoryid);

                    }
                    results.add(contentValue);
                }
            }
            return results;
        } catch (Exception e) {
            Log.e(TAG, "gsheetquery exception spreadsheetid=" + spreadsheetId
                     + ",startcolumn=" + startColumn
                     + ",endcolumn=" + endColumn
                     + ",name=" + name
                     + ",categoryid=" + categoryid
                     + ",buildedurl=" + retrieveurl
                     + ",template=" + retrievetemplate
                     + ", getDataFromApiWithOneBlock exception=" + e.getMessage());
            return null;
        }
    }


    public void testapi() {
        try {
            //String spreadsheetId = "1zJNCn_Wp7QrHhy2JtKgIFYayksJJ-hK6YgpYD9opdXk";
            //String range = "Sheet1!A" + String.valueOf(rowID) + ":J" + String.valueOf(rowID);

            String spreadsheetId = "1VDQJsDXCc5s6JEhXrMVKrvyeBXxND1OKedVvcQl26qU"; // TODO: Update placeholder value.

            // A list of updates to apply to the spreadsheet.
            // Requests will be applied in the order they are specified.
            // If any request is not valid, no requests will be applied.
            List<Request> requests = new ArrayList<>(); // TODO: Update placeholder value.

            // TODO: Assign values to desired fields of `requestBody`:
            BatchUpdateSpreadsheetRequest requestBody = new BatchUpdateSpreadsheetRequest();
            requestBody.setRequests(requests);

            SortRangeRequest sortRangeRequest = new SortRangeRequest();
            GridRange gridRange = new GridRange();
            Request indrequest = new Request();
            AddFilterViewRequest addFilterViewRequest = new AddFilterViewRequest();
            FilterView filterView = new FilterView();
            addFilterViewRequest.setFilter(filterView);
            Map<String, FilterCriteria> mapFilterCriteria = new HashMap<>();
            FilterCriteria filterCriteria = new FilterCriteria();
            BooleanCondition booleanCondition = new BooleanCondition();

            //List<String> booleanconditionVaules = new ArrayList<>();
            //String booleanconditionVaulesString = "11";
            //booleanconditionVaules.add(booleanconditionVaulesString);

            List<ConditionValue> list_condition_value = new ArrayList<>();
            ConditionValue conditionValue = new ConditionValue();
            conditionValue.setUserEnteredValue("11");
            list_condition_value.add(conditionValue);
            booleanCondition.setType("NUMBER_EQ");
            booleanCondition.setValues(list_condition_value);
            filterCriteria.setCondition(booleanCondition);
            mapFilterCriteria.put("B", filterCriteria);
            filterView.setCriteria(mapFilterCriteria);

            indrequest.setAddFilterView(addFilterViewRequest);
            requests.add(indrequest);

            DataFilter dataFilter = new DataFilter();


            Sheets sheetsService = mService;
            Sheets.Spreadsheets.BatchUpdate request =
                    sheetsService.spreadsheets().batchUpdate(spreadsheetId, requestBody);

            BatchUpdateSpreadsheetResponse responsetest = request.execute();

            // TODO: Change code below to process the `response` object:
            System.out.println(responsetest);


        } catch (Exception e) {
            LogUtil.debug(TAG, "gsheetquery exception=" + e.getMessage());
        }


    }

    public static long decodeGetLowerBound(String range) {
        String result  = range.split("ZZ")[0];
        return Long.valueOf(result);
    }

    public static long decodeGetHigherBound(String range) {
        String result = range.split("ZZ")[1];
        return Long.valueOf(result);
    }


}
