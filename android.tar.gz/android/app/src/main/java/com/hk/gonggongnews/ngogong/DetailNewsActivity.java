package com.hk.gonggongnews.ngogong;

/**
 * Created by ismile on 11/2/2017.
 */

/**
 * Created by ismile on 9/17/2017.
 */

import android.content.ContentValues;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;

import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;

import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.GongProvider;
import com.hk.gonggongnews.ngogong.data.LatestNewsPaginationContract;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.sync.GSheetQuery;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;
import com.hk.gonggongnews.ngogong.thirdparty.BottomSheetCoordinatorBehavior;
import com.hk.gonggongnews.ngogong.thirdparty.BottomSheetInsetsBehavior;
import com.hk.gonggongnews.ngogong.thirdparty.BottomSheetCoordinatorLayout;
import com.hk.gonggongnews.ngogong.util.GongTimeUtil;

//import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.DisplayMetrics;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

/**
 * Created by ismile on 9/9/2017.
 */
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
//import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by ismile on 9/18/2017.
 */

public class DetailNewsActivity  extends AppCompatActivity implements LoaderManager.LoaderCallbacks<Cursor> {

    public static final String ARTICLE_ID = "article_id";
    public static final String SHEET_ID = "sheet_id";
    public static final String FINALURL = "finalurl";
    public static final String ROWID = "rowid";


    private BottomSheetCoordinatorBehavior bottomSheetBehavior ;
    private static final String TAG = DetailNewsActivity.class.getSimpleName();
    private float  mBottomSheetBehaviorX ;
    private float  mBottomSheetBehaviorY ;
    private final int mPeekHeight =100;
    private int mScreenWidth;
    private int mScreenHeight;
    private float mLatestSlideValue ;

    private CollapsingToolbarLayout collapsingToolbarLayout;
    private android.support.v7.app.ActionBar  mActionbar;

    private GestureDetectorCompat mDetector;
    private  boolean updatemBottomSheetBehaviorY=false;


    private long mArticleID;
    private String mFinalurl;
    private String mSheetID;
    private Cursor mCursor;
    private long mRowID;
    private static final String FINALURL_DEFAULT = "https://www.google.com";
    private static final String SHEETID_DEFAULT = "1zJNCn_Wp7QrHhy2JtKgIFYayksJJ-hK6YgpYD9opdXk";

    private ImageView mImageView;
    private TextView mTVTitle;
    private TextView mTVDescription;
    private ImageButton mIBBookmark;
    private ImageView mIV_sourceiconexpandoneView;
    private TextView mTV_domainsourceexpandoneView;
    private TextView mTV_dateexpandoneView;
    private LinearLayout mLL_inside_toolbar_linearlayout;

    private boolean mBookmarkAlready=false;
    private Map<String, String> mArticleLookupList;

    private static final int ID_ARTICLE_LOADER = 100;
    private static final int ID_SIGNAL_ID_LOADER = 101;
    private static final int ID_ARTICLELOOKUP_LOADER = 102;

    private Context mContext;


    private WebView mWebView;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        View viewBottomSheet = findViewById(R.id.bottom_sheet) ;
        int [] location = new int[2];
        viewBottomSheet.getLocationOnScreen(location);
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged --- location[x0]=" + location[0] );
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged --- location[y1]=" + location[1] );
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged --- getWidth=" + viewBottomSheet.getWidth() );
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged --- getHeight=" + viewBottomSheet.getHeight() );
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged --- getX=" + viewBottomSheet.getX() );
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged --- getY=" + viewBottomSheet.getY() );

        mBottomSheetBehaviorX =  viewBottomSheet.getX();
        mBottomSheetBehaviorY =  viewBottomSheet.getY();

        View viewtoolbar = findViewById(R.id.toolbar);
        int [] locationtoolbar = new int[2];
        viewtoolbar.getLocationOnScreen(location);
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- location[x0]=" + locationtoolbar[0] );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- location[y1]=" + locationtoolbar[1] );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- getWidth=" + viewtoolbar.getWidth() );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- getHeight=" + viewtoolbar.getHeight() );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- getX=" + viewtoolbar.getX() );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- getY=" + viewtoolbar.getY() );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- getpaddingtop=" + viewtoolbar.getPaddingTop() );
        LogUtil.debug(TAG, "viewtoolbar onWindowFocusChanged --- getpaddingbottom=" + viewtoolbar.getPaddingBottom() );

        View viewimage = findViewById(R.id.image);
        locationtoolbar = new int[2];
        viewtoolbar.getLocationOnScreen(location);
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- location[x0]=" + locationtoolbar[0] );
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- location[y1]=" + locationtoolbar[1] );
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- getWidth=" + viewimage.getWidth() );
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- getHeight=" + viewimage.getHeight() );
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- getX=" + viewimage.getX() );
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- getY=" + viewimage.getY() );

        float scale = getResources().getDisplayMetrics().density;
        float scaledensity = getResources().getDisplayMetrics().scaledDensity;
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- scale=" + scale );
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- scaledensity=" + scaledensity );
        int dpAsPixels = (int) (56*scale + 0.5f);
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- dpAsPixels=" + dpAsPixels);
        LogUtil.debug(TAG, "viewimage onWindowFocusChanged --- getheight*1/1/scale=" + (viewtoolbar.getHeight() * (1 / (1/scale) + 0.5f)));
        viewimage.setPadding(viewimage.getPaddingLeft(),viewtoolbar.getHeight(),
                viewimage.getPaddingRight(), viewimage.getPaddingBottom());
        ViewGroup.LayoutParams lp = (ViewGroup.LayoutParams) viewimage.getLayoutParams();
        ViewGroup.LayoutParams lp1 = (ViewGroup.LayoutParams) viewtoolbar.getLayoutParams();


        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged displaymetrics --- width" +
                Resources.getSystem().getDisplayMetrics().widthPixels  );
        LogUtil.debug(TAG, "bottomsheetbehavior onWindowFocusChanged displaymetrics --- height" +
                Resources.getSystem().getDisplayMetrics().heightPixels);

        mScreenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;
        mScreenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
        bottomSheetBehavior.setPeekHeight(viewtoolbar.getHeight() );
        //bottomSheetBehavior.setPeekHeight(viewtoolbar.getHeight() - dpAsPixels );
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_news);

        Intent intent = getIntent();
        mArticleID = intent.getLongExtra(ARTICLE_ID, 0);
        mFinalurl = intent.getStringExtra(FINALURL);
        mSheetID = intent.getStringExtra(SHEET_ID);
        mRowID = intent.getLongExtra(ROWID, 0);

        mContext = this;

        mArticleLookupList = new HashMap<>();
        mIBBookmark = findViewById(R.id.ib_bookmark);
        mIBBookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = SignalContract.SignalEntry.CONTENT_URI;

                LogUtil.debug(TAG, " ib_bookmarkButton onclick 1");
                ContentValues contentValues = new ContentValues();
                contentValues.put(SignalContract.SignalEntry.COLUMN_ARTICLE_ID, (int) mArticleID);

                if (view.isSelected() == false) {
                    view.setSelected(true);
                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 1);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 2");
                    for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

                        if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= mArticleID)
                                && (mArticleID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                            LogUtil.debug(TAG, "  --> mIBBookmark.setOnClickListener 1 entryID=" + mArticleID);
                            if (Gongdispatch.isOnline(getApplicationContext())) {
                                Gongdispatch.gsheetfetchOneEntry(getApplicationContext(),
                                        mapentry.getValue(),
                                        mArticleID -
                                                (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                        mArticleID);
                            } else {
                                Toast.makeText(getApplicationContext(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                            }

                            LogUtil.debug(TAG, "  --> mIBBookmark.setOnClickListener 2 entryID=" + mArticleID);
                            break;
                        }
                    }


                } else {
                    //set it off
                    view.setSelected(false);

                    contentValues.put(SignalContract.SignalEntry.COLUMN_BOOKMARKALREADY, 0);
                    LogUtil.debug(TAG, " ib_bookmarkButton onclick 3 ");
                    Uri removeindIDURI = ArticleTableContract.buildArticleUriWithID(mArticleID);
                    String selection = " " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " == ? ";

                    int result  = getContentResolver().delete(
                            removeindIDURI,
                            selection,
                            null);
                    LogUtil.debug(TAG, "newsfragment --> onClickBookmarkArticleStoreOrRemove 4 result= " + result);

                }
                getContentResolver().insert(
                        uri,
                        contentValues);

            }
        });


        ImageButton shareImageButton = (ImageButton) findViewById(R.id.ib_share);
        shareImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LogUtil.debug(TAG, " ib_sharebutton 1");
                String finalurl = mFinalurl;
                String title = (String) mTVTitle.getText();

                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                String shareBody = title + "\n" + finalurl;
                String shareSub = title;
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, shareSub);
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
                startActivity(Intent.createChooser(sharingIntent, "Share using"));
                LogUtil.debug(TAG, " ib_sharebutton 2");

            }
        });

        final View viewBottomSheet = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetCoordinatorBehavior.from((BottomSheetCoordinatorLayout) viewBottomSheet);
        bottomSheetBehavior.setHideable(true);
        //bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        bottomSheetBehavior.setState(BottomSheetCoordinatorBehavior.STATE_COLLAPSED);
        //bottomSheetBehavior.setPeekHeight(mPeekHeight);

        bottomSheetBehavior.setBottomSheetCallback(new BottomSheetCoordinatorBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {

                switch (newState) {

                    case BottomSheetCoordinatorBehavior.STATE_COLLAPSED:{

                        LogUtil.debug("BSB","collapsed") ;
                    }
                    case BottomSheetCoordinatorBehavior.STATE_SETTLING:{

                        LogUtil.debug("BSB","settling") ;
                    }
                    case BottomSheetCoordinatorBehavior.STATE_EXPANDED:{

                        LogUtil.debug("BSB","expanded") ;
                    }
                    case BottomSheetCoordinatorBehavior.STATE_HIDDEN: {

                        LogUtil.debug("BSB" , "hidden") ;
                    }
                    case BottomSheetCoordinatorBehavior.STATE_DRAGGING: {

                        LogUtil.debug("BSB","dragging") ;
                    }
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
                mLatestSlideValue = slideOffset;
                LogUtil.debug("BSB","sliding " + slideOffset ) ;
            }
        });


        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        mActionbar = getSupportActionBar();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //getSupportActionBar().setTitle(R.string.simple_display_backup);
        //getSupportActionBar().setDisplayShowTitleEnabled(true);



//        getSupportActionBar().setDisplayShowTitleEnabled(false);
//        getSupportActionBar().setDisplayShowCustomEnabled(true);
//        getSupportActionBar().setCustomView(R.layout.action_bar_title);


        mLL_inside_toolbar_linearlayout = (LinearLayout) findViewById(R.id.inside_toolbar_linearlayout);



        collapsingToolbarLayout = (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        //collapsingToolbarLayout.setTitle(itemTitle);
        //collapsingToolbarLayout.setTitleEnabled(false);
        collapsingToolbarLayout.setExpandedTitleColor(getResources().getColor(android.R.color.transparent));

        AppBarLayout appBarLayout = (AppBarLayout) findViewById(R.id.app_bar_layout);
        appBarLayout.addOnOffsetChangedListener(new AppBarLayout.OnOffsetChangedListener() {
            boolean isShow = false;
            int scrollRange = -1;

            @Override
            public void onOffsetChanged(AppBarLayout appBarLayout, int verticalOffset) {

                if (scrollRange == -1) {
                    scrollRange = appBarLayout.getTotalScrollRange();
                }
                LogUtil.debug(TAG, "vertical - 1 scrollRange=" + scrollRange + ", verticalOffset=" + verticalOffset + ",isshow=" + isShow);
                LogUtil.debug(TAG, "vertical - 2 scrollRange=" + appBarLayout.getTotalScrollRange() + ", verticalOffset=" + verticalOffset + ",isshow=" + isShow);
                //when the first time ony show peek scrollrange=0/-608 , verticaloffset=-1, isshow=false
                //full expand scrollrange=0/-608 , verticaloffset=-1, isshow=false
                //moving show title and description  expand scrollrange=0/-608 , verticaloffset=-608, isshow=false
                //back to full expand scrollrange=0/-608 , verticaloffset=0, isshow=true
                //back down only show peek expand scrollrange=0/-608 , verticaloffset=0, isshow=true


                /*
                if ( (verticalOffset == -1) || (verticalOffset == 0)) {
                    //appBarLayout.getLocationOnScreen();
                    collapsingToolbarLayout.setTitleEnabled(false);
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setTitle(" helloworld-2");
                    mActionbar.setDisplayShowTitleEnabled(true);

                }
                */

                if ( verticalOffset < -1){
                    collapsingToolbarLayout.setTitleEnabled(true);
                    collapsingToolbarLayout.setTitle(mTVTitle.getText());
                    mLL_inside_toolbar_linearlayout.setVisibility(View.GONE);
//                    getSupportActionBar().setDisplayShowCustomEnabled(false);
                    //mActionbar.setDisplayShowTitleEnabled(true);
                    LogUtil.debug(TAG, "vertical 0 ");

                } else {
                    collapsingToolbarLayout.setTitleEnabled(false);
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    mLL_inside_toolbar_linearlayout.setVisibility(View.VISIBLE);
//                    getSupportActionBar().setDisplayShowCustomEnabled(true);

                    //getSupportActionBar().setTitle(R.string.simple_display);
                    //mActionbar.setDisplayShowTitleEnabled(true);

                    /*
                    //mActionbar.setBackgroundDrawable(getResources().getDrawable(R.drawable.actionbar_background));
                    View viewActionBar = getLayoutInflater().inflate(R.layout.action_bar_title, null);
                    ActionBar.LayoutParams params = new ActionBar.LayoutParams(//Center the textview in the ActionBar !
                            ActionBar.LayoutParams.WRAP_CONTENT,
                            ActionBar.LayoutParams.MATCH_PARENT,
                            Gravity.CENTER);
                    TextView textviewTitle = (TextView) viewActionBar.findViewById(R.id.actionbar_textview);
                    textviewTitle.setText(R.string.simple_display);
                    getSupportActionBar().setCustomView(viewActionBar, params);
                    getSupportActionBar().setDisplayShowCustomEnabled(true);
                    getSupportActionBar().setDisplayShowTitleEnabled(true);
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_HOME_AS_UP |
                            ActionBar.DISPLAY_SHOW_CUSTOM );
                    */
                    LogUtil.debug(TAG, "vertical 1 ");

                }

                /*

                if (scrollRange + verticalOffset == 0) {
                    //fully collapsed the actionbar to the top
                    collapsingToolbarLayout.setTitleEnabled(false);
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setTitle(" helloworld----1");
                    mActionbar.setDisplayShowTitleEnabled(true);


                    //collapsingToolbarLayout.setTitle(" vertical0");
                    //collapsingToolbarLayout.setTitleEnabled(true);
                    //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    //getSupportActionBar().setTitle(" helloworld-0");
                    //getSupportActionBar().show();
                    //mActionbar.setDisplayShowTitleEnabled(true);


                    isShow = true;
                    LogUtil.debug(TAG, "vertical 0 ");
                } else if (isShow) {
                    //either dragging or expanding.
                    //collapsingToolbarLayout.setTitle(" vertical1");//carefull there should a space between double quote otherwise it wont work

                    collapsingToolbarLayout.setTitleEnabled(false);
                    isShow = false;
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setTitle(" helloworld-1");
                    mActionbar.setDisplayShowTitleEnabled(true);
                    LogUtil.debug(TAG, "vertical 1 ");
                } else {
                    //scroolrange =0 , verticaloffset=-1, isshow=false
                    //scroolrange =0 , verticaloffset=0, isshow=true
                    collapsingToolbarLayout.setTitleEnabled(false);
                    getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                    getSupportActionBar().setTitle(" helloworld-2");
                    mActionbar.setDisplayShowTitleEnabled(true);
                    isShow = false;

                    LogUtil.debug(TAG, "vertical 2 ");
                }
                */

                LogUtil.debug(TAG, "vertical 3 ");
            }
        });




        mImageView = (ImageView) findViewById(R.id.image);
        mImageView.setImageResource(R.drawable.ic_tmp_icon);

        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.setWebViewClient(new WebViewClient());
        mWebView.getSettings().setBuiltInZoomControls(true);
        //myWebView.getSettings().setSupportZoom(true);
        mWebView.getSettings().setDisplayZoomControls(true);
        mWebView.getSettings().setAllowFileAccess(false);
        mWebView.getSettings().setDatabaseEnabled(false);
        mWebView.getSettings().setJavaScriptEnabled(true);

        //myWebView.getSettings().setSafeBrowsingEnabled(true);
        //mWebView.loadUrl(mFinalurl);
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        TextView textView = (TextView) findViewById(R.id.webview_not_connected);
        if (networkInfo != null && networkInfo.isConnected()){
            mWebView.setVisibility(View.VISIBLE);
            textView.setVisibility(View.GONE);
        } else {
            mWebView.setVisibility(View.GONE);
            textView.setVisibility(View.VISIBLE);
        }


        LogUtil.debug(TAG, " mywebview.loadurl = "+ mFinalurl);
        mDetector = new GestureDetectorCompat(this, new DetailNewsActivity.MyGestureListener());

        mTVDescription = (TextView) findViewById(R.id.description);
        mTVTitle = (TextView) findViewById(R.id.title);
        mIV_sourceiconexpandoneView = (ImageView) findViewById(R.id.iv_sourceiconexpandone);
        mTV_domainsourceexpandoneView =  (TextView) findViewById(R.id.tv_domainsourceexpandone);
        mTV_dateexpandoneView =  (TextView) findViewById(R.id.tv_dateexpandone);



        getSupportLoaderManager().initLoader(ID_ARTICLE_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_SIGNAL_ID_LOADER, null, this);
        getSupportLoaderManager().initLoader(ID_ARTICLELOOKUP_LOADER, null, this);



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        LogUtil.debug(TAG, " onoptionsitemselected 1 " + item.toString());
        switch (item.getItemId()) {
            case android.R.id.home:
                // API 5+ solution
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
        //return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        final int action = MotionEventCompat.getActionMasked(ev);

        View viewBottomSheet = findViewById(R.id.bottom_sheet) ;
        int [] location = new int[2];
        viewBottomSheet.getLocationOnScreen(location);
        LogUtil.debug(TAG, "bottomsheetbehavior dispatchTouchEvent --- location[x0]=" + location[0] );
        LogUtil.debug(TAG, "bottomsheetbehavior dispatchTouchEvent --- location[y1]=" + location[1] );
        LogUtil.debug(TAG, "bottomsheetbehavior dispatchTouchEvent --- getWidth=" + viewBottomSheet.getWidth() );
        LogUtil.debug(TAG, "bottomsheetbehavior dispatchTouchEvent --- getHeight=" + viewBottomSheet.getHeight() );
        LogUtil.debug(TAG, "bottomsheetbehavior dispatchTouchEvent --- getX=" + viewBottomSheet.getX() );
        LogUtil.debug(TAG, "bottomsheetbehavior dispatchTouchEvent --- getY=" + viewBottomSheet.getY() );
        if (updatemBottomSheetBehaviorY == false) {
            mBottomSheetBehaviorX = viewBottomSheet.getX();
            mBottomSheetBehaviorY = viewBottomSheet.getY();
            updatemBottomSheetBehaviorY =true;
        }

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                LogUtil.debug(TAG, ".....................dispatchTouchEvent action_down.... ");
                break;
            case MotionEvent.ACTION_MOVE:
//                LogUtil.debug(TAG, ".....................dispatchTouchEvent action_move.... ");
                break;
            case MotionEvent.ACTION_UP:
                LogUtil.debug(TAG, ".....................dispatchTouchEvent action_up.... ");
                break;
            case MotionEvent.ACTION_CANCEL:
                LogUtil.debug(TAG, ".....................dispatchTouchEvent action_cancel.... ");
                break;
        }
        //LogUtil.debug(TAG, ".....................dispatchTouchEvent all.... ");
        this.mDetector.onTouchEvent(ev);

        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        LogUtil.debug(TAG, ".....................onTouchEvent.... ");
        View viewBottomSheet = findViewById(R.id.bottom_sheet) ;
        int [] location = new int[2];
        viewBottomSheet.getLocationOnScreen(location);
        LogUtil.debug(TAG, "bottomsheetbehavior onTouchEvent --- location[x0]=" + location[0] );
        LogUtil.debug(TAG, "bottomsheetbehavior onTouchEvent --- location[y1]=" + location[1] );
        LogUtil.debug(TAG, "bottomsheetbehavior onTouchEvent --- getWidth=" + viewBottomSheet.getWidth() );
        LogUtil.debug(TAG, "bottomsheetbehavior onTouchEvent --- getHeight=" + viewBottomSheet.getHeight() );
        LogUtil.debug(TAG, "bottomsheetbehavior onTouchEvent --- getX=" + viewBottomSheet.getX() );
        LogUtil.debug(TAG, "bottomsheetbehavior onTouchEvent --- getY=" + viewBottomSheet.getY() );

        this.mDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Uri indIDURI;
        String order;
        switch (id) {

            case ID_ARTICLE_LOADER:
                /* URI for all rows of weather data in our weather table */
                indIDURI = ArticleTableContract.buildArticleUriWithID(mArticleID);

                order = ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 1 indinduri=" + indIDURI);

                return new CursorLoader(this,
                        indIDURI,
                        ArticleTableContract.PROJECTION,
                        null,
                        null,
                        order);


            case ID_ARTICLELOOKUP_LOADER:
                Uri articlelookupQueryUri = ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI;
                String articlelookupsortOrder = ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 3");

                return new CursorLoader(this,
                        articlelookupQueryUri,
                        ArticleLookupTableContract.PROJECTION,
                        null,
                        null,
                        articlelookupsortOrder);


            case ID_SIGNAL_ID_LOADER:
            default:
                /* URI for all rows of weather data in our weather table */
                indIDURI = SignalContract.buildSignalUriWithID(mArticleID);

                order = SignalContract.SignalEntry.COLUMN_ARTICLE_ID+ " ASC";
                LogUtil.debug(TAG, "----> oncreateloader 2");

                if (id != ID_SIGNAL_ID_LOADER){
                    Log.w(TAG, " wrong loader id = " + id);
                }
                return new CursorLoader(this,
                        indIDURI,
                        SignalContract.PROJECTION,
                        null,
                        null,
                        order);
                //throw new RuntimeException("Loader Not Implemented: " + id);
        }
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, " detailnewsactivity onloadfinished 1 ");
        /*
        private long mArticleID;
        private String mFinalurl;
        private String mSheetID;
        private static final String FINALURL_DEFAULT = "https://www.google.com";
        private static final String SHEETID_DEFAULT = "1zJNCn_Wp7QrHhy2JtKgIFYayksJJ-hK6YgpYD9opdXk";

        private ImageView mImageView;
        private TextView mTVTitle;
        private TextView mTVDescription;
        */

        switch (loader.getId()) {
            case ID_ARTICLE_LOADER:
                LogUtil.debug(TAG, " ID_ARTICLE_LOADER onLoadFinished 1 ");
                if ((data != null) && (data.getCount() == 1)) {
                    //it should not have one row
                    LogUtil.debug(TAG, " ID_ARTICLE_LOADER onLoadFinished 2 ");
                    data.moveToPosition(0);
                    mCursor = data;
                    String content = data.getString(ArticleTableContract.INDEX_CONTENT);
                    String title = data.getString(ArticleTableContract.INDEX_TITLE);
                    String imageurl = data.getString(ArticleTableContract.INDEX_IMAGEURL);
                    DisplayMetrics displaymetrics = new DisplayMetrics();
                    getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
                    int ht = displaymetrics.heightPixels;
                    int wt = displaymetrics.widthPixels;

                    LogUtil.debug (TAG, " ID_ARTICLE_LOADER onLoadFinished 3 ht="+ ht +", wt=" + wt);

                    ArrayList<String> oneSourceIconURLChiName = SourceInfo.getInstance()
                            .getSourceIconURLAndName(data.getInt(ArticleTableContract.INDEX_FIRSTSUBDOMAINTABLE_ID));

                    GlideApp.with(this)
                            .load(oneSourceIconURLChiName.get(SourceInfo.ARRAY_SOURCEICONURL_POS))
                            .placeholder(R.drawable.ic_tmp_icon)
                            .fitCenter()
                            .into(mIV_sourceiconexpandoneView);

                    mTV_domainsourceexpandoneView.setText(
                            oneSourceIconURLChiName.get(SourceInfo.ARRAY_NAME_POS));

                    String timeString = GongTimeUtil.getDisplayTimeStringFromData((long) data.getLong(ArticleTableContract.INDEX_TIMESTAMPONDOC),
                            this);
                    mTV_dateexpandoneView.setText(timeString);

                    mTVTitle.setText(title);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N ){
                        mTVDescription.setText(Html.fromHtml(content,Html.FROM_HTML_MODE_COMPACT));
                    } else {
                        mTVDescription.setText(Html.fromHtml(content));
                    }
                    if (imageurl.compareTo("EMPTYSTRINGVALUE") ==0) {
                        mImageView.setImageResource(R.drawable.ic_logo_hourglass_question);
                    } else {
                        GlideApp.with(this)
                                .load(imageurl)
                                .placeholder(R.drawable.ic_tmp_icon)
                                .fitCenter()
                                .override(wt)
                                .into(mImageView);
                    }

                    if (mWebView.getVisibility() == View.VISIBLE) {
                        LogUtil.debug(TAG, " ID_ARTICLE_LOADER onLoadFinished 3.1 ");
                        mWebView.loadUrl(mFinalurl);
                        LogUtil.debug(TAG, " ID_ARTICLE_LOADER onLoadFinished 3.2 ");
                    }

                } else if ((data != null) && (data.getCount() == 0)) {
                    LogUtil.debug(TAG, " ID_ARTICLE_LOADER onloadfinished 4 , it should be getcount=1  mSheetid="
                            + mSheetID
                            +",mRowid=" + mRowID
                            +",mArticleID=" + mArticleID );
                    if (Gongdispatch.isOnline(this)) {
                        Gongdispatch.gsheetfetchOneEntry(this, mSheetID, mRowID, mArticleID);
                    }else {
                        Toast.makeText(this, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                } else {
                    LogUtil.debug(TAG, " ID_ARTICLE_LOADER onloadfinished 5 error cursor...... ");
                }
                LogUtil.debug(TAG, " ID_ARTICLE_LOADER onLoadFinished 6 ");

                break;
            case ID_SIGNAL_ID_LOADER:
                if ((data != null) && (data.getCount() == 1)) {
                    //it should not have one row
                    data.moveToPosition(0);
                    int bookmarkalready = 0 ;
                    if (data.isNull(SignalContract.INDEX_BOOKMARKALREADY) != true) {
                        bookmarkalready = data.getInt(SignalContract.INDEX_BOOKMARKALREADY);
                        if (bookmarkalready !=0){
                            mIBBookmark.setSelected(true);
                        }
                    }


                }
                break;

            case ID_ARTICLELOOKUP_LOADER:
                if ( (data != null) && (data.getCount() > 0) ){
                    for (int index=0 ; index < data.getCount(); index++){
                        data.moveToPosition(index);
                        mArticleLookupList.put(
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID),
                                data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL));
                        LogUtil.debug(TAG, "  onloadinfished articlelookup_loader index="
                                + index
                                + ", sheetid="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID)
                                + ", sheetid_url="
                                + data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL)
                        );

                    }
                } else {
                    LogUtil.debug(TAG, "  onloadinfished articlelookup_loader getcount=0");
                }
                LogUtil.debug (TAG, " ID_ARTICLELOOKUP_LOADER mArticleLookupList=" + mArticleLookupList.toString());

                break;

            default:
                Log.w(TAG, "Loader onloadfinished 2 Not Implemented: " + loader.getId());
                //throw new RuntimeException("Loader onloadfinished 2 Not Implemented: " + loader.getId());

        }

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    class MyGestureListener extends GestureDetector.SimpleOnGestureListener {
        private static final String DEBUG_TAG = "Gestures";

        @Override
        public boolean onDown(MotionEvent event) {
            LogUtil.debug(DEBUG_TAG, "onDown: " + event.toString());
            return super.onDown(event);
        }

        @Override
        public boolean onSingleTapUp(MotionEvent e) {
            LogUtil.debug(DEBUG_TAG, "onSingleTapUp: " + e.toString());
            return super.onSingleTapUp(e);
        }

        @Override
        public boolean onFling(MotionEvent event1, MotionEvent event2,
                               float velocityX, float velocityY) {
            LogUtil.debug(DEBUG_TAG, "onFling: " + event1.toString() + event2.toString());
            LogUtil.debug(DEBUG_TAG, "start event 1 .............");
            printSamples(event1);
            LogUtil.debug(DEBUG_TAG, "start event 2 .............");
            printSamples(event2);


            LogUtil.debug(DEBUG_TAG, "event1.gety(0)=" + event1.getY(0) + ",event2.getY(0)=" + event2.getY(0) + " .............");
            LogUtil.debug(DEBUG_TAG, "mBottomSheetBehaviorY=" + mBottomSheetBehaviorY );
            LogUtil.debug(DEBUG_TAG, "bottomsheetbehavior getstate=" + bottomSheetBehavior.getState() );
            LogUtil.debug(DEBUG_TAG, "bottomsheetbehavior=collapsed=" + BottomSheetCoordinatorBehavior.STATE_COLLAPSED );
            LogUtil.debug(DEBUG_TAG, "bottomsheetbehavior=HIDDEN=" + BottomSheetCoordinatorBehavior.STATE_HIDDEN );
            LogUtil.debug(DEBUG_TAG, "bottomsheetbehavior=expanded=" + BottomSheetCoordinatorBehavior.STATE_EXPANDED );
            LogUtil.debug(DEBUG_TAG, "bottomsheetbehavior=dragging=" + BottomSheetCoordinatorBehavior.STATE_DRAGGING );
            LogUtil.debug(DEBUG_TAG, "bottomsheetbehavior=settling=" + BottomSheetCoordinatorBehavior.STATE_SETTLING );

            LogUtil.debug(DEBUG_TAG, "event1.gety(0)=" + event1.getY(0) );
            LogUtil.debug(DEBUG_TAG, "mBottomSheetBehaviorY=" + mBottomSheetBehaviorY);
            if  (  event1.getY(0) < mBottomSheetBehaviorY  )
                LogUtil.debug(DEBUG_TAG, " event1.gety(0) < mBottomSheetBehaviorY");
            if (bottomSheetBehavior.getState() != BottomSheetCoordinatorBehavior.STATE_EXPANDED)
                LogUtil.debug(DEBUG_TAG, " bottomSheetBehavior.getState() != BottomSheetCoordinatorBehavior.STATE_EXPANDED ");

            if ( (  event1.getY(0) <  mBottomSheetBehaviorY  ) &&
                    (bottomSheetBehavior.getState() != BottomSheetCoordinatorBehavior.STATE_EXPANDED)){
                LogUtil.debug(DEBUG_TAG, " check whether bottom sheet to display peek or not " );
                if ( event1.getY(0)  < event2.getY(0) ){
                    LogUtil.debug(DEBUG_TAG, "onFling collapsed  .............");
                    bottomSheetBehavior.setState(BottomSheetCoordinatorBehavior.STATE_COLLAPSED);
                } else {
                    LogUtil.debug(DEBUG_TAG, "onFling hidden  .............");
                    bottomSheetBehavior.setState(BottomSheetCoordinatorBehavior.STATE_HIDDEN);
                }
            } else if (  (event1.getY(0) >  mBottomSheetBehaviorY  ) &&
                    ( event2.getY(0)  <event1.getY(0)  )){
                LogUtil.debug(DEBUG_TAG, "onFling expanded.............");
                bottomSheetBehavior.setState(BottomSheetCoordinatorBehavior.STATE_EXPANDED);
            }else {
                LogUtil.debug(DEBUG_TAG, "outside bottomsheet " );
            }
            return super.onFling(event1, event2, velocityX, velocityY);
        }
        void printSamples(MotionEvent ev) {
            final int historySize = ev.getHistorySize();
            final int pointerCount = ev.getPointerCount();

            LogUtil.debug(DEBUG_TAG, "printsamples historysize   ............."+ historySize );
            LogUtil.debug(DEBUG_TAG, "printsamples pointercount   ............."+ pointerCount );

            String comment;
            for (int h = 0; h < historySize; h++) {
                comment = "At time "+  ev.getHistoricalEventTime(h);
                LogUtil.debug(DEBUG_TAG, comment);
                for (int p = 0; p < pointerCount; p++) {
                    comment ="  first for loop pointer " + ev.getPointerId(p) + ": (" + ev.getHistoricalX(p, h) + "," +
                            ev.getHistoricalY(p, h) + ")" + "p=" + p + ",h="+ h;
                    LogUtil.debug(DEBUG_TAG, comment);
                }
            }
            comment = "At time "+  ev.getEventTime();
            LogUtil.debug(DEBUG_TAG, comment);
            for (int p = 0; p < pointerCount; p++) {
                comment = "  second for loop pointer " + ev.getPointerId(p) + ": (" + ev.getX(p) + "," +  ev.getY(p) + ")"  + "p=" + p;
                LogUtil.debug(DEBUG_TAG, comment);
            }
        }
    }



}





