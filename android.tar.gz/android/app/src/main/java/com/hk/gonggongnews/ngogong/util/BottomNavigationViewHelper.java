package com.hk.gonggongnews.ngogong.util;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;

import com.hk.gonggongnews.ngogong.BuildConfig;
import com.hk.gonggongnews.ngogong.GetUpgradeActivity;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.MenuItem;

import com.hk.gonggongnews.ngogong.BookmarkListActivity;
import com.hk.gonggongnews.ngogong.ExpandNewsActivity;
import com.hk.gonggongnews.ngogong.GongNewsActivity;
import com.hk.gonggongnews.ngogong.MainNewsActivity;
import com.hk.gonggongnews.ngogong.R;

/**
 * Created by ismile on 11/19/2017.
 */

public class BottomNavigationViewHelper {

    private static final String TAG = BottomNavigationViewHelper.class.getSimpleName();

    public static void selection(final Context context, BottomNavigationView view, int currentNavid){
        view.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent intent;
                LogUtil.debug (TAG, " onNavigationItemSelected");
                switch (item.getItemId()){
                    case R.id.nav_gongnews: //starting simplegong feature activity
                        if (currentNavid == R.id.nav_gongnews){
                            LogUtil.debug(TAG, " onNavigationItemSelected 1");
                            return false;
                        }
                        intent = new Intent(context, GongNewsActivity.class);//ACTIVITY_NUM = 1
                        LogUtil.debug(TAG, " onNavigationItemSelected 2");
                        break;

                    case R.id.nav_bookmark: //starting bookmark feature activity
                        if (currentNavid == R.id.nav_bookmark){
                            LogUtil.debug(TAG, " onNavigationItemSelected 3");
                            return false;
                        }
                        intent = new Intent(context, BookmarkListActivity.class);//ACTIVITY_NUM = 2
                        LogUtil.debug(TAG, " onNavigationItemSelected 4");
                        break;
                    case R.id.nav_mainnews: //starting mainnews feature activity
                    default:
                        if (currentNavid == R.id.nav_mainnews){
                            LogUtil.debug(TAG, " onNavigationItemSelected 5");
                            return false;
                        }
                        LogUtil.debug(TAG, " onNavigationItemSelected 6");
                        intent = new Intent(context, MainNewsActivity.class);//ACTIVITY_NUM = 0
                        break;

                }

                SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(context);
                int current_appversion = sp.getInt(context.getString(R.string.current_appversion), 0);

                LogUtil.debug(TAG, " onNavigationItemSelected appversion=" + current_appversion);
                if (BuildConfig.VERSION_CODE < current_appversion) {
                    intent = new Intent(context, GetUpgradeActivity.class);
                }

                //intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                //intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                ((Activity) context).finish();
                return true;
            }
        });
    }
}
