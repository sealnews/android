package com.hk.gonggongnews.ngogong;

/**
 * Created by ismile on 10/23/2017.
 */

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class GongAppGlideModule extends AppGlideModule {}

