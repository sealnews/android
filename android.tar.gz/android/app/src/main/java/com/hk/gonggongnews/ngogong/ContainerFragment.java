package com.hk.gonggongnews.ngogong;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.hk.gonggongnews.ngogong.util.LogUtil;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.hk.gonggongnews.ngogong.data.ArticleLookupTableContract;
import com.hk.gonggongnews.ngogong.data.ArticleTableContract;
import com.hk.gonggongnews.ngogong.data.FragArticleArcTableContract;
import com.hk.gonggongnews.ngogong.data.FragArticleTableContract;
import com.hk.gonggongnews.ngogong.data.FragLookupTableContract;
import com.hk.gonggongnews.ngogong.data.GongInfoContract;
import com.hk.gonggongnews.ngogong.data.GongInfoLookupContract;
import com.hk.gonggongnews.ngogong.data.GongPreference;
import com.hk.gonggongnews.ngogong.data.SignalContract;
import com.hk.gonggongnews.ngogong.sync.FirebaseIntentService;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;
import com.hk.gonggongnews.ngogong.util.FragInfo;

import java.util.LinkedHashMap;
import java.util.Map;

import static android.support.v7.widget.RecyclerView.SCROLL_STATE_DRAGGING;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_IDLE;
import static android.support.v7.widget.RecyclerView.SCROLL_STATE_SETTLING;
import static com.hk.gonggongnews.ngogong.NewsFragmentPagerAdapter.FRAGMENT_NAME;
import static com.hk.gonggongnews.ngogong.NewsFragmentPagerAdapter.FRAGMENT_POS;

/**
 * Created by ismile on 12/6/2017.
 */

public class ContainerFragment extends Fragment implements
        LoaderManager.LoaderCallbacks<Cursor>,
        FirstLevelNewsAdapter.FirstLevelNewsAdapterOnClickHandler,
        NewsFragmentPagerAdapter.TalkToIndividualFragment {

    private Map<String, String> mArticleLookupList;
    private Map<String, String> mGongInfoLookupList;
    private Map<String, String> mFragmentLookupList;
    private Map<String, String> mArchiveFragmentLookupList;

    private final String TAG = ContainerFragment.class.getSimpleName();

    private int ID_ARTICLELOOKUP_LOADER;
    private int ID_SIGNAL_LOADER;
    private int ID_FRAGARTICLE_TABLE_LOADER;
    private int ID_FRAGARTICLE_ARCTABLE_LOADER;
    private int ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER;
    private int ID_FRAGEMENTLOOKUP_NAME_LOADER;

    private final int NUMBER_OF_ENTRY_TO_RETRIEVE = 700;
    private int mCurrentNoofEntry = 0;
    private FirstLevelNewsAdapter mFirstLevelNewsAdapter;

    private SlowdownRecyclerView mRecyclerView;
    private int mPosition = RecyclerView.NO_POSITION; //NO_POSITION = initial state ,
    // =0 after first check localdatabase, "going" to get remote data
    private int mPosition_archive = RecyclerView.NO_POSITION; //NO_POSITION = initial state ,
    // =0 after first check localdatabase, "going" to get remote data

    private ProgressBar mLoadingIndicator;

    private boolean mLoadingMore = false;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private boolean mRefreshingLayout = false;
    private boolean mUsingAllArchive = false;
    private boolean mUsingPageArchive = false;
    private int mUsingAllArchivePageNumber = 0;
    private int mFragPageNumber = 0;
    public final String PREFERREDLISTINTARRAY = "preferredlistarray";
    private MainNewsActivity mMainNewsActivity;
    private int mRetrievePageNumber = 0;
    private Context mCurrentContext;


    private String mEntity_name;
    private int mEntity_id;

    private Cursor mCursorFragArcLookup = null;
    private Cursor mCursorFragLookup = null;
    private CollapsingToolbarLayout mCollapsingToolbarLayout;
    private String mCollapsingToolbarTitle;
    private String mFragment_name;
    private int mFragment_pos;

    private static ContainerFragment mCurrentFragment;

    private static boolean mRestartFRAGARTICLELoader=false;

    private static boolean mCallbackMaintoCheckHowmany=false;

    public ContainerFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.article_list, container, false);
        Bundle passInBundle = getArguments();
        mFragment_name = passInBundle.getString(FRAGMENT_NAME);
        mFragment_pos = passInBundle.getInt(FRAGMENT_POS);
        mCurrentFragment = this;
        int startloaderid = FragInfo.getInstance().get_startingloaderid(mFragment_name);
        ID_ARTICLELOOKUP_LOADER = startloaderid + 1;
        ID_SIGNAL_LOADER = startloaderid + 2;
        ID_FRAGARTICLE_TABLE_LOADER = startloaderid + 3;
        ID_FRAGARTICLE_ARCTABLE_LOADER = startloaderid + 4;
        ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER = startloaderid + 5;
        ID_FRAGEMENTLOOKUP_NAME_LOADER = startloaderid + 6;

        mArticleLookupList = new LinkedHashMap<String, String>();
        mArchiveFragmentLookupList = new LinkedHashMap<String, String>();
        mFragmentLookupList = new LinkedHashMap<String, String>();
        LogUtil.debug(TAG, "oncreateview 1 " + mFragment_name);

        mRecyclerView = (SlowdownRecyclerView) rootView.findViewById(R.id.recyclerview_slowdown);
        mLoadingIndicator = (ProgressBar) rootView.findViewById(R.id.pb_loading_indicator);


        LinearLayoutManager layoutManager =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mFirstLevelNewsAdapter = new FirstLevelNewsAdapter(this.getActivity(), this);
        mRecyclerView.setAdapter(mFirstLevelNewsAdapter);

        LogUtil.debug(TAG, "oncreateview 2 " + mFragment_name);

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                LogUtil.debug(TAG, "-->  " + mFragment_name + " onScrollStateChanged idle=" + SCROLL_STATE_IDLE + ",settling=" + SCROLL_STATE_SETTLING + ",dragging=" +
                        SCROLL_STATE_DRAGGING + ",newState=" + newState);
                int visibleItemCount = recyclerView.getLayoutManager().getChildCount();
                int totalItemCount = recyclerView.getLayoutManager().getItemCount();
                int findFirstVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findFirstVisibleItemPosition();
                int findFirstCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findFirstCompletelyVisibleItemPosition();
                int findLastVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findLastVisibleItemPosition();
                int findLastCompletelyVisibleItemPosition = ((LinearLayoutManager) recyclerView.getLayoutManager())
                        .findLastCompletelyVisibleItemPosition();

                LogUtil.debug(TAG, "---->  " + mFragment_name + " onscrollstatechanged  visibleItemCount=" + visibleItemCount +
                        ",totalItemCount=" + totalItemCount +
                        ",findFirstVisibleItemPosition=" + findFirstVisibleItemPosition +
                        ",findFirstCompletelyVisibleItemPosition=" + findFirstCompletelyVisibleItemPosition +
                        ",findLastVisibleItemPosition=" + findLastVisibleItemPosition +
                        ",findLastCompletelyVisibleItemPosition=" + findLastCompletelyVisibleItemPosition +
                        ",musingallarchive=" + mUsingAllArchive
                );
                if ((mLoadingMore == false)
                        && (newState == SCROLL_STATE_DRAGGING)
                        && (((float) findLastVisibleItemPosition / totalItemCount) > 0.4)
                        ) {
                    if (Gongdispatch.isOnline(getActivity())) {
                        if (mUsingAllArchive) {
                            mCursorFragArcLookup.moveToPosition(0);

                            int remoteNoofEntry = mCursorFragArcLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY);
                            int localNoofEntry = GongPreference.getLastUpdateNoOfEntry(mMainNewsActivity,
                                    FragInfo.getInstance().get_archivenoofentrynamelocal(mFragment_name));
                            LogUtil.debug(TAG, "  " + mFragment_name + " onscrollstatechanged 4 remoteNoofEntry="
                                    + remoteNoofEntry + ",localNoofEntry=" + localNoofEntry);

                            if (localNoofEntry - (NUMBER_OF_ENTRY_TO_RETRIEVE * 2 * mUsingAllArchivePageNumber) > 0) {
                                mLoadingMore = Gongdispatch.retrieveSheetAndNameCat(remoteNoofEntry,
                                        mArchiveFragmentLookupList,
                                        mUsingAllArchivePageNumber,
                                        remoteNoofEntry > localNoofEntry
                                                ? remoteNoofEntry - localNoofEntry
                                                : 0,
                                        FragArticleArcTableContract.buildUriWithNamePathAndName(FragInfo.getInstance().get_archivetablename(mFragment_name)),
                                        "H",
                                        NUMBER_OF_ENTRY_TO_RETRIEVE * 2,
                                        mMainNewsActivity,
                                        FragInfo.getInstance().get_archivetablename(mFragment_name),
                                        FragInfo.getInstance().get_archivecategory(mFragment_name)
                                );
                                LogUtil.debug(TAG, "  " + mFragment_name + " onscrollstatechanged 5 mUsingAllArchivePageNumber=" + mUsingAllArchivePageNumber);
                                mUsingAllArchivePageNumber++;
                            }
                            LogUtil.debug(TAG, "  " + mFragment_name + " onscrollstatechanged 6 mUsingAllArchivePageNumber=" + mUsingAllArchivePageNumber);

                        } else {
                            mCursorFragLookup.moveToPosition(0);

                            int remoteNoofEntry = mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY);
                            int localNoofEntry = GongPreference.getLastUpdateNoOfEntry(mMainNewsActivity,
                                    FragInfo.getInstance().get_noofentrynamelocal(mFragment_name));
                            LogUtil.debug(TAG, "  " + mFragment_name + " onscrollstatechanged 7 remoteNoofEntry="
                                    + remoteNoofEntry + ",localNoofEntry=" + localNoofEntry);
                            if (localNoofEntry - (NUMBER_OF_ENTRY_TO_RETRIEVE * 2 * mFragPageNumber) > 0) {
                                mLoadingMore = Gongdispatch.retrieveSheetAndNameCat(remoteNoofEntry,
                                        mFragmentLookupList,
                                        mFragPageNumber,
                                        remoteNoofEntry > localNoofEntry
                                                ? remoteNoofEntry - localNoofEntry
                                                : 0,
                                        FragArticleTableContract.buildUriWithNamePathAndName(mFragment_name),
                                        "H",
                                        NUMBER_OF_ENTRY_TO_RETRIEVE * 2,
                                        mMainNewsActivity,
                                        mFragment_name,
                                        FragInfo.getInstance().get_category(mFragment_name)
                                );
                                LogUtil.debug(TAG, "  " + mFragment_name + " onscrollstatechanged 8 mFragPageNumber=" + mFragPageNumber);
                                mFragPageNumber++;
                            }
                            LogUtil.debug(TAG, "  " + mFragment_name + " onscrollstatechanged 9 mFragPageNumber=" + mFragPageNumber);
                        }
                    } else {
                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }
                }

            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

            }
        });


        LogUtil.debug(TAG, "  " + mFragment_name + " oncreateview 3 ");


        mSwipeRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.swiperefresh);
//        mSwipeRefreshLayout = (SwipeRefreshLayout) ( container.getParent());
        mSwipeRefreshLayout.setDistanceToTriggerSync(32);
        mSwipeRefreshLayout.setNestedScrollingEnabled(true);
        mSwipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                        LogUtil.debug(TAG, "  " + mFragment_name + " onRefresh called from SwipeRefreshLayout 1 ");
                        LogUtil.debug(TAG, "  " + mFragment_name + " onRefresh called from SwipeRefreshLayout 1 ");
                        if (Gongdispatch.isOnline(getActivity())) {
                            mCursorFragLookup.moveToPosition(0);
                            Gongdispatch.retrieveSheetAndNameCat(mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                                    mFragmentLookupList,
                                    0,
                                    0,
                                    FragArticleTableContract.buildUriWithNamePathAndName(mFragment_name),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                                    mMainNewsActivity,
                                    mFragment_name,
                                    FragInfo.getInstance().get_category(mFragment_name)
                            );
                            mFragPageNumber=0;
                            updatearchiveNoofEntry();

                            //((FilterFragment.CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceListAfterSwipe();

                            mRefreshingLayout = true;
                        } else {
                            LogUtil.debug(TAG, "  " + mFragment_name + " onRefresh called from SwipeRefreshLayout 3");
                            Toast.makeText(mMainNewsActivity, R.string.check_network_setting, Toast.LENGTH_LONG).show();
                            mSwipeRefreshLayout.setRefreshing(false);
                            mRefreshingLayout = false;

                        }
                    }
                }
        );
        LogUtil.debug(TAG, "  " + mFragment_name + " oncreateview 4 ");

        getActivity().getSupportLoaderManager().initLoader(ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_FRAGEMENTLOOKUP_NAME_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_ARTICLELOOKUP_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_SIGNAL_LOADER, null, this);
        getActivity().getSupportLoaderManager().initLoader(ID_FRAGARTICLE_TABLE_LOADER, null, this);
        //getActivity().getSupportLoaderManager().initLoader(ID_FRAGARTICLE_ARCTABLE_LOADER, null, this);

        LogUtil.debug(TAG, "  " + mFragment_name + " oncreateview 5 ");

        //Gongdispatch.initialize(getActivity());
        LogUtil.debug(TAG, "  " + mFragment_name + " oncreateview 6 ");

        mUsingAllArchivePageNumber = 0;
        mFragPageNumber = 0;

        return rootView;


        //TextView textView = new TextView(getActivity());
        //textView.setText(R.string.hello_blank_fragment);
        //return textView;
    }


    private void showLoading() {
        /* Then, hide the weather data */
        LogUtil.debug(TAG, "  " + mFragment_name + " showloading ");
        mRecyclerView.setVisibility(View.INVISIBLE);
        /* Finally, show the loading indicator */
        mLoadingIndicator.setVisibility(View.VISIBLE);
    }

    private void showDataView() {
        /* First, hide the loading indicator */
        LogUtil.debug(TAG, "  " + mFragment_name + " showdatashow ");
        mLoadingIndicator.setVisibility(View.INVISIBLE);
        /* Finally, make sure the weather data is visible */
        mRecyclerView.setVisibility(View.VISIBLE);
    }


    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        LogUtil.debug(TAG, "---->  " + mFragment_name + "  oncreateloader " + ",id=" + id);
        if (id == ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER) {
            LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 1");
            return new CursorLoader(getActivity(),
                    FragLookupTableContract.buildUriWithNamePathAndName(FragInfo.getInstance().get_archivetablename(mFragment_name)),
                    null,
                    null,
                    null,
                    null);
        } else if (id == ID_FRAGEMENTLOOKUP_NAME_LOADER) {

            LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 2");
            return new CursorLoader(getActivity(),
                    FragLookupTableContract.buildUriWithNamePathAndName(mFragment_name),
                    null,
                    null,
                    null,
                    null);
        } else if (id == ID_FRAGARTICLE_TABLE_LOADER) {
            LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 3");
            return new CursorLoader(getActivity(),
                    FragArticleTableContract.buildUriWithNamePathAndName(mFragment_name),
                    null,
                    null,
                    null,
                    null);
        } else if (id == ID_FRAGARTICLE_ARCTABLE_LOADER) {
            LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 4");

            StringBuilder selectionBuilder = new StringBuilder();
            String[] selectionArgs ;
            int[] arrayOfFSD = new int[0];
            if (args != null){
                arrayOfFSD = args.getIntArray(PREFERREDLISTINTARRAY);
                selectionArgs = new String[arrayOfFSD.length + 1];
            } else {
                selectionArgs = new String[1];
            }
            selectionArgs[0] = FragInfo.getInstance().get_archivetablename(mFragment_name);
            selectionBuilder.append(FragArticleArcTableContract.RAWQUERY_FRAGARTICLEARC_WHERENAMESTRING);
            if (arrayOfFSD.length > 0 ) {
                selectionBuilder.append(" and ");
                for (int y = 0; y < arrayOfFSD.length; y++) {
                    LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 4.1 = " + arrayOfFSD[y]);
                }

                selectionBuilder.append(" ( ");
                for (int index = 0; index < arrayOfFSD.length; index++) {
                    selectionArgs[index + 1] = String.valueOf(arrayOfFSD[index]);
                    selectionBuilder.append(FragArticleArcTableContract.RAWQUERY_FRAGARTICLEARC_WHEREFIRSTSUBSTRING);
                    if ((index + 1) < arrayOfFSD.length) {
                        selectionBuilder.append(" or ");
                    }

                }
                selectionBuilder.append(" ) ");

                LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 4.2 = " + selectionBuilder.toString());
                for (int y = 0; y < selectionArgs.length; y++) {
                    LogUtil.debug(TAG, ",  " + mFragment_name + " selectionargs=" + selectionArgs[y]);
                }
            }
            return new CursorLoader(getActivity(),
                    FragArticleArcTableContract.buildUriWithNamePathAndName(FragInfo.getInstance().get_archivetablename(mFragment_name)),
                    null,
                    selectionBuilder.toString(),
                    selectionArgs,
                    null);
        } else if (id == ID_ARTICLELOOKUP_LOADER) {

            Uri articlelookupQueryUri = ArticleLookupTableContract.ArticleLookupEntry.CONTENT_URI;
            String articlelookupsortOrder = ArticleLookupTableContract.ArticleLookupEntry.COLUMN_SHEETID + " ASC";
            LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 5");

            return new CursorLoader(getActivity(),
                    articlelookupQueryUri,
                    ArticleLookupTableContract.PROJECTION,
                    null,
                    null,
                    articlelookupsortOrder);
        } else if (id == ID_SIGNAL_LOADER) {
            Uri signalQueryUri = SignalContract.SignalEntry.CONTENT_URI;
            String signalsortOrder = SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " ASC";
            LogUtil.debug(TAG, "---->  " + mFragment_name + " oncreateloader 6");

            return new CursorLoader(getActivity(),
                    signalQueryUri,
                    SignalContract.PROJECTION,
                    null,
                    null,
                    signalsortOrder);
        } else {
            Log.e(TAG, " " + mFragment_name + " Loader Not Implemented: " + id);
            return new CursorLoader(getActivity(),
                    SignalContract.SignalEntry.CONTENT_URI,
                    SignalContract.PROJECTION,
                    null,
                    null,
                    SignalContract.SignalEntry.COLUMN_ARTICLE_ID + " ASC");
            //throw new RuntimeException(" " + mFragment_name + " Loader Not Implemented: " + id);
        }


    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        LogUtil.debug(TAG, "  " + mFragment_name + " onloadfinished 1 loader.getid=" + loader.getId());

        int loaderid = loader.getId();
        if (loaderid == ID_FRAGARTICLE_TABLE_LOADER) {
            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER onloadfinished 1.1 ");

            if ((data == null) || ((data != null) && (data.getCount() == 0))) {
                if (((data != null) && (data.getCount() == 0)) && (mPosition == 0)) {
                    //it is really no data to show, even after get it from remote
                    LogUtil.debug(TAG, "  " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER onloadfinished 1.1.1 ");
                    mFirstLevelNewsAdapter.swapCursor(null, false);
                    mRefreshingLayout = false;

                }
                //go get data, nothing in local database, go get it from remote
                showLoading();
                if (Gongdispatch.isOnline(getActivity())) {
                    if  (mCursorFragLookup == null)  {
                        LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER onloadfinished 1.2 ");
                        mRestartFRAGARTICLELoader= true;
                        mRefreshingLayout = true;
                        //final Handler handler = new Handler();
                        //handler.postDelayed(new Runnable() {
                        //    @Override
                        //    public void run() {
                        //        Log.e(TAG, " ID_FRAGARTICLE_TABLE_LOADER onloadfinished handler=" + mCurrentFragment);
                        //        getActivity().getSupportLoaderManager().restartLoader(ID_FRAGARTICLE_TABLE_LOADER, null, mCurrentFragment);
                        //        mRefreshingLayout = true;
                        //    }
                        //}, 2000);


                    } else {
                        LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER onloadfinished 1.3 ");
                        mCursorFragLookup.moveToPosition(0);
                        if (mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY) > 0) {
                            Gongdispatch.retrieveSheetAndNameCat(mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                                    mFragmentLookupList,
                                    0,
                                    0,
                                    FragArticleTableContract.buildUriWithNamePathAndName(mFragment_name),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                                    mMainNewsActivity,
                                    mFragment_name,
                                    FragInfo.getInstance().get_category(mFragment_name)
                            );
                            mRefreshingLayout = true;
                            mFragPageNumber = 1;
                        } else {
                            LogUtil.debug(TAG, "  " + mFragment_name + "  ID_FRAGARTICLE_TABLE_LOADER onloadfinished 1.4 ");
                            mRefreshingLayout = false;
                            mFirstLevelNewsAdapter.swapCursor(null, false);

                        }
                        mPosition = 0;
                    }
                    //((FilterFragment.CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceListAfterSwipe();
                } else {
                    LogUtil.debug(TAG, "  " + mFragment_name + "  ID_FRAGARTICLE_TABLE_LOADER onloadfinished 1.5");
                    Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    mSwipeRefreshLayout.setRefreshing(false);
                    mRefreshingLayout = false;
                }

            } else {
                if (mRefreshingLayout == true) {
                    mRefreshingLayout = false;
                    mSwipeRefreshLayout.setRefreshing(false);

                    //mSwipeRefreshLayout.setEnabled(true);
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER onloadfinished 2 ");

                }
                LogUtil.debug(TAG, "  " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER  onloadfinished 3 ");
                mFirstLevelNewsAdapter.swapCursor(data, false);
                mLoadingMore = false;
                LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER  onloadfinished 4 ");

                if (mPosition == RecyclerView.NO_POSITION) {
                    //it means there are some data in the database
                    //check whether there are more new news
                    //int prefNoofentry = GongPreference.getLastUpdateNoOfEntry(this, mEntity_name);
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER  onloadfinished 5 ");

                    if (Gongdispatch.isOnline(getActivity())) {
                        if (mCursorFragLookup != null) {
                            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER  onloadfinished 6 ");
                            mCursorFragLookup.moveToPosition(0);
                            Gongdispatch.retrieveSheetAndNameCat(mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                                    mFragmentLookupList,
                                    0,
                                    0,
                                    FragArticleTableContract.buildUriWithNamePathAndName(mFragment_name),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                                    mMainNewsActivity,
                                    mFragment_name,
                                    FragInfo.getInstance().get_category(mFragment_name)
                            );
                            mFragPageNumber = 1;
                        }
                        mPosition = 0;
                    } else {
                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                } else if (mPosition >= 0) {

                    //(mPosition == RecyclerView.NO_POSITION){
                    //mPosition = data.getCount();
                    mRecyclerView.smoothScrollToPosition(0);
                    mCursorFragLookup.moveToPosition(0);
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER  onloadfinished 7 setting setLastUpdateNoOfEntry="
                            + mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY));
                    GongPreference.setLastUpdateNoOfEntry(getActivity(),
                            mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                            FragInfo.getInstance().get_noofentrynamelocal(mFragment_name));

                }
                updatearchiveNoofEntry();
                LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_TABLE_LOADER onloadfinished 8  data.getcount=" + data.getCount());
                if (data.getCount() != 0) showDataView();
            }
        } else if (loaderid == ID_FRAGARTICLE_ARCTABLE_LOADER) {
            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.1 ");

            if ((data == null) || ((data != null) && (data.getCount() == 0))) {
                if (((data != null) && (data.getCount() == 0)) && (mPosition_archive == 0)) {
                    //it is really no data to show
                    LogUtil.debug(TAG, "  " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.1.1 ");
                    mFirstLevelNewsAdapter.swapCursor(null, false);
                    mRefreshingLayout = false;
                }
                //go get data
                showLoading();
                if (Gongdispatch.isOnline(getActivity())) {
                    if (mCursorFragArcLookup == null) {
                        LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.2 ");

                        //well restart and checkagain , wait for infolookup
                        getActivity().getSupportLoaderManager().restartLoader(ID_FRAGARTICLE_ARCTABLE_LOADER, null, this);
                        mRefreshingLayout = true;

                    } else {
                        LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.3 ");
                        mCursorFragArcLookup.moveToPosition(0);
                        if (mCursorFragArcLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY) > 0) {
                            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.4 ");
                            Gongdispatch.retrieveSheetAndNameCat(mCursorFragArcLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                                    mArchiveFragmentLookupList,
                                    mUsingAllArchivePageNumber,
                                    0,
                                    FragArticleArcTableContract.buildUriWithNamePathAndName(FragInfo.getInstance().get_archivetablename(mFragment_name)),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                                    mMainNewsActivity,
                                    FragInfo.getInstance().get_archivetablename(mFragment_name),
                                    FragInfo.getInstance().get_archivecategory(mFragment_name)
                            );
                            mRefreshingLayout = true;
                            mUsingAllArchivePageNumber++;
                        } else {
                            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.5 ");
                            mRefreshingLayout = false;
                            mFirstLevelNewsAdapter.swapCursor(null, false);

                        }
                        mPosition_archive = 0;
                    }
                    //((FilterFragment.CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceListAfterSwipe();

                } else {
                    LogUtil.debug(TAG, "  " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 1.6 ");
                    Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    mSwipeRefreshLayout.setRefreshing(false);
                    mRefreshingLayout = false;
                }

            } else {
                if (mRefreshingLayout == true) {
                    mRefreshingLayout = false;
                    mSwipeRefreshLayout.setRefreshing(false);

                    //mSwipeRefreshLayout.setEnabled(true);
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER  onloadfinished 2 ");

                }
                LogUtil.debug(TAG, "  " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 3 ");
                mFirstLevelNewsAdapter.swapCursor(data, true);
                mLoadingMore = false;
                LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished  4 ");

                if (mPosition_archive == RecyclerView.NO_POSITION) {
                    //it means there are some data in the database
                    //check whether there are more new news
                    //int prefNoofentry = GongPreference.getLastUpdateNoOfEntry(this, mEntity_name);
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished  5 ");
                    if (Gongdispatch.isOnline(getActivity())) {
                        if (mCursorFragArcLookup != null) {
                            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished  6 ");
                            mCursorFragArcLookup.moveToPosition(0);
                            Gongdispatch.retrieveSheetAndNameCat(mCursorFragArcLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                                    mArchiveFragmentLookupList,
                                    0,
                                    0,
                                    FragArticleArcTableContract.buildUriWithNamePathAndName(FragInfo.getInstance().get_archivetablename(mFragment_name)),
                                    "H",
                                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                                    mMainNewsActivity,
                                    FragInfo.getInstance().get_archivetablename(mFragment_name),
                                    FragInfo.getInstance().get_archivecategory(mFragment_name)
                            );
                            mUsingAllArchivePageNumber = 1;
                        }
                        mPosition_archive = 0;
                        mRecyclerView.smoothScrollToPosition(0);

                    } else {
                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }


                } else if (mPosition_archive >= 0) {
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished  7 ");

                    //(mPosition == RecyclerView.NO_POSITION){
                    //mPosition_archive = data.getCount();
                    //mRecyclerView.smoothScrollToPosition(0);
                    mCursorFragArcLookup.moveToPosition(0);
                    //mPosition_archive = RecyclerView.NO_POSITION;
                    //updatearchiveNoofEntry();
                    if ( (mCursorFragArcLookup != null) && (mCursorFragArcLookup.getCount() > 0)) {
                        int remoteNoofEntry = mCursorFragArcLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY);
                        LogUtil.debug(TAG, "   " + mFragment_name + "  ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished  7.1= "
                                + remoteNoofEntry );
                        GongPreference.setLastUpdateNoOfEntry(mMainNewsActivity,
                                remoteNoofEntry,
                                FragInfo.getInstance().get_archivenoofentrynamelocal(mFragment_name));
                    }


                }
                LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGARTICLE_ARCTABLE_LOADER onloadfinished 8 data.getcount=" + data.getCount());
                if (data.getCount() != 0) showDataView();
            }
        } else if (loaderid == ID_FRAGEMENTLOOKUP_NAME_LOADER) {
            LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGEMENTLOOKUP_NAME_LOADER onloadinfished 1 ");
            if ((data != null) && (data.getCount() > 0)) {
                mCursorFragLookup = data;
                for (int index = 0; index < data.getCount(); index++) {
                    data.moveToPosition(index);
                    mFragmentLookupList.put(
                            data.getString(FragLookupTableContract.INDEX_SHEETID),
                            data.getString(FragLookupTableContract.INDEX_SHEETID_URL));
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGEMENTLOOKUP_NAME_LOADER onloadinfished 2 index="
                            + index
                            + ", sheetid="
                            + data.getString(FragLookupTableContract.INDEX_SHEETID)
                            + ", sheetid_url="
                            + data.getString(FragLookupTableContract.INDEX_SHEETID_URL)
                    );

                }
                if (mRestartFRAGARTICLELoader){
                    getActivity().getSupportLoaderManager().restartLoader(ID_FRAGARTICLE_TABLE_LOADER, null, mCurrentFragment);
                    mRestartFRAGARTICLELoader = false;
                }

            } else {
                LogUtil.debug(TAG, "   " + mFragment_name + " ID_FRAGEMENTLOOKUP_NAME_LOADER onloadinfished getcount=0");
            }
            LogUtil.debug(TAG, "  " + mFragment_name + " ID_FRAGEMENTLOOKUP_NAME_LOADER  onloadinfished mFragmentLookupList=" + mFragmentLookupList.toString());
        } else if (loaderid == ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER) {

            LogUtil.debug(TAG, "   " + mFragment_name + " ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER onloadinfished 1 ");
            if ((data != null) && (data.getCount() > 0)) {
                mCursorFragArcLookup = data;
                for (int index = 0; index < data.getCount(); index++) {
                    data.moveToPosition(index);
                    mArchiveFragmentLookupList.put(
                            data.getString(FragLookupTableContract.INDEX_SHEETID),
                            data.getString(FragLookupTableContract.INDEX_SHEETID_URL));
                    LogUtil.debug(TAG, "   " + mFragment_name + " ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER onloadinfished 2 index="
                            + index
                            + ", sheetid="
                            + data.getString(FragLookupTableContract.INDEX_SHEETID)
                            + ", sheetid_url="
                            + data.getString(FragLookupTableContract.INDEX_SHEETID_URL)
                    );

                }

            } else {
                LogUtil.debug(TAG, "   " + mFragment_name + " ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER onloadinfished 3 getcount=0");
            }
            LogUtil.debug(TAG, "  " + mFragment_name + " ID_ARCHIVEFRAGMENTLOOKUP_NAME_LOADER  onloadinfished 4 mArchiveFragmentLookupList=" + mArchiveFragmentLookupList.toString());

        } else if (loaderid == ID_ARTICLELOOKUP_LOADER) {
            if ((data != null) && (data.getCount() > 0)) {
                for (int index = 0; index < data.getCount(); index++) {
                    data.moveToPosition(index);
                    mArticleLookupList.put(
                            data.getString(ArticleLookupTableContract.INDEX_SHEETID),
                            data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL));
                    LogUtil.debug(TAG, "  " + mFragment_name + " ID_ARTICLELOOKUP_LOADER onloadinfished 1 articlelookup_loader index="
                            + index
                            + ", sheetid="
                            + data.getString(ArticleLookupTableContract.INDEX_SHEETID)
                            + ", sheetid_url="
                            + data.getString(ArticleLookupTableContract.INDEX_SHEETID_URL)
                    );

                }
            } else {
                LogUtil.debug(TAG, "  " + mFragment_name + " ID_ARTICLELOOKUP_LOADER onloadinfished 2 articlelookup_loader getcount=0");
            }
            LogUtil.debug(TAG, "  " + mFragment_name + " ID_ARTICLELOOKUP_LOADER onloadinfished 3 mArticleLookupList=" + mArticleLookupList.toString());

        } else if (loaderid == ID_SIGNAL_LOADER) {

            mFirstLevelNewsAdapter.updateSignalMapFromCursor(data);
            //getActivity().getSupportLoaderManager().destroyLoader(ID_SIGNAL_LOADER);
            LogUtil.debug(TAG, "  " + mFragment_name + " ID_SIGNAL_LOADER onloadfinished 1 loaderid=" + loader.getId());

        } else {

            LogUtil.debug(TAG, "  " + mFragment_name + " ID_SIGNAL_LOADER onloadfinished 100 loaderid=" + loader.getId());
        }

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        LogUtil.debug(TAG, "---->  " + mFragment_name + " onloaderreset 1 loader.getid=" + loader.getId());
        if ((loader.getId() == ID_FRAGARTICLE_ARCTABLE_LOADER)
                || (loader.getId() == ID_FRAGARTICLE_TABLE_LOADER)) {
            LogUtil.debug(TAG, "---->  " + mFragment_name + " onloaderreset 2 loader.getid=" + loader.getId());
            mFirstLevelNewsAdapter.swapCursor(null, false);
        }
    }

    @Override
    public void onClickDetailNews(long entryID, String finalurl) {
        for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

            if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                    && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                LogUtil.debug(TAG, "  -->  " + mFragment_name + " onClickDetailNews 1 entryID=" + entryID);
                Intent intent = new Intent(getActivity(), DetailNewsActivity.class);
                intent.putExtra(DetailNewsActivity.SHEET_ID, mapentry.getValue());
                intent.putExtra(DetailNewsActivity.ARTICLE_ID, entryID);
                intent.putExtra(DetailNewsActivity.FINALURL, finalurl);
                intent.putExtra(DetailNewsActivity.ROWID, entryID -
                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1);
                startActivity(intent);
                LogUtil.debug(TAG, "  -->  " + mFragment_name + " onClickDetailNews 2 entryID=" + entryID);

                break;
            }
        }
        LogUtil.debug(TAG, " -->  " + mFragment_name + " onClickDetailNews 3 ");


    }

    @Override
    public void onClickExpandNews(String jsonArticleList, String jsonSignalbit) {
        Intent intent = new Intent(getActivity(), ExpandNewsActivity.class);
        intent.putExtra(ExpandNewsActivity.JSONARTICLELISTSTR, jsonArticleList);
        intent.putExtra(ExpandNewsActivity.JSONSIGNALBITSTR, jsonSignalbit);
        startActivity(intent);
        LogUtil.debug(TAG, " -->  " + mFragment_name + " onClickExpandNews 1 ");

    }

    @Override
    public void onClickBookmarkArticleStoreOrRemove(long entryID, boolean save) {
        if (save) {
            for (Map.Entry<String, String> mapentry : mArticleLookupList.entrySet()) {

                if ((ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey()) <= entryID)
                        && (entryID <= ArticleLookupTableContract.decodeGetHigherBound(mapentry.getKey()))) {

                    LogUtil.debug(TAG, "  -->  " + mFragment_name + " onClickBookmarkArticleStoreOrRemove 1 entryID=" + entryID);
                    if (Gongdispatch.isOnline(getActivity())) {
                        Gongdispatch.gsheetfetchOneEntry(getActivity(),
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);
                    } else {
                        Gongdispatch.gongdispatchOneEntry(getActivity(),
                                mapentry.getValue(),
                                entryID -
                                        (ArticleLookupTableContract.decodeGetLowerBound(mapentry.getKey())) + 1,
                                entryID);
                        Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
                    }

                    LogUtil.debug(TAG, "  -->  " + mFragment_name + " onClickBookmarkArticleStoreOrRemove 2 entryID=" + entryID);
                    break;
                }
            }
            LogUtil.debug(TAG, " -->  " + mFragment_name + " onClickBookmarkArticleStoreOrRemove 3 ");
        } else {
            //remove
            Uri removeindIDURI = ArticleTableContract.buildArticleUriWithID(entryID);
            String selection = " " + ArticleTableContract.ArticleEntry.COLUMN_ARTICLETABLE_ID + " == ? ";

            int result = mMainNewsActivity.getContentResolver().delete(
                    removeindIDURI,
                    selection,
                    null);
            LogUtil.debug(TAG, " -->  " + mFragment_name + " onClickBookmarkArticleStoreOrRemove 4 result= " + result);

        }


    }



    @Override
    public int checkHowManyNewItem() {
        //int currentLocalNoOfEntry = GongPreference.getLatestNewsPaginationNoOfEntryLocal(getActivity());
        //int currentRemoteNoOfEntry = GongPreference.getLatestNewsPaginationNoOfEntry(getActivity());
        int currentLocalNoOfEntry = GongPreference.getLastUpdateNoOfEntry(mMainNewsActivity,
                FragInfo.getInstance().get_noofentrynamelocal(mFragment_name));

        //mCursorFragLookup.moveToPosition(0);
        //int currentRemoteNoOfEntry = mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY);
        int currentRemoteNoOfEntry = GongPreference.getLastUpdateNoOfEntry(mMainNewsActivity,
                FragInfo.getInstance().get_noofentrynameremote(mFragment_name));

        LogUtil.debug(TAG, "checkHowManyNewItem currentLocalNoOfEntry="
                + currentLocalNoOfEntry
                + ",currentRemoteNoOfEntry= " +currentRemoteNoOfEntry);
        if ( ( currentLocalNoOfEntry >0 ) && (currentRemoteNoOfEntry - currentLocalNoOfEntry > 0) ){
            return currentRemoteNoOfEntry - currentLocalNoOfEntry;
        } else {
            return 0;
        }
    }

    @Override
    public void initPreferredFirstSubDomain(int[] arrayOfFSD) {
        mUsingAllArchive = true;
        mUsingAllArchivePageNumber = 0;

        ContentResolver contentResolver = getActivity().getContentResolver();
        mRecyclerView.smoothScrollToPosition(0);
        Bundle passBundle = new Bundle();
        passBundle.putIntArray(PREFERREDLISTINTARRAY, arrayOfFSD);
        for (int x = 0; x < arrayOfFSD.length; x++) {
            LogUtil.debug(TAG, " " + mFragment_name + " initPreferredFirstSubDomain 1 arrayoffsd[" +
                    x + "=" + arrayOfFSD[x]);
        }
        getActivity().getSupportLoaderManager().restartLoader(ID_FRAGARTICLE_ARCTABLE_LOADER, passBundle, this);
        LogUtil.debug(TAG, "  " + mFragment_name + " initPreferredFirstSubDomain 2 arrayoffsd = "
                + arrayOfFSD.toString()
                + " arrayoffsd.length=" + arrayOfFSD.length );

    }

    @Override
    public void clearPreferredFirstSubDomain() {
        LogUtil.debug(TAG, "  " + mFragment_name + " clearPreferredFirstSubDomain 1");
        mUsingAllArchive = false;
        mUsingAllArchivePageNumber = 0;
        getActivity().getSupportLoaderManager().restartLoader(ID_FRAGARTICLE_TABLE_LOADER, null, this);
        LogUtil.debug(TAG, "  " + mFragment_name + " clearPreferredFirstSubDomain 2");

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        if (context instanceof Activity) {
            mMainNewsActivity = (MainNewsActivity) context;
            LogUtil.debug(TAG, "  " + mFragment_name + " onAttach 1");
        }

    }

    @Override
    public void swiperefreshNow() {
        if (Gongdispatch.isOnline(getActivity())) {
            mCursorFragLookup.moveToPosition(0);
            Gongdispatch.retrieveSheetAndNameCat(mCursorFragLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY),
                    mFragmentLookupList,
                    0,
                    0,
                    FragArticleTableContract.buildUriWithNamePathAndName(mFragment_name),
                    "H",
                    NUMBER_OF_ENTRY_TO_RETRIEVE,
                    mMainNewsActivity,
                    mFragment_name,
                    FragInfo.getInstance().get_category(mFragment_name)
            );
            mFragPageNumber=0;
            mRefreshingLayout = true;
            mSwipeRefreshLayout.setRefreshing(true);
            updatearchiveNoofEntry();
        } else {
            Toast.makeText(getActivity(), R.string.check_network_setting, Toast.LENGTH_LONG).show();
        }

    }

    private void updatearchiveNoofEntry(){
        mUsingAllArchive = false;
        mUsingAllArchivePageNumber = 0;
        LogUtil.debug(TAG, " updatearchiveNoofEntry 1");
        if ( (mCursorFragArcLookup != null) && (mCursorFragArcLookup.getCount() > 0)) {
            int remoteNoofEntry = mCursorFragArcLookup.getInt(FragLookupTableContract.INDEX_NOOFENTRY);
            LogUtil.debug(TAG, "   " + mFragment_name + "  updatearchiveNoofEntry 4.1= " + remoteNoofEntry );
            GongPreference.setLastUpdateNoOfEntry(mMainNewsActivity,
                    remoteNoofEntry,
                    FragInfo.getInstance().get_archivenoofentrynamelocal(mFragment_name));
        }

    }

    public boolean ismUsingAllArchive(){
        return mUsingAllArchive;
    }

    @Override
    public void onPause() {
        super.onPause();
        mCallbackMaintoCheckHowmany=true;
    }

    @Override
    public void onStart() {
        super.onStart();
        LogUtil.debug(TAG, " containerfragment check onstart name=" + mFragment_name);
        if (mCallbackMaintoCheckHowmany) {
            MainNewsActivity mainNewsActivity = (MainNewsActivity) getActivity();
            mainNewsActivity.callbackShowHowmanyItem(mFragment_pos, this.checkHowManyNewItem());
            mCallbackMaintoCheckHowmany = false;
        }

    }








}
