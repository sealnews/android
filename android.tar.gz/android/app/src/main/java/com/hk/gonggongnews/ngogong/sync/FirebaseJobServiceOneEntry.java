package com.hk.gonggongnews.ngogong.sync;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import com.hk.gonggongnews.ngogong.util.LogUtil;

//import com.firebase.jobdispatcher.JobParameters;
//import com.firebase.jobdispatcher.JobService;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.PersistableBundle;



import com.hk.gonggongnews.ngogong.data.ArticleTableContract;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 12/24/2017.
 */

public class FirebaseJobServiceOneEntry extends JobService {

    private final static String TAG = FirebaseJobServiceOneEntry.class.getSimpleName();

    private OneEntryAsyncTask mOneEntryAsyncTask;

    private static class OneEntryAsyncTask extends AsyncTask<Void, Void, Void> {
        private final String TAG = FirebaseJobServiceOneEntry.OneEntryAsyncTask.class.getSimpleName();
        private WeakReference<Context> mContextReference;
        private JobParameters mJobParameters;
        private WeakReference<JobService> mJobService;

        public OneEntryAsyncTask(JobParameters jobParameters, Context context, JobService jobservice) {

            LogUtil.debug(TAG, " OneEntryAsyncTask constructor ");
            mJobParameters = jobParameters;
            mContextReference = new WeakReference<Context>(context);
            mJobService = new WeakReference<JobService>(jobservice);

        }

        @Override
        protected Void doInBackground(Void... voids) {

            final String TAG = FirebaseJobServiceOneEntry.OneEntryAsyncTask.class.getSimpleName();

//            Bundle extractBundle = mJobParameters.getExtras();
            PersistableBundle extractBundle = mJobParameters.getExtras();
            Gongdispatch.gsheetfetchOneEntryAltURI(
                    mContextReference.get(),
                    extractBundle.getString(Gongdispatch.SHEET_ID),
                    extractBundle.getLong(Gongdispatch.ROW_ID),
                    extractBundle.getLong(Gongdispatch.ARTICLE_ID),
                    ArticleTableContract.ArticleEntry.CONTENT_BOOKMARK_URI
                    );
            LogUtil.debug(TAG, " OneEntryAsyncTask doInBackground 1");

            LogUtil.debug(TAG, " OneEntryAsyncTask 4 ");
            mJobService.get().jobFinished(mJobParameters, false);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            mJobService.get().jobFinished(mJobParameters, false);
        }


    }

    /*
        static void gongdispatchOneEntry(@NonNull final Context context,
                                 String sheet_id,
                                 long rowid,
                                 long articleid
    ) {
        LogUtil.debug(TAG, "in Gongdispatch gongdispatchOneEntry 1");
        Bundle passinBundle = new Bundle();
        passinBundle.putString(SHEET_ID, sheet_id);
        passinBundle.putLong(ROW_ID, rowid);
        passinBundle.putLong(ARTICLE_ID, articleid);

     */

    @Override
    public boolean onStartJob(JobParameters job) {
        LogUtil.debug(TAG, "onStartJob 1 ");
        mOneEntryAsyncTask = new FirebaseJobServiceOneEntry.OneEntryAsyncTask(job, getApplicationContext(), this);
        mOneEntryAsyncTask.execute();
        LogUtil.debug(TAG, "onStartJob 2 ");
        //return false;
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters job) {
        mOneEntryAsyncTask.cancel(true);
        return false;
    }
}
