package com.hk.gonggongnews.ngogong;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.MenuItem;

import java.util.Locale;

/**
 * Created by ismile on 12/10/2017.
 */

public class SettingActivity extends AppCompatActivity {

    private final String TAG = SettingActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.settings);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        /*
         * Normally, calling setDisplayHomeAsUpEnabled(true) (we do so in onCreate here) as well as
         * declaring the parent activity in the AndroidManifest is all that is required to get the
         * up button working properly. However, in this case, we want to navigate to the previous
         * screen the user came from when the up button was clicked, rather than a single
         * designated Activity in the Manifest.
         *
         * We use the up button's ID (android.R.id.home) to listen for when the up button is
         * clicked and then call onBackPressed to navigate to the previous Activity when this
         * happens.
         */
        int id = item.getItemId();
        if (id == android.R.id.home) {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
            String  choiceOfLang = sp.getString(getString(R.string.gong_lang_pref), getString(R.string.choice_value_lang_eng));
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();

            String lang = "en_US";
            if (choiceOfLang.compareTo(getString(R.string.choice_value_lang_eng)) == 0){
                //default true zh-rhk
                LogUtil.debug(TAG, " 1 choiceoflang=" + choiceOfLang);
                lang="en_US";
                conf.locale = Locale.ENGLISH;

            } else {
                //english
                lang = "zh_HK";
                LogUtil.debug(TAG, " 2 choiceoflang=" + choiceOfLang);
                conf.locale = Locale.CHINESE;
            }
            Locale myLocale = new Locale(lang);

            //conf.setLocale(myLocale);
            res.getConfiguration();
            res.updateConfiguration(conf, dm);
            Intent refresh = new Intent(this, MainNewsActivity.class);
            startActivity(refresh);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
