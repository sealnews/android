package com.hk.gonggongnews.ngogong;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ismile on 9/21/2017.
 */

public class FilterFragment extends Fragment implements
        LoaderManager.LoaderCallbacks<Cursor>,
        FilterFragmentAdapter.ListChanged
{
    private final String TAG = FilterFragment.class.getSimpleName();


    private MainNewsActivity mMainNewsActivity;
    private RecyclerView mRecyclerView;
    private Button mClearFilterButton;
    private int mCurrentCategory;
    private Map<Integer, List<Integer>> mFSDHistoryMap;



    private FilterFragmentAdapter mFilterFragmentAdapter;

    @Override
    public void setCurrentPreferredSourceList(List<Integer> preferredList) {

        mFSDHistoryMap.put(mCurrentCategory, preferredList);
        if (preferredList.size() > 0){
            mClearFilterButton.setVisibility(View.VISIBLE);
            LogUtil.debug(TAG, " setCurrentPreferredSourceList 1 ");
            ((CallBackMainActivity) mMainNewsActivity ).setCurrentPreferredSourceList(preferredList);

        } else {
            mClearFilterButton.setVisibility(View.INVISIBLE);
            LogUtil.debug(TAG, " setCurrentPreferredSourceList 2 ");
            //((CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceList();
            ((CallBackMainActivity) mMainNewsActivity ).setCurrentPreferredSourceList(preferredList);

        }

        LogUtil.debug(TAG, ", setCurrentPreferredSourceList 3 size=" + preferredList.size());
        for (int x: preferredList){
            LogUtil.debug(TAG, ", setCurrentPreferredSourceList4="+x);
        }
    }

    public interface CallBackMainActivity {
        public int getCurrentDisplayCategory ();
        public void passInFilterFragment (Fragment filterFragment);
        public void setCurrentPreferredSourceList (List<Integer> preferredList);
        public void clearCurrentPreferredSourceList ();
        public void clearCurrentPreferredSourceListAfterSwipe ();
    }


    public FilterFragment(){
        mFSDHistoryMap = new HashMap<Integer, List<Integer>>();

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.filter_drawer, container, false);

        LogUtil.debug (TAG, " filterfragment oncreateview 1");

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.filters);
        mClearFilterButton = (Button) rootView.findViewById(R.id.clear_filters);
        mClearFilterButton.setVisibility(View.INVISIBLE);
        mClearFilterButton.setOnClickListener(v -> {
            boolean pressed = ((Button) v).isPressed();

            if (pressed){
                mFilterFragmentAdapter.setCurrentCategory(mCurrentCategory, null);
                v.setVisibility(View.INVISIBLE);
                ((CallBackMainActivity) mMainNewsActivity ).clearCurrentPreferredSourceList();
                mFSDHistoryMap.remove(mCurrentCategory);
            }

        });

        mFilterFragmentAdapter = new FilterFragmentAdapter(getActivity(), this);
        LinearLayoutManager layoutManager =
                new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setAdapter(mFilterFragmentAdapter);

        return rootView;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }


    @Override
    public void onStop() {
        LogUtil.debug (TAG, " filterfragment onstop 1");
        super.onStop();
    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.debug (TAG, " filterfragment onpause 1");

    }

    @Override
    public void onStart() {
        super.onStart();
        LogUtil.debug (TAG, " filterfragment onstart 1");
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        LogUtil.debug (TAG, " filterfragment onactivitycreated 1");

    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.debug (TAG, " filterfragment onresume 1");

    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);


        if (context instanceof Activity){
            mMainNewsActivity=(MainNewsActivity) context;
            LogUtil.debug(TAG, " onAttach 1" );
            mMainNewsActivity.passInFilterFragment(this);
            LogUtil.debug(TAG, " onAttach 2" );
        }

    }



    public void drawerOpenedWithCategory(int category_id){
        LogUtil.debug(TAG, " drawerOpenedWithCategory 1" + category_id);
        mCurrentCategory = category_id;
        if (mFSDHistoryMap.get(category_id) != null){
            mFilterFragmentAdapter.setCurrentCategory(category_id, mFSDHistoryMap.get(category_id));
            if (mFSDHistoryMap.get(category_id).size() > 0) {
                mClearFilterButton.setVisibility(View.VISIBLE);
            } else {
                mClearFilterButton.setVisibility(View.INVISIBLE);
            }

        } else {
            mFilterFragmentAdapter.setCurrentCategory(category_id, null);
        }

    }

    public void clearPreferredList(){
        mFilterFragmentAdapter.setCurrentCategory(mCurrentCategory, null);
        mClearFilterButton.setVisibility(View.INVISIBLE);
        mFSDHistoryMap.remove(mCurrentCategory);
    }


}
