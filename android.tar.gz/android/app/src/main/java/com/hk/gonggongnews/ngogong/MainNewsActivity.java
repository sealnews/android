package com.hk.gonggongnews.ngogong;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.MenuItemImpl;

import com.hk.gonggongnews.ngogong.sync.FirebaseIntentService;
import com.hk.gonggongnews.ngogong.util.LogUtil;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.support.v7.view.menu.MenuView;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.hk.gonggongnews.ngogong.data.SourceInfo;
import com.hk.gonggongnews.ngogong.sync.GSheetQuery;
import com.hk.gonggongnews.ngogong.sync.Gongdispatch;
import com.hk.gonggongnews.ngogong.util.BottomNavigationViewHelper;
import com.hk.gonggongnews.ngogong.util.FragInfo;

import java.util.List;
import java.util.Locale;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;

public class MainNewsActivity extends AppCompatActivity implements
        FilterFragment.CallBackMainActivity {
    private final String TAG = MainNewsActivity.class.getSimpleName();

    private GSheetQuery mGSheetQuery;
    public SourceInfo mSourceInfo;
    private ViewPager mViewPager;
    private NewsFragmentPagerAdapter mPageradapter;
    private DrawerLayout mDrawerLayout;
    private FilterFragment mFilterFragment;
    private BottomNavigationView mBottomNavigationView;
    private MenuView.ItemView  mMainNewsItem;
    private MenuView.ItemView  mGongNewsItem;
    private MenuView.ItemView  mBookmarkItem;
    private CoordinatorLayout mCoordinatorlayout;

    private FirebaseAnalytics mFirebaseAnalytics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.debug(TAG, "oncreate 1 ");
        setContentView(R.layout.activity_main_news);

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        LogUtil.debug(TAG, " metrics "
                + ",density=" + metrics.density
                + ",densitydpi=" + metrics.densityDpi
                + ",scaleddensity=" + metrics.scaledDensity
                + ",heightpx=" + metrics.heightPixels
                + ",widthpx=" + metrics.widthPixels
                + ",xdpi=" + metrics.xdpi
                + ",ydpi=" + metrics.ydpi
        );
        LogUtil.debug(TAG, " metrics "
                + ",height-dp=" + (metrics.heightPixels / metrics.density)
                + ",width-dp=" + (metrics.widthPixels / metrics.density)
        );

        //mGSheetQuery = new GSheetQuery(this);
        //mGSheetQuery.test_getdatafromapi();
        LogUtil.debug(TAG, "irv oncreate 1.2 getflags()=" + String.valueOf(getIntent().getFlags())
                + ",istaskroot()="+ isTaskRoot());

        Configuration conf = getResources().getConfiguration();
        //en_US
        LogUtil.debug(TAG, " configuration.locale = " + conf.locale);

        FirebaseIntentService.setPersistenceenabledIfNot();
        FragInfo.init(this);

        DrawerLayout.DrawerListener drawerListener ;
        mDrawerLayout = findViewById(R.id.drawer_layout);
        mDrawerLayout.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                //LogUtil.debug(TAG, "mDrawerLayout onDrawerSlide 1");
            }

            @Override
            public void onDrawerOpened(View drawerView) {
                LogUtil.debug(TAG, "mDrawerLayout onDrawerOpened 1");
                int currentItemPos = mViewPager.getCurrentItem();
                LogUtil.debug(TAG, "mDrawerLayout onDrawerOpened 2 =" + currentItemPos);
                mFilterFragment.drawerOpenedWithCategory(mPageradapter.getCurrentFragmentCategory(currentItemPos));
                LogUtil.debug(TAG, "mDrawerLayout onDrawerOpened 3");
            }

            @Override
            public void onDrawerClosed(View drawerView) {
                //LogUtil.debug(TAG, "mDrawerLayout onDrawerClosed 1");

            }

            @Override
            public void onDrawerStateChanged(int newState) {
                //LogUtil.debug(TAG, "mDrawerLayout onDrawerStateChanged 1");

            }
        });


        // Find the view pager that will allow the user to swipe between fragments
        mViewPager = (ViewPager) findViewById(R.id.viewpager);

        //init sourceinfo to store the source information
        //this need to executed in the activity before anything else
        LogUtil.debug(TAG, "oncreate 1.3");
        SourceInfo.init(getApplicationContext(), getSupportLoaderManager());
        Gongdispatch.initialize(this);
        Gongdispatch.fraginitialize(this);
        Gongdispatch.gongnewsinitialize(this);

        LogUtil.debug(TAG, "oncreate 1.4");


        //getSupportActionBar().setTitle(R.string.more_detail);
        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_tmp_icon);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

        // Create an adapter that knows which fragment should be shown on each page
        mPageradapter = new NewsFragmentPagerAdapter(getSupportFragmentManager());

        // Set the adapter onto the view pager
        mViewPager.setAdapter(mPageradapter);

        //getSupportFragmentManager().findFragmentById()
        // Give the TabLayout the ViewPager
        TabLayout tabLayout = (TabLayout) findViewById(R.id.sliding_tabs);
        tabLayout.setupWithViewPager(mViewPager);
        LogUtil.debug(TAG, "oncreate 2 ");

        mMainNewsItem = (MenuView.ItemView) findViewById(R.id.nav_mainnews);
        mGongNewsItem = (MenuView.ItemView) findViewById(R.id.nav_gongnews);
        mBookmarkItem = (MenuView.ItemView) findViewById(R.id.nav_bookmark);

        mBottomNavigationView = (BottomNavigationView)
                findViewById(R.id.bottom_mainnews_navigation);

        BottomNavigationViewHelper.selection(this, mBottomNavigationView, R.id.nav_mainnews);
        /*
        mBottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.nav_mainnews:
                                mMainNewsItem.setTitle("1MainNews");
                                mMainNewsItem.setIcon(getResources().getDrawable(R.drawable.ic_expand_more_black));
                                mGongNewsItem.setTitle("");
                                mBookmarkItem.setTitle("");

                                break;

                            case R.id.nav_gongnews:
                                mMainNewsItem.setTitle("");
                                mGongNewsItem.setTitle("1GongNews");
                                mBookmarkItem.setTitle("");
                                break;

                            case R.id.nav_bookmark:
                                mMainNewsItem.setTitle("");
                                mGongNewsItem.setTitle("");
                                mBookmarkItem.setTitle("1Bookmark");
                                break;

                        }
                        return true;
                    }
                });
                */

        mCoordinatorlayout = findViewById(R.id.main_news_coordinatorlayout);
        mFirebaseAnalytics = FirebaseAnalytics.getInstance(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        /* Use the inflater's inflate method to inflate our menu layout to this menu */
        inflater.inflate(R.menu.top_menu, menu);
        /* Return true so that the menu is displayed in the Toolbar */
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.menu_feedback) {

            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:")); // only email apps should handle this
            intent.putExtra(Intent.EXTRA_EMAIL, "ngogonggongngo.0000001@gmail.com");
            intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.extra_subject_email));
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            }
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "setting-feedback" );
            mFirebaseAnalytics.logEvent("setting_open", bundle);
            return true;
        }
        if (id == R.id.menu_preferred_list) {

            mDrawerLayout.openDrawer(Gravity.LEFT,true);
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "setting-preferred-list" );
            mFirebaseAnalytics.logEvent("setting_open", bundle);

            return true;
        }
        if (id == R.id.menu_settings){
            LogUtil.debug(TAG, " onOptionsItemSelected 1 ");
            Intent settingIntent = new Intent(this, SettingActivity.class);
            startActivity(settingIntent);
            finish();
            Bundle bundle = new Bundle();
            bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "setting-settings" );
            mFirebaseAnalytics.logEvent("setting_open", bundle);

            LogUtil.debug(TAG, " onOptionsItemSelected 2 ");
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        int currentItemPos = mViewPager.getCurrentItem();
        int numOfNewItem = mPageradapter.shouldShowMoreItemSnackBar(currentItemPos);

        LogUtil.debug(TAG, " onrestart numofnewitem = " + numOfNewItem);
        if (numOfNewItem > 0){
            String displayString = getString(R.string.more_news_on_remote) +
                    String.valueOf(numOfNewItem) +
                    getString(R.string.number_of_news);
            Snackbar snack = Snackbar.make(mCoordinatorlayout,displayString, Snackbar.LENGTH_LONG);
            CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams)
                    snack.getView().getLayoutParams();
            DisplayMetrics metrics = getResources().getDisplayMetrics();

            int px = (int) ((int) 56 * ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT));
            LogUtil.debug(TAG, " left=" + params.leftMargin
                    + ",top=" +  params.topMargin
                    + ",right=" + params.rightMargin
                    + ",height=" + px);
            params.setMargins(params.leftMargin, params.topMargin, params.rightMargin, px);
            snack.getView().setLayoutParams(params);
            snack.setAction(R.string.update_action, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPageradapter.goupdateNow(currentItemPos);
                }
            });
            snack.show();
        }
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "mainnewsactivity-onrestart" );
        mFirebaseAnalytics.logEvent("main_restart", bundle);

    }



    public void callbackShowHowmanyItem(int currentItemPos, int numOfNewItem) {

        LogUtil.debug(TAG, " callbackShowHowmanyItem numofnewitem = " + numOfNewItem);
        if (numOfNewItem > 0){
            String displayString = getString(R.string.more_news_on_remote) +
                    String.valueOf(numOfNewItem) +
                    getString(R.string.number_of_news);
            Snackbar snack = Snackbar.make(mCoordinatorlayout,displayString, Snackbar.LENGTH_LONG);
            CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams)
                    snack.getView().getLayoutParams();
            DisplayMetrics metrics = getResources().getDisplayMetrics();

            int px = (int) ((int) 56 * ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT));
            LogUtil.debug(TAG, " left=" + params.leftMargin
                    + ",top=" +  params.topMargin
                    + ",right=" + params.rightMargin
                    + ",height=" + px);
            params.setMargins(params.leftMargin, params.topMargin, params.rightMargin, px);
            snack.getView().setLayoutParams(params);
            snack.setAction(R.string.update_action, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mPageradapter.goupdateNow(currentItemPos);
                }
            });
            snack.show();
        }

    }









    @Override
    public int getCurrentDisplayCategory() {
        int currentItemPos = mViewPager.getCurrentItem();
        LogUtil.debug(TAG, "getcurrentdisplaycategoy " + currentItemPos);
        return 0;
    }

    @Override
    public void passInFilterFragment(Fragment filterFragment) {
        LogUtil.debug(TAG, "passInFilterfragment 1 " );
        mFilterFragment = (FilterFragment) filterFragment;
    }

    @Override
    public void setCurrentPreferredSourceList(List<Integer> preferredList) {
        int currentItemPos = mViewPager.getCurrentItem();
        int[] passIntArray = new int[preferredList.size()];
        int index=0;
        for (int x : preferredList){
            passIntArray[index++] = x;
        }
        for (int y=0; y < passIntArray.length ; y++) {
            LogUtil.debug(TAG, "setCurrentPreferredSourceList 1=" + passIntArray[y]);
        }
        mPageradapter.passInPreferredFSD(currentItemPos, passIntArray);

        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "mainnewsact-setCurList" );
        mFirebaseAnalytics.logEvent("filter_action", bundle);


    }

    @Override
    public void clearCurrentPreferredSourceList() {
        int currentItemPos = mViewPager.getCurrentItem();
        LogUtil.debug (TAG, " clearCurrentPreferredSourceList 1 currentitempos=" + currentItemPos);
        mPageradapter.clearInPreferredFSD(currentItemPos);
        LogUtil.debug (TAG, " clearCurrentPreferredSourceList 2 ");
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "mainnewsact-clearCurList" );
        mFirebaseAnalytics.logEvent("filter_action", bundle);
    }

    @Override
    public void clearCurrentPreferredSourceListAfterSwipe() {
        mFilterFragment.clearPreferredList();
        Bundle bundle = new Bundle();
        bundle.putString(FirebaseAnalytics.Param.ITEM_NAME, "mainnewsact-setCurList-swipe" );
        mFirebaseAnalytics.logEvent("filter_action", bundle);
    }



    public void setLocale(String lang) {
        Locale myLocale = new Locale(lang);
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.getConfiguration();
        res.updateConfiguration(conf, dm);
        Intent refresh = new Intent(this, MainNewsActivity.class);
        startActivity(refresh);
        finish();
    }
}
